BDTree
Version: 1.01
Author: Jianhua Ruan (jruan@cse.wustl.edu)
Copyright: Washington University in St Louis
This java-based software learns a two-dimensional multivariate regression tree given a matrix of responses and corresponding row and column attributes. In particular, the software can be used to model the expression levels of multiple genes under multiple conditions, using binding motifs (gene attributes) and TF levels (condition attributes) as predictors. The model built by BDTree provides testable hypotheses about condition-specific binding motifs and TFs for genes, and can also be used to predict the expression levels of unknown genes under unknown conditions, given some attributes of the genes and conditions.


*********************************************
INSTALLATION
*********************************************

No installation is needed. Just copy bdtree-1-0.jar into some directory. To test, type 
"java -classpath SomeDirectory/bdtree-1-0.jar bdtree.BDTree" to see the list of flags supported by BDTree. Optionally you can add SomeDirectory/bdtree-1-0.jar into your classpath and type "java bdtree.BDTree". Below is the information you should see on screen:

General options:

-t <name of training file>
        Sets training file.
-T <name of test file>
        Sets test file. If missing, a cross-validation will be performed on the training data.
-x <number of folds>
        Sets number of folds for cross-validation. 0 means no cross-validation. (default: 10).
-X <cross validation type>
        0: all, 1: row, 2: column, 3: row + column (default: 0).
-s <random number seed>
        Sets random number seed for cross-validation (default: 1).
-v
        Outputs no statistics for training data.
-o
        Outputs statistics only, not the classifier.
-p <fileName>
        Outputs predictions for test instances.
-g <fileName>
        Outputs the dot graph representation of the classifier.
-m <fileName>
        Outputs the rearranged response matrix (not the attribute values).
-f <filePrefix>
        Outputs the response matrix within each leaf node.
-y
        Only outputs the names of the rows and columns assocaited with the response matrix. (Use with -f.)
-i <fileName>
        Calculates and outputs importance score for each attribute.

Options specific to bdtree.BDTree:

-U
        Use unpruned tree.
-C
        Use cross-validation pruning.
-M <minimum number of rows>
        Set minimum number of rows per leaf.    (default: 5)
-N <minimum number of columns>
        Set minimum number of columns per leaf. (default: 5)
-R
        Output rules instead of tree.
-S
        Don't perform subtree raising.
-V
        Verbose output.

*********************************************
USAGE
*********************************************

The simplest use of BDTree is to learn a regression tree for explaining the
expression levels given in a training file (see below for the format of
training files). For example, java bdtree.BDTree -t TrainFile will learn a tree, and perform a ten-fold cross-validation (CV) by default on the training data. The output shows the structure of the tree, and test statistics. If CV is not needed, use -x 0.

Four types of CV are available: 
-X 1: each time reserve a proportion of the rows (i.e., genes) for testing. 

------------
|    train |
|          |
------------
|    test  |
------------


-X 2: each time reserve a proportion of the columns (i.e., conditions) for testing. 
----------------
| train | test |
|       |      |
|       |      |
----------------



-X 3: each time reserve a proportion of rows and columns for testing. In this case, both the rows and columns for testing have not been used for training. 

-----------------
| train  |      |
|        |      |
-----------------
|        | test |
-----------------

-X 0: each time reserve a proportion of rows and columns for testing. In this case, either the rows or the columns, or both have not been used for training.

-----------------
| train  |      |
|        |      |
----------      |
|          test |
-----------------


A separate test file can be given with flag -T, in which case the test file
will be used for validation. Test files have the same format as training
files. For example, java bdtree.BDTree -t TrainFile -T testFile will learn a tree with TrainFile and test the accuracy of the tree with TestFile.

When flag -p is used, the predicted expression levels will be saved into a file. In the output, the columns are: gene name, condition name, actual value, predicted value, and the ID of the leaf used for this prediction.

With the flag -g, the tree structure can be saved into a dot file, which can be used to draw a graph with the Graphviz software (http://www.graphviz.org/).

With the flag -m, the rearranged expression matrix can be saved into a file, which can be visualized in the TIGER MultiExperiment Viewer (TMEV, http://www.tm4.org/mev.html). The grey lines represent a split in the expression matrix. 

With the flag -i, the importance score for each attribute are calculated with surrogate splits and saved into a file. Row attributes (motifs) and column attributes (TFs) are prefixed by �h.� and �v.�, respectively. The higher the score, the more important is the attribute in explaining the expression levels.

With the flag -f, the expression submatrix in each leaf node is saved into a file <prefix>_n<abc>.dat. Where <prefix> is the argument given with �f, abc is the ID for a leaf. When used together with �-y�, only the gene and condition names, not the actual expression levels, for that submatrix will be printed.

With the flag -U, the learned tree will not be pruned.

With the flag -C, a proportion of the training data (36% by default) will be reserved for selecting the best braches to be pruned.

If neither -U nor -C is given, the tree will be pruned by a method similar to MDL and all training data are used for training.

With -S given, the pruning procedure considers replacing a node with its largest branch sometimes.

-M and -N specify the minimum number of rows or columns per leaf.

With -R, the output is a set of rules extracted from the tree. Every path from the root to a leaf node defines a rule.


*********************************************
INPUT FILE FORMAT
*********************************************

A training or testing file contains of the following contents:
a. Motif score matrix
b. TF expression matrix
c. Gene expression matrix
d. Motif names
e. TF names
f. Gene names
g. Condition names

The format of the files is (use space or tab as field separators):
The First line: @row.atts
Following the first line are motif names, one name per line.
Following motif names: @rows
Following @rows is the motif score matrix, where each line represents a gene. Each line starts with the name of the gene, followed by the score of each motif for the gene. 
@col.atts
TF names, one name per line.
@cols
A TF expression matrix, where each line represents a condition. Each line starts with the name of the condition, followed by the expression level of each TF under the condition.
@data
The gene expression matrix. Each line represents a gene and each column represents a condition. Don't include gene or condition names in this matrix. The genes and conditions are explicitly given in the @rows and @cols matrices. Make sure that the order of the genes and conditions in this matrix is the same as in the @rows and @cols matrices.

For an example input file, see the yeast_cc_alpha.arff downloaded together with the jar file.


*********************************************
BUG FIXES
*********************************************
In Node.java: fixed the .dot file output format, so that mean expression and variance is shown for terminal nodes
