package bdtree;

import java.util.*;
import model.DNASymbol;

/**
 * <p>Copyright (c) 2004, Washington University in St Louis</p>
 *
 * <p>@author Jianhua Ruan</p>
 *
 * <p>@version $Revision$</p>
 *
 * <p> </p> not attributable
 */



public class WordNeighbor {
    public WordNeighbor() {
    }

    public int[][] findNeighbors(String[] words) {
        Vector[] neighbors = new Vector[words.length];
        DNASymbol dna = (DNASymbol)DNASymbol.getInstance();
        System.err.println("compute neighbors with factor .7");
        for (int i = 0; i < words.length; i++) {
            if (neighbors[i] == null) neighbors[i] = new Vector();
            for (int j = i + 1; j < words.length; j++) {
                int s = score(words[i], words[j]);
                int s2 = score(words[i], dna.reverse(words[j]));
                if (s2 > s) s = s2;
                int a = words[i].length();
                int b = words[j].length();
//                a = a > b ? b : a;
                if (s >= a * 0.7) {
                    neighbors[i].add(new Integer(j));
                }
                if (s >= b * 0.7) {
                    if (neighbors[j] == null) {
                        neighbors[j] = new Vector();
                    }
                    neighbors[j].add(new Integer(i));
                }
            }
        }
        int[][] n = new int[words.length][];
        for (int i = 0; i < words.length; i++) {
            n[i] = new int[neighbors[i].size()];
            for (int j = 0; j < n[i].length; j++) {
                n[i][j] = ((Integer)neighbors[i].get(j)).intValue();
            }
        }
        return n;
    }

    int score(String a, String b) {
        char[] ca = a.toCharArray();
        char[] cb = b.toCharArray();
        int[][] s = new int[cb.length+1][ca.length+1];
        int i = 0;
        for (; i < cb.length; i++) {
            int j = 0;
            for (; j < ca.length; j++) {
                if (cb[i] == ca[j]) {
                    s[i+1][j+1] = s[i][j] + 1;
                } else {
                    s[i+1][j+1] = s[i][j];
                }
            }
            if (s[i+1][j] < s[i][j]) s[i+1][j] = s[i][j];
        }
        int max = 0;
        for (int j = 1; j <= ca.length; j++) {
            if (s[i][j] > s[i][max]) {
                max = j;
            }
        }
        return s[i][max];
    }

    public static void main(String[] args) {
        WordNeighbor wn = new WordNeighbor();
        System.err.println(wn.score("abcde", "fef"));
    }

}
