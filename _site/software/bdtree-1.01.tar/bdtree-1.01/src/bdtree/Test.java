package bdtree;


import java.util.Random;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: Washington University in St Louis</p>
 *
 * @author not attributable
 * @version 1.0
 */
public class Test {
    public Test() {
    }

    public void run() throws Exception {
        int R = 1024;
        int C = 1024;
        Random random = new Random(0);
        for (int m = 0; m < 11; m++) {
            int r = R >> m;
            int c = C << m;
            double[][] array = new double[r][c];
            double avg1 = 0;
            double avg2 = 0;
            for (int n = 0; n < 1; n++) {
                for (int i = 0; i < r; i++) {
                    for (int j = 0; j < c; j++) {
                        array[i][j] = random.nextDouble();
                    }
                }
                Stat stat = new Stat(r, c);
                for (int j = 0; j < r; j++) {
                    stat.addRow(array[j]);
                }
                avg1 += stat.var2() / 1;
                avg2 += stat.var() / 1;
            }
//            double logr = Math.log(r);
//            double logc = Math.log(c);
//            double entropy = Math.log(logr) * logr + logc * Math.log(logc);
//            System.out.println(r + " " + entropy + " " + avg / 10 + " " + entropy * avg);
            System.out.println(r + " " + avg1 + " " +
                               avg2 * (r * c - r - c + 1) / (r * c + 1));
        }
    }

    public static void main(String[] args) throws Exception {
        Test test = new Test();
        test.run();
    }
}
