package bdtree;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Random;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: Washington University in St Louis</p>
 *
 * @author not attributable
 * @version 1.0
 */
public class Test2 {
    public void run() throws Exception {
        BufferedReader reader = new BufferedReader(new FileReader(
                "x:/yeast_cell_cycle/dtanalysis/multivar/regtree/bdtree/cc/bdtree.arff"));
        Array arr = new Array(reader);
        Random random = new Random(0);
        Stat stat = new Stat(arr);
        double defaultVar = stat.SS2();
        double stdev = stat.var();
//        System.out.println(stdev);
        for (int m = 0; m < 100; m++) {
            Stat[] stats = new Stat[2];
            stats[0] = new Stat(arr.numRows(), arr.numColumns());
            stats[1] = new Stat(arr.numRows(), arr.numColumns());
            for (int i = 0; i < arr.numColumns(); i++) {
                if (random.nextBoolean()) {
                    stats[0].addColumn(arr.column(i));
                } else {
                    stats[1].addColumn(arr.column(i));
                }
            }
            double gain = defaultVar / stdev -
                          stats[0].SS2() / stats[0].var() -
                          stats[1].SS2() / stats[1].var();
            System.err.println(gain / stat.nRows / stat.nCols);
        }
    }

    public static void main(String[] args) throws Exception {
        Test2 test = new Test2();
        test.run();
    }
}
