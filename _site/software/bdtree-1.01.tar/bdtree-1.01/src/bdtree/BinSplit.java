package bdtree;

/**
 * This class implements a binary split of the attributes.
 * <p> Copyright (c) 2004, Washington University in St Louis</p>
 * @author Jianhua Ruan
 * @version $Revision: 1.7 $
 */

public class BinSplit extends NodeSplitModel {

    /** Attribute to split on. */
    protected int m_attIndex;

    /** Minimum number of objects in a split.   */
    protected int m_minNoObj;

    /** Value of split point. */
    double m_splitPoint;

    /**
     * Initializes the split model.
     */
    public BinSplit(int attIndex, int minNoObj, boolean hSplit) {
        this.m_attIndex = attIndex;
        this.m_minNoObj = minNoObj;
        this.hSplit = hSplit;
    }

    protected BinSplit() {}

    /**
     * Creates a split on the given data.
     *
     * @exception Exception if something goes wrong
     */
    public void buildClassifier(Array array, Stat stat) {
        m_numSubsets = 0;
        m_splitPoint = Double.MAX_VALUE;
        array = new Array(array);
        array.sortInstances(m_attIndex, hSplit);
        if (hSplit) {
            handleHSplit(array, stat);
        } else {
            handleVSplit(array, stat);
        }
    }

    /**
     * Returns index of attribute for which split was generated.
     */
    public final int attIndex() {
        return m_attIndex;
    }

    /**
     * Creates split on numeric attribute.
     *
     * @exception Exception if something goes wrong
     */
    void handleHSplit(Array data, Stat stat) {
        int next = 1;
        int last = 0;
        int index = 0;
        int splitIndex = -1;

        double minSplit = 5;

        int r = data.numRows();
        int c = data.numColumns();

        // Compute minimum number of Instances required in each
        // subset.
        if (minSplit <= m_minNoObj) {
            minSplit = m_minNoObj;
        } else if (minSplit > 50) {
            minSplit = 50;
        }
        if (r < 2 * minSplit) {
            return;
        }

        Stat[] m_stats = new Stat[2];
        m_stats[1] = new Stat(data);
        m_stats[0] = new Stat(r, c);
        double defaultRF = stat.rowEffect();
        double bestRF = defaultRF;
        double defaultVar = stat.var2();

        while (next < r) {
            if (data.rowInstance(next - 1).getAttribute(m_attIndex) + 1e-5 <
                data.rowInstance(next).getAttribute(m_attIndex)) {
                m_stats[0].shiftRows(m_stats[1], data, last, next);
                if ((m_stats[0].nRows >= minSplit) &&
                    (m_stats[1].nRows >= minSplit)) {
                    double currentRF = m_stats[0].rowEffect() +
                                       m_stats[1].rowEffect();
                    if (currentRF > bestRF && m_stats[1].var2() < defaultVar) {
                        bestRF = currentRF;
                        splitIndex = next - 1;
                    }
                    index++;
                }
                last = next;
            }
            next++;
        }

        // Was there any useful split?
        if (index == 0) {
            return;
        }

//    m_gain = (bestRF - defaultRF) * r;
//        m_gain = (bestRF - defaultRF) * r - this.FILTER * stat.SS();
        m_gain = (bestRF - defaultRF) - this.FILTER * stat.SS() / r;
        /*
                if (!BDTree.diffRowCol && splitIndex != -1) {
                    m_gain /= r;
//                m_gain /= r * r / (splitIndex + 1) / (r - splitIndex - 1) - 1;
                }
         */
        if (m_gain <= 0) {
            return;
        }

        // Set instance variables' values to values for best split.
        m_numSubsets = 2;
        m_splitPoint = data.rowInstance(splitIndex + 1).getAttribute(m_attIndex);

    }

    void handleVSplit(Array data, Stat stat) {
        int next = 1;
        int last = 0;
        int index = 0;
        int splitIndex = -1;

        double minSplit = 2;

        int r = data.numRows();
        int c = data.numColumns();

        // Compute minimum number of Instances required in each
        // subset.
        if (minSplit <= m_minNoObj) {
            minSplit = m_minNoObj;
        } else if (minSplit > 50) {
            minSplit = 50;
        }
        if (c < 2 * minSplit) {
            return;
        }

        Stat[] m_stats = new Stat[2];
        m_stats[1] = new Stat(data, false);
        m_stats[0] = new Stat(r, c);

        double defaultRF = stat.colEffect();
        double bestRF = defaultRF;

        while (next < c) {
            if (data.colInstance(next - 1).getAttribute(m_attIndex) + 1e-5 <
                data.colInstance(next).getAttribute(m_attIndex)) {
                m_stats[0].shiftColumns(m_stats[1], data, last, next);
                if ((m_stats[0].nCols >= minSplit) &&
                    (m_stats[1].nCols >= minSplit)) {
                    double currentRF = m_stats[0].colEffect() +
                                       m_stats[1].colEffect();
                    if (currentRF > bestRF) {
                        bestRF = currentRF;
                        splitIndex = next - 1;
                    }
                    index++;
                }
                last = next;
            }
            next++;
        }

        // Was there any useful split?
        if (index == 0) {
            return;
        }

//     m_gain = (bestRF - defaultRF) * c;
//        m_gain = (bestRF - defaultRF) * c - this.FILTER * stat.SS();
        m_gain = (bestRF - defaultRF) - this.FILTER * stat.SS() / c;
        /*
                if (!BDTree.diffRowCol && splitIndex != -1) {
                    m_gain /= c;
//            m_gain /= c * c / (splitIndex+1) / (c - splitIndex - 1) - 1;

                }
         */
        if (m_gain <= 0) {
            return;
        }

        // Set instance variables' values to values for best split.
        m_numSubsets = 2;
        m_splitPoint = data.colInstance(splitIndex + 1).getAttribute(m_attIndex);

    }

    double gain(Array parent, Array[] children) {
        Stat stat = new Stat(parent);
        Stat[] subStats = new Stat[children.length];
        for (int i = 0; i < subStats.length; i++) {
            subStats[i] = new Stat(children[i]);
        }
        double gain = 0;
        if (this.hSplit) {
            gain = -stat.rowEffect() -
                   this.FILTER * stat.SS() / stat.nRows();
            for (int i = 0; i < subStats.length; i++) {
                gain += subStats[i].rowEffect();
            }
        } else {
            gain = -stat.colEffect() -
                   this.FILTER * stat.SS() / stat.nColumns();
            for (int i = 0; i < subStats.length; i++) {
                gain += subStats[i].colEffect();
            }
        }
        if (gain < 0) {
            return 0;
        }
        return gain;
    }

    /**
     * Prints left side of condition..
     * @param index of subset and training set.
     */
    public String leftSide(Array data) {
        if (hSplit) {
            return "h." + data.rowAttribute(m_attIndex);
        }
        return "v." + data.colAttribute(m_attIndex);
    }

    /**
     * Prints the condition satisfied by instances in a subset.
     *
     * @param index of subset and training set.
     */
    public String rightSide(int index, Array data) {
        double c = m_splitPoint;
/*        if (hSplit) {
            c = data.restoreRowAtt(m_attIndex, c);
        } else {
            c = data.restoreColAtt(m_attIndex, c);
        }
 */
        if (index == 0) {
            return " < " + Utils.roundDouble(c, 2);
        } else {
            return " >= " + Utils.roundDouble(c, 2);
        }
    }


    /**
     * Returns index of subset instance is assigned to.
     * Returns -1 if instance is assigned to more than one subset.
     *
     * @exception Exception if something goes wrong
     */

    public int whichSubset(Instance instance) {
        if (instance.isMissing(m_attIndex)) {
            return -1;
        } else if (instance.getAttribute(m_attIndex) < m_splitPoint) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isFuzzy(Instance inst) {
        switch (BDTree.fuzzy) {
        case 0:
            return false;
        case 1:
            return true;
        default:
        }
        double attValue = inst.getAttribute(m_attIndex);
        if (attValue < m_splitPoint - 2 || attValue > m_splitPoint + 2) {
            return false;
        }
        if (hSplit && attValue < 0.001) {
            return false;
        }
        return true;
    }

}
