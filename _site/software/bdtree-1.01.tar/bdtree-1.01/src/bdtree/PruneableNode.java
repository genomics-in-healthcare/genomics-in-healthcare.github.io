package bdtree;

/**
 * <p> Copyright (c) 2004</p>
 *
 * <p> Washington University in St Louis</p>
 *
 * @author Jianhua Ruan
 * @version 1.0
 */

public class PruneableNode extends Node {

    /** True if the tree is to be pruned. */
    boolean m_pruneTheTree = false;

    float m_CF = 0.25f;

    /** The confidence factor for pruning. */
    double alpha = 0.0005;

    /** Is subtree raising to be performed? */
    boolean m_subtreeRaising = true;

    boolean ratio = false;

    /**
     * Constructor for pruneable tree structure. Stores reference
     * to associated training data at each node.
     *
     * @param toSelectLocModel selection method for local splitting model
     * @param pruneTree true if the tree is to be pruned
     * @param cf the confidence factor for pruning
     * @exception Exception if something goes wrong
     */
    public PruneableNode(ModelSelection toSelectLocModel,
                         boolean pruneTree, float cf,
                         boolean raiseTree) throws Exception {

        super(toSelectLocModel);

        m_pruneTheTree = pruneTree;
        m_CF = cf;
        m_subtreeRaising = raiseTree;
    }

    /**
     * Method for building a pruneable classifier tree.
     *
     * @exception Exception if something goes wrong
     */
    public void buildClassifier(Array data) throws Exception {
        buildTree(data);
/*        collapse();
        if (ratio) {
            setAlpha(m_stat.totVar() / m_stat.avgVar2());
        } else {
            setAlpha(m_stat.totVar());
        }
        if (m_pruneTheTree) {
            prune();
        }
 */
    }

    void setAlpha(double a) {
        alpha *= a;
        if (!m_isLeaf) {
            for (int i = 0; i < m_sons.length; i++) {
                _son(i).setAlpha(a);
            }
        }
    }


    /**
     * Collapses a tree to a node if training error doesn't increase.
     */
    public final void collapse() {

        double errorsOfTree;
        double errorsIfLeaf = 0;
        int i;

        if (!m_isLeaf) {
            errorsOfTree = getErrorsForTree();
//      errorsOfTree = m_stat.totVar() / m_stat.avgVar2();
//      errorsOfTree = m_stat.totVar();
            errorsIfLeaf = errorsIfLeaf();
            if (errorsOfTree >= errorsIfLeaf * 0.999) {
                // Free adjacent trees
                m_sons = null;
                m_isLeaf = true;
                // Get NoSplit Model for tree.
                m_localModel = new NoSplit();
                System.err.println("collapse " + m_id);
                System.err.println("errorsOfTree " + errorsOfTree);
                System.err.println("errorsIfLeaf " + errorsIfLeaf);
            } else {
                for (i = 0; i < m_sons.length; i++) {
                    _son(i).collapse();
                }
            }
        }
    }

    /**
     * Prunes a tree using C4.5's pruning procedure.
     *
     * @exception Exception if something goes wrong
     */
    public void prune() throws Exception {

        double errorsLargestBranch;
        double errorsLeaf;
        double errorsTree;
        int indexOfLargestBranch;
        int i;
        if (!m_isLeaf) {

            // Prune all subtrees.
            for (i = 0; i < m_sons.length; i++) {
                _son(i).prune();
            }

            // Compute error for the whole subtree
            errorsTree = getErrorsForTree();

            // Compute error if this Tree would be leaf
//      errorsLeaf = m_stat.totVar() / m_stat.avgVar2();
//      errorsLeaf = m_stat.totVar();
            errorsLeaf = errorsIfLeaf();
            // Compute error for largest branch
            indexOfLargestBranch = largestBranch();
            int leavesInLargestBranch = 0;
            int leavesInOtherBranches = 0;
            for (int j = 0; j < m_sons.length; j++) {
                if (j == indexOfLargestBranch) {
                    leavesInLargestBranch = m_sons[j].numLeaves();
                } else {
                    leavesInOtherBranches += m_sons[j].numLeaves();
                }
            }
            int nLeaves = leavesInLargestBranch + leavesInOtherBranches;

            if (m_subtreeRaising && !_son(indexOfLargestBranch).m_isLeaf) {
                errorsLargestBranch = _son(indexOfLargestBranch).
                                      getEstimatedErrorsForBranch(m_train);
            } else {
                errorsLargestBranch = Double.MAX_VALUE;
            }

            // Decide if leaf is best choice.
            if (errorsLeaf <= errorsTree + alpha * (nLeaves - 1)
                &&
                errorsLeaf <=
                errorsLargestBranch + alpha * (leavesInLargestBranch - 1)) {
                // Free son Trees
                asLeaf();
 System.err.println(m_id + " becomes leaf");
                return;
            }

            // Decide if largest branch is better choice
            // than whole subtree.

            if (errorsLargestBranch <=
                errorsTree + alpha * (leavesInOtherBranches)) {
                Node largestBranch = m_sons[indexOfLargestBranch];
                m_sons = largestBranch.m_sons;
                m_localModel = largestBranch.m_localModel;
                m_isLeaf = largestBranch.m_isLeaf;
                m_id = largestBranch.m_id;
 System.err.println(m_id + " raised");
                newStat(m_train);
                prune();
            }

        }
    }

    /**
     * Returns a newly created tree.
     *
     * @exception Exception if something goes wrong
     */
    protected Node getNewTree(Array data) throws Exception {

        PruneableNode newTree =
                new PruneableNode(m_modelSelection, m_pruneTheTree, m_CF,
                                  m_subtreeRaising);
        newTree.level = this.level + 1;
        newTree.parent = this;
        newTree.buildTree(data);

        return newTree;
    }

    /**
     * Computes estimated errors for tree.
     */
    private double getErrorsForTree() {

        double errors = 0;

        if (m_isLeaf) {
//      return m_stat.totVar() / m_stat.avgVar2();
//        return m_stat.totVar();
            return errorsIfLeaf();
        } else {
            for (int i = 0; i < m_sons.length; i++) {
                errors = errors + _son(i).getErrorsForTree();
            }
            return errors;
        }
    }

    /**
     * Computes estimated errors for one branch.
     *
     * @exception Exception if something goes wrong
     */
    private double getEstimatedErrorsForBranch(Array data) throws Exception {

        Array[] localInstances;
        double errors = 0;
        int i;

        if (m_isLeaf) {
            Stat stat = new Stat(data);
            if (ratio) {
                return stat.SS2() / stat.var();
            } else {
                return stat.SS2();
            }
        } else {
            localInstances = m_localModel.split(data);
            for (i = 0; i < m_sons.length; i++) {
                if (localInstances[i].numRows() != 0 &&
                    localInstances[i].numColumns() != 0) {
                    errors = errors +
                             _son(i).getEstimatedErrorsForBranch(localInstances[
                            i]);
                }
            }
            return errors;
        }
    }


    /**
     * Computes new distributions of instances for nodes
     * in tree.
     *
     * @exception Exception if something goes wrong
     */
    private void newStat(Array data) throws Exception {

        this.resetStat(data);
        m_train = data;
        if (!m_isLeaf) {
            Array[] localInstances = m_localModel.split(data);
            for (int i = 0; i < m_sons.length; i++) {
                _son(i).newStat(localInstances[i]);
            }
        }
    }

    public int largestBranch() {
        if (m_isLeaf) {
            return -1;
        }
        int size = 0;
        int index = -1;
        for (int i = 0; i < m_sons.length; i++) {
            if (_son(i).numInstances() > size) {
                size = _son(i).numInstances();
                index = i;
            }
        }
        return index;
    }

    public PruneableNode _son(int i) {
        return (PruneableNode) m_sons[i];
    }

    public double errorsIfLeaf() {
        if (ratio) {
            return m_stat.SS2() / m_stat.var();
        } else {
            return m_stat.SS2();
        }
    }

}
