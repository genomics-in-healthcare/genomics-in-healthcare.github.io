package bdtree;

import java.io.*;
import java.util.*;

/**
 * Class for evaluating machine learning models. <p>
 * <p> Copyright (c) 2004, Washington University in St Louis</p>
 * @author Jianhua Ruan
 * @version $Revision: 1.8 $
 */
public class Evaluation {

    /** The weight of all instances that had a class assigned to them. */
    private double m_WithClass;

    /** Sum of errors. */
    private double m_SumErr;

    /** Sum of absolute errors. */
    private double m_SumAbsErr;

    /** Sum of squared errors. */
    private double m_SumSqrErr;

    /** Sum of class values. */
    private double m_SumClass;

    /** Sum of squared class values. */
    private double m_SumSqrClass;

    /*** Sum of predicted values. */
    private double m_SumPredicted;

    /** Sum of squared predicted values. */
    private double m_SumSqrPredicted;

    /** Sum of predicted * class values. */
    private double m_SumClassPredicted;

    public Evaluation(Array data) throws Exception {
    }

    public void crossValidateModel(BDTree classifier,
                                   Array data, int numFolds, int cvType) throws
            Exception {
// could use multiple thread here
// Thread[] th = new Thread[numFolds];

        Array train = null;
        Array[] test = null;
        for (int i = 0; i < numFolds; i++) {
            System.err.println("cross-validating type " + cvType + " fold " + i);
            switch (cvType) {
            case 1:
                train = data.trainCVRow(numFolds, i);
                test = new Array[] {data.testCVRow(numFolds, i)};
                break;
            case 2:
                train = data.trainCVCol(numFolds, i);
                test = new Array[] {data.testCVCol(numFolds, i)};
                break;
            case 3:
                train = data.trainCV(numFolds, i);
                test = new Array[] {data.testCVCol(numFolds,
                       i).testCVRow(numFolds, i)};
                break;
            default:
                train = data.trainCV(numFolds, i);
                test = data.testCV(numFolds, i);
                break;
            }
            classifier.buildClassifier(train);
            for (int j = 0; j < test.length; j++) {
                evaluateModel(classifier, test[j]);
            }
        }
    }

    public static String evaluateModel(BDTree classifier,
                                       String[] options) throws Exception {

        Array train = null, tempTrain, test = null, template = null;
        int seed = 1, folds = 10;
        String trainFileName, testFileName,
                seedString, foldsString, objectInputFileName,
                objectOutputFileName;
        boolean noOutput = false,
                           printClassifications = false, trainStatistics = true;
        StringBuffer text = new StringBuffer();
        BufferedReader trainReader = null, testReader = null;
        ObjectInputStream objectInputStream = null;
        Random random;
        StringBuffer schemeOptionsText = null;

        StringBuffer optionsText = new StringBuffer();
        for (int i = 0; i < options.length; i++) {
            optionsText.append(options[i] + " ");
        }

        boolean printLeaves = false;
        boolean printDataMatrix = false;
        boolean leafStubOnly = false;
        String leafFilePrefix = null;
        String dataMatrixFileName = null;
        String predictionFileName = null;
        int cvType = 0;

        String attributeImportanceFileName = null;
        String graphFileName = null;

        long trainTimeStart = 0, trainTimeElapsed = 0,
                testTimeStart = 0, testTimeElapsed = 0;

    if (options.length == 0) {
        System.err.println(makeOptionString(classifier));
        System.exit(0);
    }

        try {

            // Get basic options (options the same for all schemes)
            trainFileName = Utils.getOption('t', options);
//            objectInputFileName = Utils.getOption('l', options);
//            objectOutputFileName = Utils.getOption('d', options);
            objectInputFileName = "";
            objectOutputFileName = "";
            testFileName = Utils.getOption('T', options);
            if (trainFileName.length() == 0) {
                if (objectInputFileName.length() == 0) {
                    throw new Exception("No training file and no object " +
                                        "input file given.");
                }
                if (testFileName.length() == 0) {
                    throw new Exception("No training file and no test " +
                                        "file given.");
                }
            } else if ((objectInputFileName.length() != 0) &&
                       (testFileName.length() == 0)) {
                throw new Exception("Classifier not incremental, or no " +
                                    "test file provided: can't " +
                                    "use both train and model file.");
            }
            try {
                if (trainFileName.length() != 0) {
                    trainReader = new BufferedReader(new FileReader(
                            trainFileName));
                }
                if (testFileName.length() != 0) {
                    testReader = new BufferedReader(new FileReader(testFileName));
                }
                if (objectInputFileName.length() != 0) {
                    InputStream is = new FileInputStream(objectInputFileName);
                    objectInputStream = new ObjectInputStream(is);
                }
            } catch (Exception e) {
                throw new Exception("Can't open file " + e.getMessage() + '.');
            }
            if (testFileName.length() != 0) {
                template = test = new Array(testReader);
            }
            if (trainFileName.length() != 0) {
                System.err.println("start reading data.....");
                train = new Array(trainReader);
                /*        Array t2 = new Array(train, true, false);
                        for (int i = 77; i < train.numColumns(); i++) {
                 t2.addColumn(train.colInstance(i), train.column(i));
                        }
                        train = t2;
                 */
                System.err.println("finished reading data.");
                System.err.println("nRows = " + train.numRows());
                System.err.println("nCols = " + train.numColumns());
                System.err.println("nRowAtts = " + train.numRowAttributes());
                System.err.println("nColAtts = " + train.numColAttributes());
                template = train;
            }
            if (template == null) {
                throw new Exception(
                        "No actual dataset provided to use as template");
            }
            seedString = Utils.getOption('s', options);
            if (seedString.length() != 0) {
                seed = Integer.parseInt(seedString);
            }
            foldsString = Utils.getOption('x', options);
            if (foldsString.length() != 0) {
                folds = Integer.parseInt(foldsString);
                String cvTypeString = Utils.getOption('X', options);
                if (cvTypeString.length() != 0) {
                    cvType = Integer.parseInt(cvTypeString);
                }
            }

            attributeImportanceFileName = Utils.getOption('i', options);

            noOutput = Utils.getFlag('o', options);
            trainStatistics = !Utils.getFlag('v', options);
            graphFileName = Utils.getOption('g', options);

            leafFilePrefix = Utils.getOption('f', options);
            leafStubOnly = Utils.getFlag('y', options);
            if (leafFilePrefix.length() != 0) {
                printLeaves = true;
            } else if (leafStubOnly) {
                throw new Exception("wrong option: -y set without -f");
            }
            dataMatrixFileName = Utils.getOption('m', options);
            if (dataMatrixFileName.length() != 0) {
                printDataMatrix = true;
            }

            predictionFileName = Utils.getOption('p', options);
            if (predictionFileName != null && predictionFileName.length() != 0) {
                printClassifications = true;
            }

            // If a model file is given, we can't process
            // scheme-specific options
            if (objectInputFileName.length() != 0) {
                Utils.checkForRemainingOptions(options);
            } else {

                // Set options for classifier
                if (classifier instanceof OptionHandler) {
                    for (int i = 0; i < options.length; i++) {
                        if (options[i].length() != 0) {
                            if (schemeOptionsText == null) {
                                schemeOptionsText = new StringBuffer();
                            }
                            if (options[i].indexOf(' ') != -1) {
                                schemeOptionsText.append('"' + options[i] +
                                        "\" ");
                            } else {
                                schemeOptionsText.append(options[i] + " ");
                            }
                        }
                    }
                    ((OptionHandler) classifier).setOptions(options);
                }
            }
            Utils.checkForRemainingOptions(options);
        } catch (Exception e) {
            throw new Exception(e.toString() +
                                makeOptionString(classifier));
        }

        // Setup up evaluation objects
        Evaluation trainingEvaluation = new Evaluation(template);
        Evaluation testingEvaluation = new Evaluation(template);
        if (objectInputFileName.length() != 0) {
            // Load classifier from file
            classifier = (BDTree) objectInputStream.readObject();
            objectInputStream.close();
        }

        // Build the classifier if no object file provided
        if (objectInputFileName.length() == 0) {

            // Build classifier in one go
            tempTrain = train;
            trainTimeStart = System.currentTimeMillis();
            classifier.buildClassifier(tempTrain);
            trainTimeElapsed = System.currentTimeMillis() - trainTimeStart;

            if (attributeImportanceFileName != null && attributeImportanceFileName.length() != 0) {
                printInfo(classifier.surrogateInfo(),
                          attributeImportanceFileName);
            }

        }

        // Save the classifier if an object output file is provided
        if (objectOutputFileName.length() != 0) {
            OutputStream os = new FileOutputStream(objectOutputFileName);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(os);
            objectOutputStream.writeObject(classifier);
            objectOutputStream.flush();
            objectOutputStream.close();
        }

        // If classifier is drawable output string describing graph
        if (graphFileName != null && graphFileName.length() != 0) {
            printInfo(classifier.graph(), graphFileName);
        }

        // Output test instance predictions
        if (printClassifications) {
            printClassifications(classifier, train, testFileName, predictionFileName);
        }

        if (printLeaves) {
            printLeaves(classifier, leafFilePrefix, leafStubOnly);
        }

        if (printDataMatrix) {
            printDataMatrix(classifier, dataMatrixFileName);
        }

        // Output model
        if (!(noOutput)) {
            if (classifier instanceof OptionHandler) {
                if (schemeOptionsText != null) {
//	  text.append("\nOptions: "+schemeOptionsText);
                    text.append("\nOptions: " + optionsText);
                    text.append("fuzzy=" + BDTree.fuzzy);
                    text.append(" split=" + BDTree.split);
                    text.append(" knn=" + BDTree.knn);
                    text.append("\n");
                }
            }
            text.append("\n" + classifier.toString() + "\n");
            System.out.println(text);
            text = new StringBuffer();
        }

        // Compute error estimate from training data
        if ((trainStatistics) &&
            (trainFileName.length() != 0)) {

            System.err.println("evaluating training data");
            testTimeStart = System.currentTimeMillis();
            trainingEvaluation.evaluateModel(classifier,
                                             train);
            testTimeElapsed = System.currentTimeMillis() - testTimeStart;

            // Print the results of the training evaluation
            text.append("\nTime taken to build model: " +
                        Utils.doubleToString(trainTimeElapsed / 1000.0, 2) +
                        " seconds");
            text.append("\nTime taken to test model on training data: " +
                        Utils.doubleToString(testTimeElapsed / 1000.0, 2) +
                        " seconds");
            text.append(trainingEvaluation.
                        toSummaryString("\n\n=== Error on training" +
                                        " data ===\n"));
        }

        text.append("\n\n=== Stats on training" +
                    " data ===\n" + classifier.information());

        System.out.println(text);
        text = new StringBuffer();

        /*
         classifier.kmeans();

         text.append("\n\n=== Stats on K-means training" +
                " data ===\n" + classifier.information());

            if (printLeaves) {
                printLeaves(classifier, "K_" + leafFilePrefix, leafStubOnly);
            }

            if (printDataMatrix) {
                printDataMatrix(classifier, "K_" + dataMatrixPrefix);
            }

         */

        // Compute proper error estimates
        if (testFileName.length() != 0) {
            test = new Array(testReader);

            // Testing is on the supplied test data
            for (int i = 0; i < test.numRows(); i++) {
                for (int j = 0; j < test.numColumns(); j++) {
                    Instance a = test.rowInstance(i);
                    Instance b = test.colInstance(j);
                    double v = test.value(i, j);
                    testingEvaluation.evaluateModelOnce(classifier, a, b, v);
                }
            }
            testReader.close();
            text.append("\n\n" + testingEvaluation.
                        toSummaryString("=== Error on test data ===\n"));
        } else if (trainFileName.length() != 0 && folds > 1) {
            // Testing is via cross-validation on training data
            random = new Random(seed);
            random.setSeed(seed);
            train.randomize(random);
            testingEvaluation.
                    crossValidateModel(classifier, train, folds, cvType);
            text.append("\n\n\n" + testingEvaluation.
                        toSummaryString("=== Cross-validation ===\n"));
        }
        return text.toString();
    }


    /**
     * Evaluates the classifier on a given set of instances.
     *
     * @param classifier machine learning classifier
     * @param data set of test instances for evaluation
     * @exception Exception if model could not be evaluated
     * successfully
     */
    public void evaluateModel(BDTree classifier,
                              Array data) throws Exception {
/*
        Vector results = classifier.classifyArray(data);
        for (int k = 0; k < results.size(); k++) {
            double[][][] pair = (double[][][]) results.get(k);
            for (int i = 0; i < pair[0].length; i++) {
                for (int j = 0; j < pair[0][i].length; j++) {
                    updateStatsForPredictor(pair[0][i][j], pair[1][i][j]);
                }
            }
        }
 */

            for (int i = 0; i < data.numRows(); i++) {
                Instance a = data.rowInstance(i);
                for (int j = 0; j < data.numColumns(); j++) {
                    Instance b = data.colInstance(j);
                    double v = data.value(i, j);
                    if (BDTree.verbose) {
                        System.err.print("%cv " + i + " " + j);
                    }
                    evaluateModelOnce(classifier, a, b, v);
                }
            }

    }

    /**
     * Evaluates the classifier on a single instance.
     *
     * @return the prediction made by the clasifier
     * @exception Exception if model could not be evaluated
     * successfully or the data contains string attributes
     */
    public double evaluateModelOnce(BDTree classifier,
                                    Instance a, Instance b, double v) throws
            Exception {
        double pred = classifier.classifyInstance(a, b);
        updateStatsForPredictor(pred, v);
        if (BDTree.verbose) {
            System.err.println(" " + v + " " + pred);
        }
        return pred;
    }


    /**
     * Evaluates the supplied prediction on a single instance.
     *
     * @param prediction the supplied prediction
     * @param instance the test instance to be classified
     * @exception Exception if model could not be evaluated
     * successfully
     */
/*
    public void evaluateModelOnce(double prediction,
                                  double v) throws Exception {
        updateStatsForPredictor(prediction, v);
    }
 */

    /**
     * Gets the number of test instances that had a known class value
     * (actually the sum of the weights of test instances with known
     * class value).
     *
     * @return the number of test instances with known class
     */
    public final double numInstances() {
        return m_WithClass;
    }

    /**
     * Returns the correlation coefficient if the class is numeric.
     *
     * @return the correlation coefficient
     * @exception Exception if class is not numeric
     */
    public final double correlationCoefficient() throws Exception {
        double correlation = 0;
        double varActual =
                m_SumSqrClass - m_SumClass * m_SumClass / m_WithClass;
        double varPredicted =
                m_SumSqrPredicted - m_SumPredicted * m_SumPredicted /
                m_WithClass;
        double varProd =
                m_SumClassPredicted - m_SumClass * m_SumPredicted / m_WithClass;

        if (Utils.smOrEq(varActual * varPredicted, 0.0)) {
            correlation = 0.0;
        } else {
            correlation = varProd / Math.sqrt(varActual * varPredicted);
        }
        return correlation;
    }

    /**
     * Returns the mean absolute error. Refers to the error of the
     * predicted values for numeric classes, and the error of the
     * predicted probability distribution for nominal classes.
     *
     * @return the mean absolute error
     */
    public final double meanAbsoluteError() {

        return m_SumAbsErr / m_WithClass;
    }

    /**
     * Returns the mean absolute error of the prior.
     *
     * @return the mean absolute error
     */
    /*
       public final double meanPriorAbsoluteError() {
      return m_SumPriorAbsErr / m_WithClass;
       }
     */
    /**
     * Returns the relative absolute error.
     *
     * @return the relative absolute error
     * @exception Exception if it can't be computed
     */
    /*
      public final double relativeAbsoluteError() throws Exception {
        return 100 * meanAbsoluteError() / meanPriorAbsoluteError();
      }
     */
    /**
     * Returns the root mean squared error.
     *
     * @return the root mean squared error
     */
    public final double rootMeanSquaredError() {

        return Math.sqrt(m_SumSqrErr / m_WithClass);
    }

    /**
     * Returns the root mean prior squared error.
     *
     * @return the root mean prior squared error
     */
    /*
       public final double rootMeanPriorSquaredError() {

      return Math.sqrt(m_SumPriorSqrErr / m_WithClass);
       }
     */
    /**
     * Returns the root relative squared error if the class is numeric.
     *
     * @return the root relative squared error
     */
    /*
       public final double rootRelativeSquaredError() {

      return 100.0 * rootMeanSquaredError() /
        rootMeanPriorSquaredError();
       }
     */

    public String toSummaryString() {

        return toSummaryString("=== Summary ===\n");
    }


    public String toSummaryString(String title) {

        StringBuffer text = new StringBuffer();

        text.append(title + "\n");
        try {
            if (m_WithClass > 0) {
                text.append("Correlation coefficient            ");
                text.append(Utils.doubleToString(correlationCoefficient(), 12,
                                                 4) +
                            "\n");
                text.append("Mean absolute error                ");
                text.append(Utils.doubleToString(meanAbsoluteError(), 12, 4)
                            + "\n");
                text.append("Root mean squared error            ");
                text.append(Utils.
                            doubleToString(rootMeanSquaredError(), 12, 4)
                            + "\n");
                /*
                 text.append("Relative absolute error            ");
                 text.append(Utils.doubleToString(relativeAbsoluteError(),
                      12, 4) + " %\n");
                 text.append("Root relative squared error        ");
                 text.append(Utils.doubleToString(rootRelativeSquaredError(),
                      12, 4) + " %\n");
                 */
            }
            text.append("Total Number of Instances          ");
            text.append(Utils.doubleToString(m_WithClass, 12, 4) + "\n");
        } catch (Exception ex) {
            // Should never occur since the class is known to be nominal
            // here
            System.err.println("Arggh - Must be a bug in Evaluation class");
        }

        return text.toString();
    }


    /**
     * Tests whether the current evaluation object is equal to another
     * evaluation object
     *
     * @param obj the object to compare against
     * @return true if the two objects are equal
     */
    public boolean equals(Object obj) {

        if ((obj == null) || !(obj.getClass().equals(this.getClass()))) {
            return false;
        }
        Evaluation cmp = (Evaluation) obj;
        if (m_WithClass != cmp.m_WithClass) {
            return false;
        }
        if (m_SumErr != cmp.m_SumErr) {
            return false;
        }
        if (m_SumAbsErr != cmp.m_SumAbsErr) {
            return false;
        }
        if (m_SumSqrErr != cmp.m_SumSqrErr) {
            return false;
        }
        if (m_SumClass != cmp.m_SumClass) {
            return false;
        }
        if (m_SumSqrClass != cmp.m_SumSqrClass) {
            return false;
        }
        if (m_SumPredicted != cmp.m_SumPredicted) {
            return false;
        }
        if (m_SumSqrPredicted != cmp.m_SumSqrPredicted) {
            return false;
        }
        if (m_SumClassPredicted != cmp.m_SumClassPredicted) {
            return false;
        }

        return true;
    }

    private static void printInfo(String info, String fileName) throws
            Exception {
        PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(
                fileName)));
        pw.print(info);
        pw.flush();
    }

    private static void printLeaves(BDTree classifier, String filePrefix,
                                    boolean leafStubOnly) throws Exception {
        classifier.printLeaves(filePrefix, leafStubOnly);
    }

    private static void printDataMatrix(BDTree classifier, String fileName) throws
            Exception {
        classifier.printDataMatrix(fileName);
    }

    /**
     * Prints the predictions for the given dataset into a String variable.
     */
    private static void printClassifications(BDTree classifier,
                                             Array train,
                                             String testFileName,
                                             String outFile) throws Exception {
        Array test = null;
        PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(
                outFile)));
        if (testFileName.length() != 0) {
            BufferedReader testReader = null;
            try {
                testReader = new BufferedReader(new FileReader(testFileName));
            } catch (Exception e) {
                throw new Exception("Can't open file " + e.getMessage() + '.');
            }
            test = new Array(testReader);
            testReader.close();
        } else {
            test = train;
        }
        for (int i = 0; i < test.numRows(); i++) {
            for (int j = 0; j < test.numColumns(); j++) {
                Instance a = test.rowInstance(i);
                Instance b = test.colInstance(j);
                double v = test.value(i, j);
                double predValue = classifier.classifyInstance(a, b);
                pw.println(a.getName() + " " + b.getName() + " " + v + " "
                           + Utils.roundDouble(predValue, 2) + " "
                           + classifier.ruleForInstance(a, b));
            }
        }
        pw.close();
    }

    /**
     * Make up the help string giving all the command line options
     *
     * @param classifier the classifier to include options for
     * @return a string detailing the valid command line options
     */
    private static String makeOptionString(BDTree classifier) {

        StringBuffer optionsText = new StringBuffer("");

        // General options
        optionsText.append("\n\nGeneral options:\n\n");
        optionsText.append("-t <name of training file>\n");
        optionsText.append("\tSets training file.\n");
        optionsText.append("-T <name of test file>\n");
        optionsText.append("\tSets test file. If missing, a cross-validation");
        optionsText.append(" will be performed on the training data.\n");
        optionsText.append("-x <number of folds>\n");
        optionsText.append(
                "\tSets number of folds for cross-validation. 0 means no cross-validation. (default: 10).\n");
            optionsText.append("-X <cross validation type>\n");
            optionsText.append(
                    "\t0: all, 1: row, 2: column, 3: row + column (default: 0).\n");
        optionsText.append("-s <random number seed>\n");
        optionsText.append(
                "\tSets random number seed for cross-validation (default: 1).\n");
//        optionsText.append("-l <name of input file>\n");
//        optionsText.append("\tSets model input file.\n");
//        optionsText.append("-d <name of output file>\n");
//        optionsText.append("\tSets model output file.\n");
        optionsText.append("-v\n");
        optionsText.append("\tOutputs no statistics for training data.\n");
        optionsText.append("-o\n");
        optionsText.append("\tOutputs statistics only, not the classifier.\n");
        optionsText.append("-p <fileName>\n");
        optionsText.append("\tOutputs predictions for test instances.\n");
        optionsText.append("-g <fileName>\n");
        optionsText.append("\tOutputs the dot graph representation of the classifier.\n");
        optionsText.append("-m <fileName>\n");
        optionsText.append("\tOutputs the rearranged response matrix (not the attribute values).\n");
        optionsText.append("-f <filePrefix>\n");
        optionsText.append("\tOutputs the response matrix within each leaf node.\n");
        optionsText.append("-y\n");
        optionsText.append("\tOnly outputs the names of the rows and columns assocaited with the response matrix. (Use with -f.)\n");
        optionsText.append("-i <fileName>\n");
        optionsText.append("\tCalculates and outputs importance score for each attribute.\n");

        // Get scheme-specific options
        if (classifier instanceof OptionHandler) {
            optionsText.append("\nOptions specific to "
                               + classifier.getClass().getName()
                               + ":\n\n");
            Enumeration enu = ((OptionHandler) classifier).listOptions();
            while (enu.hasMoreElements()) {
                Option option = (Option) enu.nextElement();
                optionsText.append(option.synopsis() + '\n');
                optionsText.append(option.description() + "\n");
            }
        }
        return optionsText.toString();
    }

    /**
     * Updates all the statistics about a predictors performance for
     * the current test instance.
     *
     * @param predictedValue the numeric value the classifier predicts
     * @param instance the instance to be classified
     * @exception Exception if the class of the instance is not
     * set
     */
    private void updateStatsForPredictor(double predictedValue,
                                         double actualValue) throws Exception {

        // Update stats
        m_WithClass++;
        m_SumClass += actualValue;
        m_SumSqrClass += actualValue * actualValue;
        m_SumClassPredicted += actualValue * predictedValue;
        m_SumPredicted += predictedValue;
        m_SumSqrPredicted += predictedValue * predictedValue;

        double diff = predictedValue - actualValue;
        m_SumErr += diff;
        m_SumAbsErr += Math.abs(diff);
        m_SumSqrErr += diff * diff;
    }

}
