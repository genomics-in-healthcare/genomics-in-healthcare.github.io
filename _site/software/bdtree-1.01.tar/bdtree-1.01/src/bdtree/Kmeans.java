package bdtree;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
import java.util.Vector;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: Washington University in St Louis</p>
 *
 * @author not attributable
 * @version $Revision: 1.4 $
 */

public class Kmeans {
    double k;
    double[][] data;
    double[][] center;
    int[] size;
    int[] cluster;

    public Kmeans() {
    }

    public int[] cluster(double[][] data, int k) {
        int[] initial = new int[data.length];
        java.util.Random random = new java.util.Random();
        for (int i = 0; i < initial.length; i++) {
            initial[i] = (int) (k * random.nextDouble());
        }
        return cluster(data, k, initial);
    }

    public int[] cluster(double[][] data, int k, int[] initial) {
        if (data.length != initial.length) {
            System.err.println("initial.length != data.length");
            System.exit(0);
        }
        this.k = k;
        this.data = data;
        this.cluster = new int[data.length];
        System.arraycopy(initial, 0, cluster, 0, initial.length);
        this.center = new double[k][data[0].length];
        this.size = new int[k];
        int change = 0;
        int totChange = 0;
        int iterations = 0;
        do {
            calculateMean();
            iterations++;
            change = 0;
            for (int i = 0; i < data.length; i++) {
                int index = member(data[i], center);
                if (index != cluster[i]) {
                    change++;
                    cluster[i] = index;
                }
            }
            totChange += change;
        } while (change > 0);
        System.err.println("number of iterations before converge: " +
                           iterations);
        System.err.println("total number of changes: " + totChange);
        return cluster;
    }

    private void calculateMean() {
        for (int i = 0; i < k; i++) {
            java.util.Arrays.fill(center[i], 0);
        }
        java.util.Arrays.fill(size, 0);
        for (int i = 0; i < data.length; i++) {
            int m = cluster[i];
            size[m]++;
            for (int j = 0; j < data[i].length; j++) {
                center[m][j] += data[i][j];
            }
        }
        for (int i = 0; i < k; i++) {
            for (int j = 0; j < center[i].length; j++) {
                center[i][j] /= size[i];
            }
        }
    }

    public int member(double[] p, double[][] centers) {
        double min = Double.MAX_VALUE;
        int m = -1;
        for (int i = 0; i < centers.length; i++) {
            double d = dist(p, centers[i]);
            if (d < min) {
                min = d;
                m = i;
            }
        }
        return m;
    }

    double dist(double[] a, double[] b) {
        double d = 0;
        for (int i = 0; i < a.length; i++) {
            d += (a[i] - b[i]) * (a[i] - b[i]);
        }
        return d;
    }


    public static void main(String[] args) throws Exception {
        Kmeans kmeans = new Kmeans();
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.
                in));
        String aLine = null;
        Vector name = new Vector();
        Vector values = new Vector();
        while ((aLine = reader.readLine()) != null) {
            StringTokenizer st = new StringTokenizer(aLine);
            name.add(st.nextToken());
            Vector row = new Vector();
            while (st.hasMoreTokens()) {
                row.add(st.nextToken());
            }
            values.add(row);
        }
        int nRow = values.size();
        int nCol = ((Vector) values.get(0)).size();
        double[][] data = new double[values.size()][nCol];

        for (int i = 0; i < nRow; i++) {
            Vector row = (Vector) values.get(i);
            if (row.size() != nCol) {
                System.err.println("not equal nCol");
                System.exit(1); ;
            }
            for (int j = 0; j < nCol; j++) {
                String v = (String) row.get(j);
                data[i][j] = Double.parseDouble(v);
            }
        }

        int k = Integer.parseInt(args[0]);
        int[] cluster = (new Kmeans()).cluster(data, k);

        System.out.print("gid\tcluster");
        for (int i = 1; i <= nCol; i++) {
            System.out.print("\tc" + i);
        }
        System.out.println();
        for (int i = 0; i < k; i++) {
            for (int j = 0; j < nRow; j++) {
                if (cluster[j] == i) {
                    System.out.print(name.get(j) + "\t" + i);
                    for (int c = 0; c < nCol; c++) {
                        System.out.print("\t" + data[j][c]);
                    }
                    System.out.println();
                }
            }
            for (int c = 0; c < nCol + 2; c++) {
                System.out.print("\t");
            }
            System.out.println();
        }
    }
}
