package bdtree;

/**
 * <p> Copyright (c) 2004</p>
 *
 * <p> Washington University in St Louis</p>
 *
 * @author Jianhua Ruan
 * @version 1.0
 */

public class BinSplit_row_or_column_variance extends BinSplit {

    /**
     * Initializes the split model.
     */
    public BinSplit_row_or_column_variance(int attIndex, int minNoObj,
                                           boolean hSplit) {
        super(attIndex, minNoObj, hSplit);
    }

    protected BinSplit_row_or_column_variance() {}

    /**
     * Creates split on numeric attribute.
     *
     * @exception Exception if something goes wrong
     */
    void handleHSplit(Array data, Stat stat) {
        int next = 1;
        int last = 0;
        int index = 0;
        int splitIndex = -1;

        double minSplit = 5;

        int r = data.numRows();
        int c = data.numColumns();

        // Compute minimum number of Instances required in each
        // subset.
        if (minSplit <= m_minNoObj) {
            minSplit = m_minNoObj;
        } else if (minSplit > 50) {
            minSplit = 50;
        }
        if (r < 2 * minSplit) {
            return;
        }

        Stat[] m_stats = new Stat[2];
        m_stats[1] = new Stat(data);
        m_stats[0] = new Stat(r, c);
        double defaultRF = stat.SS3r();
        double bestRF = defaultRF;
        double defaultVar = defaultRF / r;

        while (next < r) {
            if (data.rowInstance(next - 1).getAttribute(m_attIndex) + 1e-5 <
                data.rowInstance(next).getAttribute(m_attIndex)) {
                m_stats[0].shiftRows(m_stats[1], data, last, next);
                if ((m_stats[0].nRows >= minSplit) &&
                    (m_stats[1].nRows >= minSplit)) {
                    double currentRF = m_stats[0].SS3r() +
                                       m_stats[1].SS3r();
                    if (currentRF < bestRF &&
                        m_stats[1].SS3r() / m_stats[1].nRows() <
                        defaultVar) {
                        bestRF = currentRF;
                        splitIndex = next - 1;
                    }
                    index++;
                }
                last = next;
            }
            next++;
        }

        // Was there any useful split?
        if (index == 0) {
            return;
        }

//    m_gain = (bestRF - defaultRF) * r;
//  m_gain = (defaultRF - bestRF) * r - this.FILTER * stat.totVar2();
        m_gain = (defaultRF - bestRF) - this.FILTER * stat.SS() / r;

//  if (!BDTree.diffRowCol) { m_gain /= r; }

        if (m_gain <= 0) {
            return;
        }

        // Set instance variables' values to values for best split.
        m_numSubsets = 2;
        m_splitPoint = data.rowInstance(splitIndex + 1).getAttribute(m_attIndex);

    }

    void handleVSplit(Array data, Stat stat) {
        int next = 1;
        int last = 0;
        int index = 0;
        int splitIndex = -1;

        double minSplit = 2;

        int r = data.numRows();
        int c = data.numColumns();

        // Compute minimum number of Instances required in each
        // subset.
        if (minSplit <= m_minNoObj) {
            minSplit = m_minNoObj;
        } else if (minSplit > 25) {
            minSplit = 25;
        }
        if (c < 2 * minSplit) {
            return;
        }

        Stat[] m_stats = new Stat[2];
        m_stats[1] = new Stat(data, false);
        m_stats[0] = new Stat(r, c);

        double defaultRF = stat.SS3c();
        double bestRF = defaultRF;

        while (next < c) {
            if (data.colInstance(next - 1).getAttribute(m_attIndex) + 1e-5 <
                data.colInstance(next).getAttribute(m_attIndex)) {
                m_stats[0].shiftColumns(m_stats[1], data, last, next);
                if ((m_stats[0].nCols >= minSplit) &&
                    (m_stats[1].nCols >= minSplit)) {
                    double currentRF = m_stats[0].SS3c() +
                                       m_stats[1].SS3c();
                    if (currentRF < bestRF) {
                        bestRF = currentRF;
                        splitIndex = next - 1;
                    }
                    index++;
                }
                last = next;
            }
            next++;
        }

        // Was there any useful split?
        if (index == 0) {
            return;
        }

//     m_gain = (bestRF - defaultRF) * c;
//     m_gain = (defaultRF - bestRF) * c - this.FILTER * stat.totVar2();
        m_gain = (defaultRF - bestRF) - this.FILTER * stat.SS() / c;
//     if (!BDTree.diffRowCol) { m_gain /= c; }

        if (m_gain <= 0) {
            return;
        }

        // Set instance variables' values to values for best split.
        m_numSubsets = 2;
        m_splitPoint = data.colInstance(splitIndex + 1).getAttribute(m_attIndex);

    }

    double gain(Array parent, Array[] children) {
        Stat stat = new Stat(parent);
        Stat[] subStats = new Stat[children.length];
        for (int i = 0; i < subStats.length; i++) {
            subStats[i] = new Stat(children[i]);
        }
        double gain = 0;
        if (this.hSplit) {
            gain = stat.SS3r() -
                   this.FILTER * stat.SS() / stat.nRows();
            for (int i = 0; i < subStats.length; i++) {
                gain -= subStats[i].SS3r();
            }
        } else {
            gain = stat.SS3c() -
                   this.FILTER * stat.SS() / stat.nColumns();
            for (int i = 0; i < subStats.length; i++) {
                gain -= subStats[i].SS3c();
            }
        }
        if (gain < 0) {
            return 0;
        }
        return gain;
    }


}
