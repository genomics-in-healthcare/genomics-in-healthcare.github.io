package bdtree;

import java.io.*;
import java.util.*;

/**
 * <p> Copyright (c) 2004</p>
 *
 * <p> Washington University in St Louis</p>
 *
 * @author Jianhua Ruan
 * @version 1.0
 */
public class Node {

    /** Local model at node. */
    protected NodeSplitModel m_localModel;
    protected ModelSelection m_modelSelection;

    /** References to sons. */
    protected Node[] m_sons;

    /** True if node is leaf. */
    protected boolean m_isLeaf;

    protected Stat m_stat;

    /** The training instances. */
    protected Array m_train;

    /** The test instances */
    protected Array m_test;

    /** The id for the node. */
    protected int m_id;

    protected Node parent = null;

//    protected double percent = 1.0;

    protected BitSet usedRowAtts;
    protected BitSet usedColAtts;

    protected static int lastid = 1;

    int level = 1;

    /**
     * Constructor.
     */
    public Node(ModelSelection ms) {
        m_id = lastid++;
        m_sons = null;
        m_isLeaf = true;
        m_modelSelection = ms;
        usedRowAtts = new BitSet();
        usedColAtts = new BitSet();
    }

    /**
     * Method for building a classifier tree.
     *
     * @exception Exception if something goes wrong
     */
    public void buildClassifier(Array array) throws Exception {
        buildTree(array);
    }

    /**
     * Builds the tree structure.
     *
     * @param data the data for which the tree structure is to be
     * generated.
     * @exception Exception if something goes wrong
     */
    public void buildTree(Array data) throws Exception {
        if (data.numRows() <= 0 || data.numColumns() <= 0) {
            throw new Exception("no instances!");
        }
        m_train = data;
        m_stat = new Stat(data);
//        data.updateInstances(m_stat);

        if (BDTree.verbose) {
            System.err.println("node: " + m_id + " " + this.dumpLabel() + " " + m_stat.var2());
        }
//        if (this.level >= 4) {
//            return;
//        }
        m_localModel = m_modelSelection.selectModel(data, m_stat);
        if (BDTree.verbose) {
            System.err.println("gain = " + m_localModel.gain());
        }
        if (m_localModel.numSubsets() > 1) {
/*
            if (m_localModel.hSplit()) {
                usedRowAtts.set(((BinSplit) m_localModel).attIndex());
            } else {
                usedColAtts.set(((BinSplit) m_localModel).attIndex());
            }
*/
            Array[] localArrays = m_localModel.split(data);
            m_sons = new Node[m_localModel.numSubsets()];
            for (int i = 0; i < m_sons.length; i++) {
                m_sons[i] = getNewTree(localArrays[i]);
                localArrays[i] = null;
            }
            m_isLeaf = false;
        }
        data = null;
    }

    public String ruleForInstance(Instance a, Instance b) throws Exception {
        if (m_isLeaf) {
            return String.valueOf(m_id);
        }
        int treeIndex = m_localModel.whichSubset(a, b);
        if (treeIndex == -1) {
            return String.valueOf(m_id);
        }
        return m_sons[treeIndex].ruleForInstance(a, b);
    }

    public String toRules() {
        StringBuffer text = new StringBuffer();
        text.append("J48Rule: \n");
        try {
            if (m_isLeaf) {
                text.append("[" + m_id + "]" + " : " + this.dumpLabel());
            } else {
                text.append(ruleText(""));
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
        return text.toString();
    }

    private String ruleText(String prefix) throws Exception {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < m_sons.length; i++) {
            String rule = m_localModel.leftSide(m_train) +
                          m_localModel.rightSide(i, m_train);
            if (prefix != "") {
                rule = prefix + " and " + rule;
            }
            if (m_sons[i].m_isLeaf) {
                sb.append("[" + m_sons[i].m_id + "] : ");
                sb.append(rule + " : " + m_sons[i].dumpLabel());
                sb.append("\n");
            } else {
                sb.append(m_sons[i].ruleText(rule));
            }
        }
        return sb.toString();
    }


    /**
     * Returns graph describing the tree.
     *
     * @exception Exception if something goes wrong
     */
    public String graph() throws Exception {

        StringBuffer text = new StringBuffer();

        text.append("digraph J48Tree {\n");
        if (m_isLeaf) {
            text.append("N" + m_id + " [label=\"" +
                        this.dumpLabel() + "\\[" + m_id + "\\]" +
                        "\" " + "shape=box style=filled ");
            text.append("]\n");
        } else {
            String label = m_localModel.leftSide(m_train);
//            String label = m_localModel.leftSide(m_train) +
//                           " (" + m_id + ")" + " (" + this.dumpLabel() + ")";
            text.append("N" + m_id + " [label=\"" +
                        label + "\"]\n");
            graphTree(text);
        }

        return text.toString() + "}\n";
    }

    /**
     * Returns number of leaves in tree structure.
     */
    public int numLeaves() {
        int num = 0;
        if (m_isLeaf) {
            return 1;
        } else {
            for (int i = 0; i < m_sons.length; i++) {
                num += m_sons[i].numLeaves();
            }
        }
        return num;
    }

    /**
     * Returns number of nodes in tree structure.
     */
    public int numNodes() {
        int no = 1;
        if (!m_isLeaf) {
            for (int i = 0; i < m_sons.length; i++) {
                no += m_sons[i].numNodes();
            }
        }
        return no;
    }

    /**
     * Prints tree structure.
     */
    public String toString() {

        try {
            StringBuffer text = new StringBuffer();

            if (m_isLeaf) {
                text.append(": ");
                text.append(this.dumpLabel());
                text.append(" [" + m_id + "]");
            } else {
                dumpTree(0, text);
            }
            text.append("\n\nNumber of Leaves  : \t" + numLeaves() + "\n");
            text.append("\nSize of the tree : \t" + numNodes() + "\n");

            return text.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return "Can't print classification tree.";
        }
    }

    /**
     * Returns a newly created tree.
     *
     * @param data the training data
     * @exception Exception if something goes wrong
     */
    protected Node getNewTree(Array data) throws Exception {

        Node newTree = new Node(m_modelSelection);
//        newTree.usedRowAtts.or(this.usedRowAtts);
//        newTree.usedColAtts.or(this.usedColAtts);
        newTree.level = this.level + 1;
        newTree.parent = this;
        newTree.buildTree(data);
        return newTree;
    }

    /**
     * Help method for printing tree structure.
     *
     * @exception Exception if something goes wrong
     */
    private void dumpTree(int depth, StringBuffer text) throws Exception {

        for (int i = 0; i < m_sons.length; i++) {
            text.append("\n"); ;
            for (int j = 0; j < depth; j++) {
                text.append("|   ");
            }
            text.append(m_localModel.leftSide(m_train));
            text.append(m_localModel.rightSide(i, m_train));
            if (m_sons[i].m_isLeaf) {
                text.append(": ");
                text.append(m_sons[i].dumpLabel() + " (" +
                            m_localModel.m_good[i] + ")");
                text.append(" [" + m_sons[i].m_id + "]");
            } else {
                text.append(": ");
                text.append(m_sons[i].dumpLabel() + " (" +
                            m_localModel.m_good[i] + ")");
                text.append(" [" + m_sons[i].m_id + "]");
//                if (this.level < 4) {
                    m_sons[i].dumpTree(depth + 1, text);
//                }
            }
        }
    }

    String dumpLabel() {
        return m_train.numRows() + " x " + m_train.numColumns() + "(" +
//                Utils.roundDouble(m_stat.SS3r() / m_stat.SS(), 2) +
                Utils.roundDouble(m_stat.avg(), 2) +
                "," +
//                Utils.roundDouble(m_stat.SS3c() / m_stat.SS(), 2) +
                Utils.roundDouble(Math.sqrt(m_stat.var()), 2) +
                ")";
    }


    /**
     * Help method for printing tree structure as a graph.
     *
     * @exception Exception if something goes wrong
     */
    private void graphTree(StringBuffer text) throws Exception {

        for (int i = 0; i < m_sons.length; i++) {
            text.append("N" + m_id + "->" + "N" + m_sons[i].m_id +
                        " [label=\"" + m_localModel.rightSide(i, m_train).trim() +
                        "\"]\n");
            if (m_sons[i].m_isLeaf) {
                String label = " (" + m_sons[i].m_id + ")"
                               + " (" + m_sons[i].dumpLabel() + ")";
                text.append("N" + m_sons[i].m_id +
                            " [label=\"" + label + "\" " +
                            "shape=box style=filled]\n");
            } else {
                String label = m_sons[i].m_localModel.leftSide(m_train);
//                               +  " (" + m_sons[i].m_id + ")" + " (" +
//                               m_sons[i].dumpLabel() + ")";
                text.append("N" + m_sons[i].m_id + " [label=\"" + label +
                            "\"]\n");
//                if (this.level < 4) {
                    m_sons[i].graphTree(text);
//                }
            }
        }
    }


    public Vector classifyArray(Array array) {
        Vector v = new Vector();
        if (m_isLeaf) {
            int column = -1;
            int row = -1;
                        if (m_train.rowInstance(0).equals(array.rowInstance(0))) {
                            row = 1;
                        }
             if (m_train.colInstance(0).equals(array.colInstance(0))) {
                            column = 1;
                        }
/*                                    if (row == -1 && column == -1) {
              System.err.println("error...............col and row not recognized");
                                          System.exit(0);
                                      }
 */

             if (row == 1 && column == 1) {
                 if (this.parent == null) {
                     row = -1;
                     column = -1;
                 } else if (this.parent.m_localModel.hSplit()) {
                     row = -1;
                 } else {
                     column = -1;
                 }
             }

            v.add(estimate(array, row, column));
        } else {
            Array[] localArrays = m_localModel.split(array);
            for (int i = 0; i < m_sons.length; i++) {
                if (localArrays[i].size() != 0) {
                    v.addAll(m_sons[i].classifyArray(localArrays[i]));
                }
            }
            localArrays = null;
        }
        return v;
    }

    double[][][] estimate(Array array, int row, int column) {
        int[][] nearestRows = new int[array.nRows][];
        int[][] nearestColumns = new int[array.nCols][];
        if (BDTree.knn) {
            this.usedRowAtts = new BitSet();
            for (int i = 0; i < array.nRows; i++) {
                if (row == -1) {
                    nearestRows[i] = nearestRow( -1, array.rowInstance(i), 5);
                } else {
                    nearestRows[i] = new int[] {i};
                }
            }
            this.usedColAtts = new BitSet();
            for (int i = 0; i < array.nCols; i++) {
                if (column == -1) {
                    nearestColumns[i] = nearestColumn( -1, array.colInstance(i),
                            5);
                } else {
                    nearestColumns[i] = new int[] {i};
                }
            }
        }

        double[][] pred = new double[array.nRows][array.nCols];

        double[] rAvg = m_stat.rowAvg();
        double[] cAvg = m_stat.colAvg();
        for (int i = 0; i < array.nRows; i++) {
            for (int j = 0; j < array.nCols; j++) {
                if (!BDTree.knn) {
                    if (row == -1 && column == -1) {
                        pred[i][j] = m_stat.avg();
                    } else if (row == -1) {
                        pred[i][j] = cAvg[j];
                    } else if (column == -1) {
                        pred[i][j] = rAvg[i];
                    } else {
                        pred[i][j] = cAvg[j];
                    }
                } else {
                    pred[i][j] = 0;
                    for (int k = 0; k < nearestRows[i].length; k++) {
                        for (int l = 0; l < nearestColumns[j].length; l++) {
                            pred[i][j] +=
                                    m_train.value(nearestRows[i][k],
                                                  nearestColumns[j][l]);
                        }
                    }
                    pred[i][j] /=
                            (nearestRows[i].length * nearestColumns[j].length);
                }
            }
        }
        double[][][] pair = new double[2][][];
        pair[0] = pred;
        pair[1] = array.values;
        return pair;
    }


    /**
     * Classifies an instance.
     *
     * @exception Exception if something goes wrong
     */
    public double classifyInstance(Instance a, Instance b) throws Exception {

        if (m_isLeaf) {
            if (m_train == null) {
                throw new Exception("training data not saved in nodes");
            }
            int column = -1;
            int row = -1;
            for (int i = 0; i < m_train.numRows(); i++) {
                if (m_train.rowInstance(i).equals(a)) {
                    row = i;
                    break;
                }
            }
            for (int i = 0; i < m_train.numColumns(); i++) {
                if (m_train.colInstance(i).equals(b)) {
                    column = i;
                    break;
                }
            }

//            if (row != -1 && col != -1) { row = -1; col = -1; }

            /*            int[] nearestRow = nearestRow(row, a, 10);
                        int[] nearestCol = nearestColumn(column, b, 10);

                        double pred = 0;
                        for (int i = 0; i < nearestRow.length; i++) {
                            for (int j = 0; j < nearestCol.length; j++) {
             pred += m_train.value(nearestRow[i], nearestCol[j]);
                            }
                        }
                        return pred / (nearestRow.length * nearestCol.length);
             */
            if (column == -1 && row == -1) {
                return m_stat.avg();
            } else if (column == -1) {
                return m_stat.rowAvg(row);
            } else if (row == -1) {
                return m_stat.colAvg(column);
            } else {
                return m_stat.colAvg(column);
            }
            /*
                        } else if (this.parent == null) {
                            return m_stat.avg();
                        } else if (this.parent.m_localModel.hSplit()) {
                            return m_stat.colAvg(column);
                        } else {
                            return m_stat.rowAvg(row);
                        }
             */
        } else {
            int treeIndex = m_localModel.whichSubset(a, b);
            if ((m_localModel.hSplit() && m_localModel.isFuzzy(a)) ||
                (!m_localModel.hSplit() && m_localModel.isFuzzy(b))) {
                return m_localModel.m_good[treeIndex] *
                        m_sons[treeIndex].classifyInstance(a, b) / 100.0
                        + (100.0 - m_localModel.m_good[treeIndex]) * m_sons[1 -
                        treeIndex].classifyInstance(a, b) / 100.0;
            } else {
                return m_sons[treeIndex].classifyInstance(a, b);
            }
        }
    }

    int[] nearestRow(int row, Instance a, int n) {
        if (row != -1) {
            return new int[] {row};
        } else {
            int[] nearest = new int[n];
            double[] dist = new double[n];
            int maxIndex = 0;
            double maxV = Double.MAX_VALUE;
            java.util.Arrays.fill(dist, maxV);
            for (int i = 0; i < m_train.numRows(); i++) {
                Instance r = m_train.rowInstance(i);
                if (a.equals(r)) {
                    continue;
                }
                double d = distance(a, r, this.usedRowAtts);
                if (d < maxV) {
                    dist[maxIndex] = d;
                    nearest[maxIndex] = i;
                    maxIndex = 0;
                    for (int j = 1; j < dist.length; j++) {
                        if (dist[j] > dist[maxIndex]) {
                            maxIndex = j;
                        }
                    }
                    maxV = dist[maxIndex];
                }
            }
            return nearest;
        }
    }


    int[] nearestColumn(int col, Instance b, int n) {
        if (col != -1) {
            return new int[] {col};
        } else {
            int[] nearest = new int[n];
            double[] dist = new double[n];
            int maxIndex = 0;
            double maxV = Double.MAX_VALUE;
            java.util.Arrays.fill(dist, maxV);
            for (int i = 0; i < m_train.numColumns(); i++) {
                Instance c = m_train.colInstance(i);
                if (c.equals(b)) {
                    continue;
                }
                double d = distance(b, c, this.usedColAtts);
                if (d < maxV) {
                    dist[maxIndex] = d;
                    nearest[maxIndex] = i;
                    maxIndex = 0;
                    for (int j = 1; j < dist.length; j++) {
                        if (dist[j] > dist[maxIndex]) {
                            maxIndex = j;
                        }
                    }
                    maxV = dist[maxIndex];
                }
            }
            return nearest;
        }
    }

    double distance(Instance a, Instance b, BitSet indices) {
        double d = 0;
        double[] attA = a.getAttributes();
        double[] attB = b.getAttributes();
        if (indices.isEmpty()) {
            for (int i = 0; i < a.numAttributes(); i++) {
                d += (attA[i] - attB[i]) * (attA[i] - attB[i]);
            }
        } else {
            for (int i = indices.nextSetBit(0); i != -1;
                         i = indices.nextSetBit(i + 1)) {
                d += (attA[i] - attB[i]) * (attA[i] - attB[i]);
            }
        }
        return d;
    }


    public int numInstances() {
        return m_stat.nRows;
    }

    public void resetStat(Array data) {
        m_stat = new Stat(data);
    }

    public void printLeaves(String filePrefix, boolean leafStubOnly) throws
            IOException {
        if (m_isLeaf) {
            String fileName = filePrefix + "_n" + m_id + ".dat";
            PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(
                    fileName)));
            out.print(m_train.toString(leafStubOnly));
            out.flush();
            out.close();
        } else {
            for (int i = 0; i < m_sons.length; i++) {
                m_sons[i].printLeaves(filePrefix, leafStubOnly);
            }
        }
    }

    public double[][] finalDataMatrix() {

        if (m_isLeaf) {
            m_train.compactify();
            return m_train.values;
        } else {
            double[][] newMatrix = m_sons[0].finalDataMatrix();
            for (int i = 1; i < m_sons.length; i++) {
                if (m_localModel.hSplit()) {
                    newMatrix = mergeRow(m_sons[i].finalDataMatrix(), newMatrix);
                } else {
                    newMatrix = mergeCol(newMatrix, m_sons[i].finalDataMatrix());
                }
            }
            return newMatrix;
        }
    }

    public double[][] mergeRow(double[][] m1, double[][] m2) {
        if (m1.length == 0) {
            return m2;
        }
        if (m2.length == 0) {
            return m1;
        }
        double[][] newMatrix = new double[m1.length +
                               m2.length][max(m1[0].length, m2[0].length)];
        for (int i = 0; i < m1.length; i++) {
            Arrays.fill(newMatrix[i], Double.NaN);
            if ((this.level > 0 && i < m1.length - 1) || i < m1.length - 2) {
                System.arraycopy(m1[i], 0, newMatrix[i], 0, m1[i].length);
            }
        }
        int j = m1.length;
//        Arrays.fill(newMatrix[j++], Double.NaN);
        for (int i = 0; i < m2.length; i++, j++) {
            Arrays.fill(newMatrix[j], Double.NaN);
            if ((this.level > 0 && i > 0) || i > 1) {
                System.arraycopy(m2[i], 0, newMatrix[j], 0, m2[i].length);
            }
        }
        return newMatrix;
    }

    public double[][] mergeCol(double[][] m1, double[][] m2) {
        double[][] newMatrix = new double[max(m1.length, m2.length)][m1[0].
                               length + m2[0].length];
        for (int i = 0; i < newMatrix.length; i++) {
            Arrays.fill(newMatrix[i], Double.NaN);
        }
        for (int i = 0; i < m1.length; i++) {
            if (level <= 4) {
                System.arraycopy(m1[i], 0, newMatrix[i], 0, m1[i].length - 1);
            } else {
                System.arraycopy(m1[i], 0, newMatrix[i], 0, m1[i].length);
            }
        }
        int j = m1[0].length;
        for (int i = 0; i < m2.length; i++) {
            System.arraycopy(m2[i], 1, newMatrix[i], j + 1, m2[i].length - 1);
        }
        return newMatrix;
    }

    private int max(int a, int b) {
        return a > b ? a : b;
    }

    public double SS() {
        return m_stat.SS();
    }

    public double SS2() {
        return m_stat.SS2();
    }

    public double SS3r() {
        return m_stat.SS3r();
    }

    public double SS3c() {
        return m_stat.SS3c();
    }

    public double SS2RatioScore() {
        return m_stat.SS2() / m_stat.var();
    }

    public double SS3rRatioScore() {
        return m_stat.SS3r() / m_stat.var();
    }

    public double SS3cRatioScore() {
        return m_stat.SS3c() / m_stat.var();
    }

    public double SSInTree() {
        double v = 0;
        if (m_isLeaf) {
            v = m_stat.SS();
        } else {
            for (int i = 0; i < m_sons.length; i++) {
                v += m_sons[i].SSInTree();
            }
        }
        return v;
    }

    public double SS2InTree() {
        double v = 0;
        if (m_isLeaf) {
            v = m_stat.SS2();
        } else {
            for (int i = 0; i < m_sons.length; i++) {
                v += m_sons[i].SS2InTree();
            }
        }
        return v;
    }

    public double SS3rInTree() {
        double v = 0;
        if (m_isLeaf) {
            v = m_stat.SS3r();
        } else {
            for (int i = 0; i < m_sons.length; i++) {
                v += m_sons[i].SS3rInTree();
            }
        }
        return v;
    }

    public double SS3cInTree() {
        double v = 0;
        if (m_isLeaf) {
            v = m_stat.SS3c();
        } else {
            for (int i = 0; i < m_sons.length; i++) {
                v += m_sons[i].SS3cInTree();
            }
        }
        return v;
    }

    public double SS2RatioScoreInTree() {
        double v = 0;
        if (m_isLeaf) {
            v = this.SS2RatioScore();
        } else {
            for (int i = 0; i < m_sons.length; i++) {
                v += m_sons[i].SS2RatioScoreInTree();
            }
        }
        return v;
    }


    public double SS3rRatioScoreInTree() {
        double v = 0;
        if (m_isLeaf) {
            v = this.SS3rRatioScore();
        } else {
            for (int i = 0; i < m_sons.length; i++) {
                v += m_sons[i].SS3rRatioScoreInTree();
            }
        }
        return v;
    }

    public double SS3cRatioScoreInTree() {
        double v = 0;
        if (m_isLeaf) {
            v = this.SS3cRatioScore();
        } else {
            for (int i = 0; i < m_sons.length; i++) {
                v += m_sons[i].SS3cRatioScoreInTree();
            }
        }
        return v;
    }

    public int dataSize() {
        return m_stat.nRows() * m_stat.nColumns();
    }

    public Node[] getLeaves() {
        if (this.m_isLeaf) {
            return new Node[] {this};
        } else {
            Node[][] leaves = new Node[m_sons.length][];
            int n = 0;
            for (int i = 0; i < m_sons.length; i++) {
                leaves[i] = m_sons[i].getLeaves();
                n += leaves[i].length;
            }
            Node[] lea = new Node[n];
            n = 0;
            for (int i = 0; i < m_sons.length; i++) {
                System.arraycopy(leaves[i], 0, lea, n, leaves[i].length);
                n += leaves[i].length;
            }
            return lea;
        }
    }


    /* return the set of internal nodes whose both children are leaves */
    public Vector getOuterNodes() {
        if (this.m_isLeaf) {
            return null;
        } else {
            if (isOuter()) {
               Vector v = new Vector();
               v.add(this);
               return v;
            }
            Vector leaves = new Vector();
            for (int i = 0; i < m_sons.length; i++) {
               if (!m_sons[i].m_isLeaf) {
                  leaves.addAll(m_sons[i].getOuterNodes());
               }
            }
            return leaves;
        }
    }

    /* check if a node is an outer node */
    boolean isOuter() {
        if (this.m_isLeaf) return false;
        for (int i = 0; i < m_sons.length; i++) {
           if (!m_sons[i].m_isLeaf) return false;
        }
        return true;
    }


    public double[][] surrogateInfo() throws Exception {
        double[] rowSurro = (m_localModel.hSplit && !m_isLeaf) ? surrogateSplit() :
                            new double[m_train.numRowAttributes()];
        double[] colSurro = (!m_localModel.hSplit && !m_isLeaf) ?
                            surrogateSplit() :
                            new double[m_train.numColAttributes()];
        for (int i = 0; !m_isLeaf && i < m_sons.length; i++) {
            double[][] info = m_sons[i].surrogateInfo();
            for (int j = 0; j < info[0].length; j++) {
                rowSurro[j] += info[0][j];
            }
            for (int j = 0; j < info[1].length; j++) {
                colSurro[j] += info[1][j];
            }
        }
        double[][] surro = new double[2][];
        surro[0] = rowSurro;
        surro[1] = colSurro;
        return surro;
    }

    public double[] surrogateSplit() throws Exception {
        if (m_isLeaf || !m_localModel.checkModel()) {
            return null;
        }
        if (m_sons == null || m_sons.length == 0) {
            throw new RuntimeException("have not been splitted!");
        }
        Array a = new Array(m_sons[0].m_train);
        Array b = new Array(m_sons[1].m_train);

        double[] gains = null;
        if (m_localModel.hSplit()) {
            gains = new double[m_train.numRowAttributes()];
            for (int i = 0; i < m_train.numRowAttributes(); i++) {
                if (i == ((BinSplit) m_localModel).attIndex()) {
                    gains[i] = m_localModel.gain();
                } else {
                    a.sortInstancesRow(i);
                    b.sortInstancesRow(i);
                    double[] att1 = new double[a.numRows()];
                    double[] att2 = new double[b.numRows()];
                    for (int j = 0; j < att1.length; j++) {
                        att1[j] = a.rowInstance(j).getAttributes()[i];
                    }
                    for (int j = 0; j < att2.length; j++) {
                        att2[j] = b.rowInstance(j).getAttributes()[i];
                    }
                    double point = surrogatePoint(att1, att2);
                    BinSplit bs = (BinSplit) m_localModel.getClass().
                                  newInstance();
                    bs.m_attIndex = i;
                    bs.hSplit = m_localModel.hSplit;
                    bs.m_splitPoint = point;
                    bs.m_numSubsets = 2;
                    Array[] localArray = bs.hSplit(m_train);
                    if (localArray[0].size() == 0 || localArray[1].size() == 0) {
                        gains[i] = 0;
                    } else {
                        gains[i] = bs.gain(m_train, localArray);
                        if (BDTree.verbose) {
                            System.err.println("surrogate gain for att h." + i +
                                               " at node " + m_id + ": " +
                                               gains[i]);
                        }
                    }
                }
            }
        } else {
            gains = new double[m_train.numColAttributes()];
            for (int i = 0; i < m_train.numColAttributes(); i++) {
                if (i == ((BinSplit) m_localModel).attIndex()) {
                    gains[i] = m_localModel.gain();
                } else {
                    a.sortInstancesColumn(i);
                    b.sortInstancesColumn(i);
                    double[] att1 = new double[a.numColumns()];
                    double[] att2 = new double[b.numColumns()];
                    for (int j = 0; j < att1.length; j++) {
                        att1[j] = a.colInstance(j).getAttributes()[i];
                    }
                    for (int j = 0; j < att2.length; j++) {
                        att2[j] = b.colInstance(j).getAttributes()[i];
                    }
                    double point = surrogatePoint(att1, att2);
                    BinSplit bs = (BinSplit) m_localModel.getClass().
                                  newInstance();
                    bs.m_attIndex = i;
                    bs.hSplit = m_localModel.hSplit;
                    bs.m_splitPoint = point;
                    bs.m_numSubsets = 2;
                    Array[] localArray = bs.vSplit(m_train);
                    if (localArray[0].size() == 0 || localArray[1].size() == 0) {
                        gains[i] = 0;
                    } else {
                        gains[i] = bs.gain(m_train, localArray);
                        if (BDTree.verbose) {
                            System.err.println("surrogate gain for att v." + i +
                                               " at node " + m_id + ": " +
                                               gains[i]);
                        }
                    }
                }
            }
        }
        return gains;
    }

    double surrogatePoint(double[] a, double[] b) {
        int i = 0;
        int j = 0;
        double point = a[0] < b[0] ? a[0] : b[0];
        int mismatch = a.length;
        double bestPoint = point;
        double leastMismatch = mismatch;
        while (i < a.length) {
            while (i < a.length && (j == b.length || a[i] < b[j])) {
                i++;
                mismatch--;
            }
            if (mismatch < leastMismatch) {
                leastMismatch = mismatch;
                if (j != b.length) {
                    bestPoint = b[j];
                } else {
                    bestPoint = Double.MAX_VALUE;
                }
            }
            if (i == a.length) {
                break;
            } while (j < b.length && b[j] <= a[i]) {
                j++;
                mismatch++;
            }
        }
        return bestPoint;
    }

    void asLeaf() {
        this.m_sons = null;
        this.m_isLeaf = true;
        this.m_localModel = new NoSplit();
    }



}
