package bdtree;

import java.io.BufferedReader;
import java.util.StringTokenizer;
import java.util.Vector;

/**
 * This class stores an expression array and associated row and column attributes.
 * <p> Copyright (c) 2004, Washington University in St Louis</p>
 * @author Jianhua Ruan
 * @version $Revision: 1.11 $
 */
public class Array {
    int nRows;
    int nCols;
    Instance[] rows;
    Instance[] columns;
    String[] rowAttributes;
    String[] colAttributes;
    static String[] colAttributesMapped;
    double[][] values;

/* used for normalizing row and column attributes */
    static double[] rowMax;
    static double[] rowMin;
    static double[] colMax;
    static double[] colMin;

/* used for the additional attributes H and V. defined temporarily in the updateInstances func */
//    double[] rowRootMeanErrors = null;
//    double[] colRootMeanErrors = null;

    public Array() {
        nRows = 0;
        nCols = 0;
    }

    public Array(int nR, int nC) {
        this();
        rows = new Instance[nR];
        columns = new Instance[nC];
        values = new double[nR][nC];
    }

    public Array(Array a, boolean headOnly) {
        this(a.nRows, a.nCols);
        this.rowAttributes = a.rowAttributes;
        this.colAttributes = a.colAttributes;
        if (!headOnly) {
            this.nRows = a.nRows;
            this.nCols = a.nCols;
            System.arraycopy(a.rows, 0, this.rows, 0, nRows);
            System.arraycopy(a.columns, 0, this.columns, 0, nCols);
            for (int i = 0; i < nRows; i++) {
                System.arraycopy(a.values[i], 0, this.values[i], 0, nCols);
            }
        }
    }

    public Array(Array a) {
        this(a, false);
    }

    public Array(Array a, boolean copyRow, boolean copyCol) {
        this(a.nRows, a.nCols);
        this.rowAttributes = a.rowAttributes;
        this.colAttributes = a.colAttributes;
        if (copyRow) {
            this.nRows = a.nRows;
            System.arraycopy(a.rows, 0, this.rows, 0, nRows);
        }
        if (copyCol) {
            this.nCols = a.nCols;
            System.arraycopy(a.columns, 0, this.columns, 0, nCols);
        }
    }


    /**
     * format of the data file:
     * <pre>
     * @rows.att
     * rowAttibuteName1,
     * rowAttibuteName2,
     * ...
     * rowAttibuteNamep,
     * @rows
     * mxp matrix of row attribute values
     * @cols.att
     * colAttibuteName1,
     * colAttibuteName2,
     * ...
     * colAttibuteNameq,
     * @cols
     * nxq matrix of col attribute values
     * @data
     * mxn matrix of expression values
     * </pre>
     * @param reader BufferedReader
     * @throws Exception
     */
    public Array(BufferedReader reader) throws Exception {
        this();
        String aLine = null;
        while ((aLine = reader.readLine()) != null) {
            if (aLine.trim().equals("@row.atts")) {
                break;
            }
        }
        if (aLine == null) {
            throw new RuntimeException("unknown format");
        }
        Vector att = new Vector();
        while ((aLine = reader.readLine()) != null) {
            aLine = aLine.trim();
            if (aLine.equals("@rows")) {
                break;
            }
            if (!aLine.equals("")) {
                att.add(aLine);
            }
        }
        /* two additional fields for H and V. See methods updateInstances */
        this.rowAttributes = new String[att.size()];
        this.rowAttributes = (String[]) att.toArray(this.rowAttributes);
//        this.rowAttributes[att.size()] = "H";
//        this.rowAttributes[att.size() + 1] = "V";

        if (aLine == null) {
            throw new RuntimeException("unknown format");
        }
        double[] instAttributes = new double[this.rowAttributes.length];
        Vector rowVector = new Vector();
        while ((aLine = reader.readLine()) != null) {
            aLine = aLine.trim();
            if (aLine.equals("@col.atts")) {
                break;
            }
            if (aLine.equals("")) {
                continue;
            }
            StringTokenizer st = new StringTokenizer(aLine);
            String name = st.nextToken();
            int i = 0;
            while (st.hasMoreTokens()) {
                instAttributes[i++] = Double.parseDouble(st.nextToken());
            }
            if (i != att.size()) {
                throw new RuntimeException(
                        "unexpected end of line when reading rows");
            }
            Instance inst = new Instance(name, instAttributes);
            rowVector.add(inst);
        }
        this.nRows = rowVector.size();
        this.rows = new Instance[nRows];
        this.rows = (Instance[]) rowVector.toArray(rows);
        if (aLine == null) {
            throw new RuntimeException("unknown format");
        }
        att = new Vector();
        Vector map = new Vector();
        while ((aLine = reader.readLine()) != null) {
            aLine = aLine.trim();
            if (aLine.equals("@cols")) {
                break;
            }
            if (!aLine.equals("")) {
                String[] a = aLine.split("\t");
//                att.add(aLine);
                att.add(a[0]);
                if (a.length == 2) {
                    map.add(a[1]);
                }
            }
        }
//        this.colAttributes = new String[2 * att.size() + 2];

        /* two additional fields for H and V. See methods updateInstances */
        this.colAttributes = new String[att.size()];
        this.colAttributes = (String[]) att.toArray(this.colAttributes);
        if (map.size() == att.size()) {
            this.colAttributesMapped = new String[att.size()];
            this.colAttributesMapped = (String[]) map.toArray(this.
                    colAttributesMapped);
        }
//        for (int i = 0; i < att.size(); i++) {
//            this.colAttributes[att.size() + i] = this.colAttribute(i) + ".abs";
//        }
//        this.colAttributes[att.size()] = "H";
//        this.colAttributes[att.size() + 1] = "V";
        instAttributes = new double[this.colAttributes.length];
        Vector colVector = new Vector();
        while ((aLine = reader.readLine()) != null) {
            aLine = aLine.trim();
            if (aLine.equals("@data")) {
                break;
            }
            if (aLine.equals("")) {
                continue;
            }
            StringTokenizer st = new StringTokenizer(aLine);
            String name = st.nextToken();
            int i = 0;
            while (st.hasMoreTokens()) {
                instAttributes[i] = Double.parseDouble(st.nextToken());
//                instAttributes[att.size() + i] = Math.abs(instAttributes[i]);
                i++;
            }
            if (i != att.size()) {
                throw new RuntimeException(
                        "unexpected end of line when reading columns");
            }
            Instance inst = new Instance(name, instAttributes);
            colVector.add(inst);
        }
        this.nCols = colVector.size();
        this.columns = new Instance[nCols];
        this.columns = (Instance[]) colVector.toArray(columns);
        values = new double[nRows][nCols];
        int i = 0;
        while ((aLine = reader.readLine()) != null) {
            aLine = aLine.trim();
            if (aLine.equals("")) {
                continue;
            }
            StringTokenizer st = new StringTokenizer(aLine);
            int j = 0;
            while (st.hasMoreTokens()) {
                values[i][j++] = Double.parseDouble(st.nextToken());
            }
            if (j != nCols) {
                throw new RuntimeException(
                        "unexpected end of line when reading data");
            }
            i++;
        }
        if (i != nRows) {
            throw new RuntimeException(
                    "unexpected end of file when reading data: " + i + " " +
                    nRows + " " + nCols);
        }

        /* normalize row and column attributes */
//        this.normalizeRowAtts();
//        this.normalizeColAtts();

        /* normalize expression values row-wise */
//        this.normalizeRowValues();
    }


    /**
     * Update the H and V fields for each instance
     * called by Node::buildTree
     * @param stat Stat
     */
    protected void updateInstances(Stat stat) {
        double avg = stat.avg();
        double[] rowAvg = stat.rowAvg();
        double[] colAvg = stat.colAvg();
        int nColAttribute = this.numColAttributes();
        double[] rowRootMeanErrors = new double[nRows];
        double[] colRootMeanErrors = new double[nCols];
        for (int i = 0; i < nCols; i++) {
            Instance inst = this.colInstance(i);
            double H = 0;
            double V = 0;
            double s = 0;
            for (int j = 0; j < nRows; j++) {
                double diff = values[j][i] - rowAvg[j] - colAvg[i] + avg;
                double diff3 = values[j][i] - rowAvg[j];
                H += diff * diff;
                V += diff3 * diff3;
                s += values[j][i] * values[j][i];
            }
            colRootMeanErrors[i] = (s - stat.colSum[i] * stat.colSum[i] / nRows);
            inst.setAttribute(nColAttribute - 2, H);
            inst.setAttribute(nColAttribute - 1, V);
        }
        int nRowAttribute = this.numRowAttributes();
        for (int i = 0; i < nRows; i++) {
            Instance inst = this.rowInstance(i);
            double H = 0;
            double V = 0;
            double s = 0;
            for (int j = 0; j < nCols; j++) {
                double diff = values[i][j] - rowAvg[i] - colAvg[j] + avg;
                double diff3 = values[i][j] - colAvg[j];
                H += diff * diff;
                V += diff3 * diff3;
                s += values[i][j] * values[i][j];
            }
            rowRootMeanErrors[i] = (s - stat.rowSum[i] * stat.rowSum[i] / nCols);
            inst.setAttribute(nRowAttribute - 2, H);
            inst.setAttribute(nRowAttribute - 1, V);
        }
    }

    public String rowAttribute(int i) {
        return rowAttributes[i];
    }

    public String colAttribute(int i) {
        return colAttributes[i];
    }

    public void sortInstances(int attIndex, boolean row) {
        if (row) {
            sortInstancesRow(attIndex);
        } else {
            sortInstancesColumn(attIndex);
        }
    }

    public void sortInstancesRow(int i) {
        double[] vals = new double[nRows];
        int j = 0;
        try {
            for (; j < nRows; j++) {
                vals[j] = rows[j].getAttribute(i);
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(j);
        }
        int[] indices = Utils.sort(vals);
        Instance[] newRows = new Instance[nRows];
        double[][] newValues = new double[nRows][];
        for (j = 0; j < nRows; j++) {
            newRows[j] = rows[indices[j]];
            newValues[j] = values[indices[j]];
        }
        rows = newRows;
        values = newValues;
    }

    public void sortInstancesColumn(int i) {
        double[] vals = new double[nCols];
        for (int j = 0; j < nCols; j++) {
            vals[j] = columns[j].getAttribute(i);
        }
        int[] indices = Utils.sort(vals);
        Instance[] newCols = new Instance[nCols];
        double[][] newValues = new double[nRows][nCols];
        for (int j = 0; j < nCols; j++) {
            newCols[j] = columns[indices[j]];
            for (int k = 0; k < nRows; k++) {
                newValues[k][j] = values[k][indices[j]];
            }
        }
        columns = newCols;
        values = newValues;
    }

    public Instance rowInstance(int i) {
        return rows[i];
    }

    public Instance colInstance(int j) {
        return columns[j];
    }

    public double value(int i, int j) {
        return values[i][j];
    }

    /**
     * given row and column instances, look for the corresponding value
     * @param a a row Instance
     * @param b a column Instance
     * @return value if instances found, Double.NaN otherwise
     */
    public double value(Instance a, Instance b) {
        int i = -1;
        for (int r = 0; r < nRows; r++) {
            if (rows[r].equals(a)) {
                i = r;
            }
        }
        int j = -1;
        for (int c = 0; c < nCols; c++) {
            if (columns[c].equals(b)) {
                j = c;
            }
        }
        if (i != -1 && j != -1) {
            return values[i][j];
        }
        return Double.NaN;
    }

    public double[] row(int i) {
        double[] r = new double[nCols];
        System.arraycopy(values[i], 0, r, 0, nCols);
        return r;
    }

    public double[] column(int j) {
        double[] c = new double[nRows];
        for (int i = 0; i < nRows; i++) {
            c[i] = values[i][j];
        }
        return c;
    }

    public int numRows() {
        return nRows;
    }

    public int numColumns() {
        return nCols;
    }

    /**
     * add a row to the data set
     * assumes the new row has the same number of values as old rows,
     * unless the data set is original empty
     * allocate more space if the original row array is full
     * @param inst row Instance
     * @param vals values for the row
     */
    public void addRow(Instance inst, double[] vals) {
        if (nRows == 0) {
            nCols = vals.length;
        } else if (vals.length != nCols) {
            throw new RuntimeException("vals.length != nCols");
        }
        if (rows.length <= nRows) {
            Instance[] newRows = new Instance[nRows + 10];
            System.arraycopy(rows, 0, newRows, 0, nRows);
            rows = newRows;
            double[][] newValues = new double[nRows + 10][nCols];
            System.arraycopy(values, 0, newValues, 0, nRows);
            values = newValues;
        }
        rows[nRows] = inst;
        System.arraycopy(vals, 0, values[nRows++], 0, nCols);
    }

    /**
     * add a column to the data set
     * assumes the new column has the same number of values as old columns,
     * unless the data set is original empty
     * allocate more space if the original column array is full
     * @param inst column Instance
     * @param vals values for the column
     */
    public void addColumn(Instance inst, double[] vals) {
        if (nCols == 0) {
            nRows = vals.length;
        } else if (vals.length != nRows) {
            throw new RuntimeException("vals.length != nRows");
        }
        if (columns.length <= nCols) {
            Instance[] newColumns = new Instance[nCols + 10];
            System.arraycopy(columns, 0, newColumns, 0, nCols);
            columns = newColumns;
            double[][] newValues = new double[nRows][nCols + 10];
            for (int i = 0; i < nRows; i++) {
                System.arraycopy(values[i], 0, newValues[i], 0, nCols);
            }
            values = newValues;
        }
        columns[nCols] = inst;
        for (int i = 0; i < nRows; i++) {
            values[i][nCols] = vals[i];
        }
        nCols++;
    }

    /**
     * remove empty space in the data set
     */
    public void compactify() {
        if (rows.length > nRows) {
            Instance[] newRows = new Instance[nRows];
            System.arraycopy(rows, 0, newRows, 0, nRows);
            rows = newRows;
        }
        if (columns.length > nCols) {
            Instance[] newCols = new Instance[nCols];
            System.arraycopy(columns, 0, newCols, 0, nCols);
            columns = newCols;
        }
        double[][] newValues = new double[nRows][nCols];
        for (int i = 0; i < nRows; i++) {
            System.arraycopy(values[i], 0, newValues[i], 0, nCols);
        }
        values = newValues;
    }

    public int numRowAttributes() {
        return this.rowAttributes.length;
    }

    public int numColAttributes() {
        return this.colAttributes.length;
    }

    /**
     * returns the (n-1)*(n-1) fold subset
     * @param numFolds int
     * @param i int
     * @return Array
     */
    public Array trainCV(int numFolds, int i) {
        return trainCVRow(numFolds, i).trainCVCol(numFolds, i);
    }

    /**
     * returns three arrays: the (n-1) * 1 row subset, 1 * (n-1) column subset,
     * and the 1 * 1 diagonal subset
     * @param numFolds int
     * @param i int
     * @return Array[]
     */
    public Array[] testCV(int numFolds, int i) {
        Array[] test_data = new Array[3];
        test_data[0] = testCVRow(numFolds, i).trainCVCol(numFolds, i);
        test_data[1] = testCVCol(numFolds, i).trainCVRow(numFolds, i);
        test_data[2] = testCVRow(numFolds, i).testCVCol(numFolds, i);
        return test_data;
    }

    public Array trainCVRow(int numFolds, int i) {
        Array a = new Array(this, false, true);
        int foldSize = this.nRows / numFolds;
        int remainder = this.nRows % numFolds;
        int start = foldSize * i + (i < remainder ? i : remainder);
        int end = foldSize * (i + 1) + (i + 1 < remainder ? i + 1 : remainder);
        for (int j = 0; j < start; j++) {
            a.addRow(this.rowInstance(j), this.row(j));
        }
        for (int j = end; j < this.numRows(); j++) {
            a.addRow(this.rowInstance(j), this.row(j));
        }
        return a;
    }

    public Array trainCVCol(int numFolds, int i) {
        Array a = new Array(this, true, false);
        int foldSize = this.nCols / numFolds;
        int remainder = this.nCols % numFolds;
        int start = foldSize * i + (i < remainder ? i : remainder);
        int end = foldSize * (i + 1) + (i + 1 < remainder ? i + 1 : remainder);
        for (int j = 0; j < start; j++) {
            a.addColumn(this.colInstance(j), this.column(j));
        }
        for (int j = end; j < this.numColumns(); j++) {
            a.addColumn(this.colInstance(j), this.column(j));
        }
        return a;
    }

    public Array testCVRow(int numFolds, int i) {
        Array a = new Array(this, false, true);
        int foldSize = this.nRows / numFolds;
        int remainder = this.nRows % numFolds;
        int start = foldSize * i + (i < remainder ? i : remainder);
        int end = foldSize * (i + 1) + (i + 1 < remainder ? i + 1 : remainder);
        for (int j = start; j < end; j++) {
            a.addRow(this.rowInstance(j), this.row(j));
        }
        return a;
    }

    public Array testCVCol(int numFolds, int i) {
        Array a = new Array(this, true, false);
        int foldSize = this.nCols / numFolds;
        int remainder = this.nCols % numFolds;
        int start = foldSize * i + (i < remainder ? i : remainder);
        int end = foldSize * (i + 1) + (i + 1 < remainder ? i + 1 : remainder);
        for (int j = start; j < end; j++) {
            a.addColumn(this.colInstance(j), this.column(j));
        }
        return a;
    }

    /**
     * randomize the data set
     * move the rows and columns along with their attributes
     * @param random Random
     */
    public void randomize(java.util.Random random) {
        for (int j = numRows() - 1; j > 0; j--) {
            swapRow(j, (int) (random.nextDouble() * (double) j));
        }
        for (int j = numColumns() - 1; j > 0; j--) {
            swapColumn(j, (int) (random.nextDouble() * (double) j));
        }
    }

    private void swapRow(int i, int j) {
        double[] tempVal = values[i];
        values[i] = values[j];
        values[j] = tempVal;
        Instance tempInst = rows[i];
        rows[i] = rows[j];
        rows[j] = tempInst;
    }

    private void swapColumn(int i, int j) {
        for (int k = 0; k < this.nRows; k++) {
            double tempVal = values[k][i];
            values[k][i] = values[k][j];
            values[k][j] = tempVal;
        }
        Instance tempInst = columns[i];
        columns[i] = columns[j];
        columns[j] = tempInst;
    }

    public String toString() {
        return toString(false);
    }

    public String toString(boolean headOnly) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < this.numColumns(); i++) {
            sb.append("\t" + this.colInstance(i).getName());
        }
        sb.append("\n");
        for (int i = 0; i < this.numRows(); i++) {
            sb.append(this.rowInstance(i).getName());
            if (!headOnly) {
                for (int j = 0; j < this.numColumns(); j++) {
                    sb.append("\t" + this.value(i, j));
                }
            }
            sb.append("\n");
        }
        return sb.toString();
    }


    /**
     * normalize the values for each row attribute
     * called in Array(BufferedReader)
     */
    public void normalizeRowAtts() {
        rowMin = new double[this.rowAttributes.length];
        rowMax = new double[this.rowAttributes.length];
        java.util.Arrays.fill(rowMin, Double.MAX_VALUE);
        java.util.Arrays.fill(rowMax, Double.MIN_VALUE);
        for (int i = 0; i < rows.length; i++) {
            for (int j = 0; j < rowMin.length; j++) {
                double v = rows[i].getAttribute(j);
                if (v > rowMax[j]) {
                    rowMax[j] = v;
                }
                if (v < rowMin[j]) {
                    rowMin[j] = v;
                }
            }
        }
        for (int i = 0; i < rows.length; i++) {
            for (int j = 0; j < rowMin.length; j++) {
                double v = rows[i].getAttribute(j);
                rows[i].setAttribute(j, norm(v, rowMin[j], rowMax[j]));
            }
        }
        System.err.println("row att normalized");
    }

    /**
     * normalize the values for each column attribute
     * called in Array(BufferedReader)
     */
    public void normalizeColAtts() {
        colMin = new double[this.colAttributes.length];
        colMax = new double[this.colAttributes.length];
        java.util.Arrays.fill(colMin, Double.MAX_VALUE);
        java.util.Arrays.fill(colMax, Double.MIN_VALUE);
        for (int i = 0; i < columns.length; i++) {
            for (int j = 0; j < colMin.length; j++) {
                double v = columns[i].getAttribute(j);
                if (v > colMax[j]) {
                    colMax[j] = v;
                }
                if (v < colMin[j]) {
                    colMin[j] = v;
                }
            }
        }
        for (int i = 0; i < columns.length; i++) {
            for (int j = 0; j < colMin.length; j++) {
                double v = columns[i].getAttribute(j);
                columns[i].setAttribute(j, norm(v, colMin[j], colMax[j]));
            }
        }
        System.err.println("col att normalized");
    }


    /**
     * normalize a value according to max and min values
     * @param v double
     * @param min double
     * @param max double
     * @return double
     */
    double norm(double v, double min, double max) {
        if (v < min || v > max) {
            throw new RuntimeException("error in normalization!");
        }
        if (min == max) {
            return .0;
        }
        return (v - min) / (max - min);
    }

    /**
     * normalize the expression matrix row-wise
     */
    public void normalizeRowValues() {
        for (int i = 0; i < values.length; i++) {
            double[] v = values[i];
            double avg = Stat.average(v);
            double stdev = Stat.stdev(v);
            for (int j = 0; j < v.length; j++) {
                values[i][j] = (values[i][j] - avg) / stdev;
            }
        }
    }

    public int size() {
        return nRows * nCols;
    }

    /**
     * reverse the effect of normalizeRowAtts().
     * This is to ensure the threshold used for prediction is valid for new instances
     * called by BinSplit::rightSide
     * @param i int
     * @param x double
     * @return double
     */
    double restoreRowAtt(int i, double x) {
//        if (rowMax == null || rowMin == null) return x;
        return (rowMax[i] - rowMin[i]) * x + rowMin[i];
    }

    /**
     * reverse the effect of normalizeColAtts()
     * called by BinSplit::rightSide
     * @param i int
     * @param x double
     * @return double
     */
    double restoreColAtt(int i, double x) {
//        if (colMax == null || colMin == null) return x;
        return (colMax[i] - colMin[i]) * x + colMin[i];
    }

}
