package bdtree;

import java.io.Serializable;
import java.util.*;

/**
 * <p> Copyright (c) 2004</p>
 *
 * <p> Washington University in St Louis</p>
 *
 * @author Jianhua Ruan
 * @version 1.0
 */

public class ClusterModelSelection extends ModelSelection {

    static int[][] neighbors = null;

    /**
     * Initializes the split selection method with the given parameters.
     *
     * @param m_minNoObj minimum number of instances that have to occur in at least two
     * subsets induced by split
     */
    public ClusterModelSelection(int minNoRow, int minNoCol) {
        super(minNoRow, minNoCol);
    }

    /**
     * Selects a split for the given dataset.
     */
    public NodeSplitModel selectModel(Array data, Stat stat) {
        BinSplit currentModel;

        double r = data.numRows();

        double hGain = 0;
        BinSplit bestHModel = null;

/*        if (stat.avgVar() <= 1e-5) {
            return new NoSplit();
        }
*/
        BinSplit[] models = new BinSplit[data.numRowAttributes()];
        if (r >= 2 * m_minNoRow) {
            for (int i = 0; i < data.numRowAttributes(); i++) {
                currentModel = new BinSplit_row_or_column_variance(i,
                            m_minNoRow, true);
                currentModel.buildClassifier(data, stat);
                if (currentModel.checkModel()) {
                    models[i] = currentModel;
                    if (currentModel.gain() > hGain) {
                        bestHModel = currentModel;
                        hGain = currentModel.gain();
                    }
                }
            }
        }

        if (bestHModel == null) {
            return new NoSplit();
        }

        if (neighbors == null) {
            WordNeighbor wn = new WordNeighbor();
            neighbors = wn.findNeighbors(data.rowAttributes);
            wn = null;
        }

        int[] nb = neighbors[bestHModel.attIndex()];
        ArrayList nbModels = new ArrayList();
        nbModels.add(bestHModel);
        for (int i = 0; i < nb.length; i++) {
            if (models[nb[i]] != null) {
                nbModels.add(models[nb[i]]);
            }
        }

        ClusterBinSplit cModel = new ClusterBinSplit(m_minNoRow, true, nbModels);
        cModel.buildClassifier(data, stat);
        if (cModel.models.size() > 1) return cModel;
        return bestHModel;
    }

}
