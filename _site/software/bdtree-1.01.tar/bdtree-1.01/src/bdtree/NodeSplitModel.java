package bdtree;

import java.io.Serializable;

/**
 * <p> Copyright (c) 2004</p>
 *
 * <p> Washington University in St Louis</p>
 *
 * @author Jianhua Ruan
 * @version 1.0
 */

public abstract class NodeSplitModel implements Cloneable, Serializable, Comparable {

    /** Number of created subsets. */
    protected int m_numSubsets;
    protected double m_gain = 0;
    protected boolean hSplit = true;
    protected int[] m_good = null;

    double FILTER = 1.0;

    /**
     * Allows to clone a model (shallow copy).
     */
    public Object clone() {

        Object clone = null;

        try {
            clone = super.clone();
        } catch (CloneNotSupportedException e) {
        }
        return clone;
    }

    /**
     * Builds the classifier split model for the given set of instances.
     */
    abstract public void buildClassifier(Array data, Stat stat);

    /**
     * Checks if generated model is valid.
     */
    public final boolean checkModel() {

        if (m_numSubsets > 0) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Returns coding costs of model. Returns 0 if not overwritten.
     */
    public double codingCost() {

        return 0;
    }

    /**
     * Returns the distribution of class values induced by the model.
     */
    public final double gain() {
        return m_gain;
    }

    /**
     * Prints left side of condition satisfied by instances.
     *
     * @param data the data.
     */
    abstract public String leftSide(Array data);

    /**
     * Prints left side of condition satisfied by instances in subset index.
     */
    abstract public String rightSide(int index, Array data);

    /**
     * Returns the number of created subsets for the split.
     */
    public final int numSubsets() {

        return m_numSubsets;
    }

    /**
     * Splits the given set of instances into subsets.
     *
     * @exception Exception if something goes wrong
     */
    public final Array[] split(Array data) {
        if (hSplit) {
            return hSplit(data);
        } else {
            return vSplit(data);
        }
    }

    public final Array[] hSplit(Array data) {
        Array[] subarrays = new Array[m_numSubsets];
        Instance instance;
        int i;

        Stat[] stats = new Stat[m_numSubsets];
        int[] allFit = new int[m_numSubsets];
        int[] goodFit = new int[m_numSubsets];
        int[] branch = new int[data.numRows()];
        if (m_good == null) {
            m_good = new int[m_numSubsets];
        }
        for (i = 0; i < m_numSubsets; i++) {
            subarrays[i] = new Array(data, false, true);
            stats[i] = new Stat(data.numRows(), data.numColumns());
        }

        for (i = 0; i < data.numRows(); i++) {
            instance = data.rowInstance(i);
            int subset = whichSubset(instance);
            if (subset > -1) {
                subarrays[subset].addRow(instance, data.row(i));
                branch[i] = subset;
                if (isFuzzy(instance)) {
                    allFit[subset]++;
                }
            } else {
                throw new RuntimeException("missing value not supported yet");
            }
        }

        // it is possible to enter with emptySet if fuzzy split and prunable nodes was used
        boolean emptySet = false;
        for (i = 0; i < m_numSubsets; i++) {
            if (subarrays[i].numRows() == 0) {
                emptySet = true;
            }
        }

        if (BDTree.fuzzy != 0) {
            // it is possible to enter with emptySet if fuzzy split and prunable nodes was used
            for (int k = 0; k < 1 && !emptySet; k++) {
                for (i = 0; i < m_numSubsets; i++) {
                    stats[i] = new Stat(subarrays[i]);
                    subarrays[i] = new Array(data, false, true);
                    goodFit[i] = allFit[i];
                }
                System.gc();
                double[][] colAverages = new double[m_numSubsets][];
                for (i = 0; i < m_numSubsets; i++) {
                    colAverages[i] = stats[i].colAvg();
                }
                for (i = 0; i < data.numRows(); i++) {
                    instance = data.rowInstance(i);
                    int subset = branch[i];
                    if (isFuzzy(instance) && subset == 1) {
                        subset = closest(data.row(i), colAverages);
                    }
                    subarrays[subset].addRow(instance, data.row(i));
                    if (subset != branch[i]) {
                        goodFit[branch[i]]--;
                    }
                }
                for (i = 0; i < m_numSubsets; i++) {
                    if (subarrays[i].numRows() == 0) {
                        emptySet = true;
                        break;
                    }
                }
            }
            if (emptySet) {
                for (i = 0; i < m_numSubsets; i++) {
                    subarrays[i] = new Array(data, false, true);
                    goodFit[i] = allFit[i];
                }
                for (i = 0; i < data.numRows(); i++) {
                    instance = data.rowInstance(i);
                    subarrays[branch[i]].addRow(instance, data.row(i));
                }
            }

        }
        for (i = 0; i < m_numSubsets; i++) {
            if (BDTree.fuzzy != 0 && allFit[i] > 0) {
                m_good[i] = (goodFit[i] * 100) / allFit[i];
            } else {
                m_good[i] = 100;
            }
            subarrays[i].compactify();
        }

        return subarrays;
    }

    int closest(double[] a, double[][] A) {
        double min = Double.MAX_VALUE;
        int x = -1;
        for (int i = 0; i < A.length; i++) {
            double currentdist = dist(a, A[i]);
            if (currentdist < min) {
                min = currentdist;
                x = i;
            }
        }
        if (x == -1) {
            System.err.println("what's going on? ");
            for (int i = 0; i < A.length; i++) {
                for (int j = 0; j < A[i].length; j++) {
                    System.err.print(A[i][j] + " ");
                }
                System.out.println();
            }
            System.exit(0);
        }
        return x;
    }

    double dist(double[] a, double[] b) {
        double distance = 0;
        for (int i = 0; i < a.length; i++) {
            distance += (a[i] - b[i]) * (a[i] - b[i]);
        }
        return distance;
    }

    public final Array[] vSplit(Array data) {
        Array[] subarrays = new Array[m_numSubsets];
        Instance instance;
        int i;

        Stat[] stats = new Stat[m_numSubsets];
        int[] goodFit = new int[m_numSubsets];
        int[] allFit = new int[m_numSubsets];
        int[] branch = new int[data.numColumns()];
        if (m_good == null) {
            m_good = new int[m_numSubsets];
        }
        for (i = 0; i < m_numSubsets; i++) {
            subarrays[i] = new Array(data, true, false);
            stats[i] = new Stat(data.numRows(), data.numColumns());
        }
        for (i = 0; i < data.numColumns(); i++) {
            instance = data.colInstance(i);
            int subset = whichSubset(instance);
            if (subset > -1) {
                subarrays[subset].addColumn(instance, data.column(i));
                branch[i] = subset;
                if (isFuzzy(instance)) {
                    allFit[subset]++;
                }
            } else {
                throw new RuntimeException("missing value not supported yet");
            }
        }

        // it is possible to enter with emptySet if fuzzy split and prunable nodes was used
        boolean emptySet = false;
        for (i = 0; i < m_numSubsets; i++) {
            if (subarrays[i].numColumns() == 0) {
                emptySet = true;
            }
        }

        if (BDTree.fuzzy != 0) {
            for (int k = 0; k < 1 && !emptySet; k++) {
                for (i = 0; i < m_numSubsets; i++) {
                    stats[i] = new Stat(subarrays[i]);
                    subarrays[i] = new Array(data, true, false);
                    goodFit[i] = allFit[i];
                }
                System.gc();
                double[][] rowAverages = new double[m_numSubsets][];
                for (i = 0; i < m_numSubsets; i++) {
                    rowAverages[i] = stats[i].rowAvg();
                }
                for (i = 0; i < data.numColumns(); i++) {
                    instance = data.colInstance(i);
                    int subset = branch[i];
                    if (isFuzzy(instance)) {
                        subset = closest(data.column(i), rowAverages);
                    }
                    subarrays[subset].addColumn(instance, data.column(i));
                    if (subset != branch[i]) {
                        goodFit[branch[i]]--;
                    }
                }
                for (i = 0; i < m_numSubsets; i++) {
                    if (subarrays[i].numColumns() == 0) {
                        emptySet = true;
                        break;
                    }
                }
            }
            if (emptySet) {
                for (i = 0; i < m_numSubsets; i++) {
                    subarrays[i] = new Array(data, true, false);
                    goodFit[i] = allFit[i];
                }
                for (i = 0; i < data.numColumns(); i++) {
                    instance = data.colInstance(i);
                    subarrays[branch[i]].addColumn(instance, data.column(i));
                }
            }
        }
        for (i = 0; i < m_numSubsets; i++) {
            if (BDTree.fuzzy != 0 && allFit[i] > 0) {
                m_good[i] = (goodFit[i] * 100) / allFit[i];
            } else {
                m_good[i] = 100;
            }
            subarrays[i].compactify();
        }

        return subarrays;
    }

    /**
     * Returns index of subset instance is assigned to.
     * Returns -1 if instance is assigned to more than one subset.
     *
     * @exception Exception if something goes wrong
     */
    abstract public int whichSubset(Instance instance);

    abstract public boolean isFuzzy(Instance instance);

    public int whichSubset(Instance a, Instance b) {
        if (hSplit) {
            return whichSubset(a);
        }
        return whichSubset(b);
    }

    public boolean hSplit() {
        return hSplit;
    }

    public int compareTo(Object b) {
        if (this.m_gain < ((NodeSplitModel)b).m_gain) {
            return 1;
        }
        if (this.m_gain > ((NodeSplitModel)b).m_gain) {
            return -1;
        }
        return 0;
    }



}
