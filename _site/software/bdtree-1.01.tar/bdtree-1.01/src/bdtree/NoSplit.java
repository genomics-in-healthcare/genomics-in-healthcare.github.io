package bdtree;

/**
 * <p> Copyright (c) 2004</p>
 *
 * <p> Washington University in St Louis</p>
 *
 * @author Jianhua Ruan
 * @version 1.0
 */

public final class NoSplit extends NodeSplitModel {

    /**
     * Creates "no-split"-split for given distribution.
     */
    public NoSplit() {
        m_numSubsets = 1;
    }

    /**
     * Creates a "no-split"-split for a given set of instances.
     *
     * @exception Exception if split can't be built successfully
     */
    public final void buildClassifier(Array data, Stat stat) {
        m_numSubsets = 1;
    }

    /**
     * Always returns 0 because only there is only one subset.
     */
    public final int whichSubset(Instance instance) {
        return 0;
    }

    /**
     * Does nothing because no condition has to be satisfied.
     */
    public final String leftSide(Array data) {

        return "";
    }

    /**
     * Does nothing because no condition has to be satisfied.
     */
    public final String rightSide(int index, Array data) {
        return "";
    }

    public final boolean isFuzzy(Instance a) {
        return false;
    }

}
