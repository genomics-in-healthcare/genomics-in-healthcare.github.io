package bdtree;

import java.io.*;
import java.util.*;

/**
 * This class is the starting point for the BDTree program
 * <p> Copyright (c) 2004, Washington University in St Louis</p>
 * @author Jianhua Ruan
 * @version $Revision: 1.8 $
 */
public class BDTree implements OptionHandler {

    /** The decision tree */
    private Node m_root;

    /** Minimum number of rows (default 5) */
    private int m_minNumRow = 5;
    /** Minimum number of columns (default 5) */
    private int m_minNumCol = 5;

    /** Unpruned tree? */
    private boolean m_unpruned = true;

    /** reduced error pruning */
    private boolean m_reducedError = false;
    /** Subtree raising to be performed? */
    private boolean m_subtreeRaising = false;

    /** confidence factor, unused currently */
    private float m_CF = 0.02f;

    private int m_maxNumLeaves = Integer.MAX_VALUE;

    /** output rules instead of tree */
    boolean m_outputRules = false;

    protected static int fuzzy = 0;
    protected static int split = 2;
    protected static boolean rowFirst = false;
    protected static boolean diffRowCol = true;
    protected static boolean verbose = false;
    protected static boolean knn = false;
    protected static boolean cluster = false;

    public BDTree() {
        /* initiate variable for the experimental features */
        String property = System.getProperty("split");
        if (property != null && !property.equals("")) {
            split = Integer.parseInt(property);
        }
        property = System.getProperty("fuzzy");
        if (property != null && !property.equals("")) {
            fuzzy = Integer.parseInt(property);
        }
        property = System.getProperty("rowFirst");
        if (property != null) {
            rowFirst = true;
        }
        property = System.getProperty("noDiff");
        if (property != null) {
            diffRowCol = false;
        }
        property = System.getProperty("knn");
        if (property != null) {
            knn = true;
        }
        property = System.getProperty("cluster");
        if (property != null) {
            cluster = true;
        }
    }


    public BDTree(BDTree copy) {
        this.m_root = null;
        this.m_unpruned = copy.m_unpruned;
        this.m_minNumRow = copy.m_minNumRow;
        this.m_minNumCol = copy.m_minNumCol;
        this.m_subtreeRaising = copy.m_subtreeRaising;
        this.m_outputRules = copy.m_outputRules;
        this.m_CF = copy.m_CF;
    }

    /**
     * Generates the classifier.
     *
     * @exception Exception if classifier can't be built successfully
     */
    public void buildClassifier(Array array) throws Exception {
        ModelSelection modSelection = null;
        if (BDTree.cluster)
            modSelection = new ClusterModelSelection(m_minNumRow, m_minNumCol);
        else
            modSelection = new ModelSelection(m_minNumRow, m_minNumCol);
        if (m_unpruned) {
            m_root = new Node(modSelection);
        } else if (m_reducedError) {
            m_root = new CVPruneableNode(modSelection, !m_unpruned);
        } else {
            m_root = new PruneableNode(modSelection, !m_unpruned, m_CF, m_subtreeRaising);

        }
        m_root.buildClassifier(array);
        if (m_maxNumLeaves != Integer.MAX_VALUE) {
            prune(m_maxNumLeaves);
        }
    }

    private void prune(int maxNumLeaves) {
        Collection outerNodes = m_root.getOuterNodes();
        int n = m_root.numNodes();
        int nLeaves = (n+1)/2;
        if (nLeaves <= maxNumLeaves) return;
        SortedSet set = new TreeSet(new Comparator() {
           public int compare(Object o1, Object o2) {
               Node n1 = (Node)o1;
               Node n2 = (Node)o2;
               double g1 = n1.m_localModel.gain();
               double g2 = n2.m_localModel.gain();
               if (g1 < g2) return -1;
               if (g1 > g2) return 1;
               return 0;
           }
        });
        set.addAll(outerNodes);
        while (nLeaves > maxNumLeaves) {
           Node node = (Node)set.first();
           if (BDTree.verbose) {
               System.err.println("gain = " + node.m_localModel.gain());
           }
           set.remove(node);
           if (nLeaves > maxNumLeaves) {
               node.asLeaf();
           }
           nLeaves--;
//           if (nLeaves == 1) break;
           Node parent = node.parent;
           if (parent != null && parent.isOuter()) {
              set.add(parent);
           }
        }
    }

    /**
     * experimental feature. apply K-means to the expression array, using current partitioning as seed.
     * called in  Evaluation. currently not in use.
     */
    public void kmeans() {
        Node[] leaves = m_root.getLeaves();
        int k = leaves.length;
        int n = 0;
        for (int i = 0; i < k; i++) {
            n += leaves[i].m_train.numRows();
        }
        int[] cluster = new int[n];
        double[][] matrix = new double[n][];
        int c = 0;
        for (int i = 0; i < k; i++) {
            for (int j = 0; j < leaves[i].m_train.numRows(); j++) {
                matrix[c] = leaves[i].m_train.row(j);
                cluster[c++] = i;
            }
        }

        cluster = (new Kmeans()).cluster(matrix, k, cluster);

        Array[] newArrays = new Array[k];
        for (int i = 0; i < k; i++) {
            newArrays[i] = new Array(leaves[0].m_train, false, true);
        }
        c = 0;
        for (int i = 0; i < k; i++) {
            for (int j = 0; j < leaves[i].m_train.numRows(); j++) {
                Instance inst = leaves[i].m_train.rowInstance(j);
                double[] row = leaves[i].m_train.row(j);
                int m = cluster[c++];
                newArrays[m].addRow(inst, row);
            }
        }
        for (int i = 0; i < k; i++) {
            leaves[i].m_train = newArrays[i];
            leaves[i].m_stat = new Stat(newArrays[i]);
        }
    }

    /**
     * Classifies an instance.
     *
     * @exception Exception if instance can't be classified successfully
     */
    public double classifyInstance(Instance a, Instance b) throws Exception {
        return m_root.classifyInstance(a, b);
    }

    public Vector classifyArray(Array array) throws Exception {
        return m_root.classifyArray(array);
    }

    public String ruleForInstance(Instance a, Instance b) throws Exception {
        return m_root.ruleForInstance(a, b);
    }

    /**
     * Returns graph describing the tree.
     *
     * @exception Exception if graph can't be computed
     */
    public String graph() throws Exception {

        return m_root.graph();
    }

    /**
     * Returns an enumeration describing the available options
     *
     * Valid options are: <p>
     *
     * -U <br>
     * Use unpruned tree.<p>
     *
     * -C confidence <br>
     * Set confidence threshold for pruning. (Default: 0.25) <p>
     *
     * -M number <br>
     * Set minimum number of instances per leaf. (Default: 2) <p>
     *
     * -S <br>
     * Don't perform subtree raising. <p>
     *
     * @return an enumeration of all the available options
     */
    public Enumeration listOptions() {
        Vector newVector = new Vector();
        newVector.
                addElement(new Option("\tUse unpruned tree.",
                                      "U", 0, "-U"));
        newVector.
                addElement(new Option("\tUse cross-validation pruning.",
                                        "C", 0, "-C"));
        newVector.
                addElement(new Option(
                        "\tSet minimum number of rows per leaf." +
                        "\t(default: 5)",
                        "M", 1, "-M <minimum number of rows>"));
        newVector.
                addElement(new Option(
                        "\tSet minimum number of columns per leaf." +
                        "\t(default: 5)",
                        "N", 1, "-N <minimum number of columns>"));
        newVector.
                addElement(new Option(
                        "\tSet maximum number of leaves." +
                        "\t(default: infinity)",
                        "L", 1, "-L <minimum number of columns>"));
        newVector.
                addElement(new Option("\tOutput rules instead of tree.",
                                      "R", 0, "-R"));
        newVector.
                addElement(new Option("\tDon't perform subtree raising.",
                                      "S", 0, "-S"));
        newVector.
                addElement(new Option("\tVerbose output.",
                                      "V", 0, "-V"));
        return newVector.elements();
    }

    /**
     * Parses a given list of options.
     *
     * @param options the list of options as an array of strings
     * @exception Exception if an option is not supported
     */
    public void setOptions(String[] options) throws Exception {
        String minNumString = Utils.getOption('M', options);
        if (minNumString.length() != 0) {
            m_minNumRow = Integer.parseInt(minNumString);
        } else {
            m_minNumRow = 5;
        }
        minNumString = Utils.getOption('N', options);
        if (minNumString.length() != 0) {
            m_minNumCol = Integer.parseInt(minNumString);
        } else {
            m_minNumCol = 5;
        }
        minNumString = Utils.getOption('L', options);
        if (minNumString.length() > 0) {
            m_maxNumLeaves = Integer.parseInt(minNumString);
        } else {
            m_maxNumLeaves = Integer.MAX_VALUE;
        }

        // Pruning options
        m_unpruned = Utils.getFlag('U', options);
        m_reducedError = Utils.getFlag('C', options);
        m_subtreeRaising = !Utils.getFlag('S', options);
        if ((m_unpruned) && (!m_subtreeRaising || m_reducedError)) {
            throw new Exception(
                    "Subtree raising doesn't need to be unset for unpruned tree!");
        }
        m_outputRules = Utils.getFlag('R', options);
        BDTree.verbose = Utils.getFlag('V', options);
        /*
              String confidenceString = Utils.getOption('C', options);
              if (confidenceString.length() != 0 && m_unpruned) {
                  throw new Exception("Doesn't make sense to change confidence for unpruned tree!");
              } else if (confidenceString.length() != 0) {
                  m_CF = (new Float(confidenceString)).floatValue();
                  if ((m_CF <= 0) || (m_CF >= 1)) {
                    throw new Exception("Confidence has to be greater than zero and smaller than one!");
                  }
              } else {
                m_CF = 0.25f;
              }
         */
    }

    /**
     * Gets the current settings of the Classifier.
     *
     * @return an array of strings suitable for passing to setOptions
     */
    public String[] getOptions() {

        Vector v = new Vector();

        if (m_outputRules) {
            v.add("-R");
        }
        if (m_unpruned) {
            v.add("-U");
        } else {
            if (m_reducedError) {
                v.add("-C");
            }
            if (!m_subtreeRaising) {
                v.add("-S");
            }
        }
        v.add("-M " + m_minNumRow);
        v.add("-N " + m_minNumCol);
        if (m_maxNumLeaves != Integer.MAX_VALUE) {
           v.add("-L " + m_maxNumLeaves);
        }
        if (verbose) {
            v.add("-V");
        }

        String[] options = new String[v.size()];
        return (String[]) v.toArray(options);
    }

    /**
     * Returns a description of the classifier.
     */
    public String toString() {

        if (m_root == null) {
            return "No classifier built";
        }
        StringBuffer sb = new StringBuffer();
        if (m_unpruned) {
            sb.append("bdtree.BDTree unpruned tree\n------------------\n");
        } else {
            sb.append("bdtree.BDTree pruned tree\n------------------\n");
        }
        if (!m_outputRules) {
            return sb.append(m_root.toString()).toString();
        }
        return sb.append(m_root.toRules()).toString();
    }

    /**
     * Returns a superconcise version of the model
     */
    public String toSummaryString() {
        return "Number of leaves: " + m_root.numLeaves() + "\n"
                + "Size of the tree: " + m_root.numNodes() + "\n";
    }

    /**
     * Returns the size of the tree
     * @return the size of the tree
     */
    public double measureTreeSize() {
        return m_root.numNodes();
    }

    /**
     * Returns the number of leaves
     * @return the number of leaves
     */
    public double measureNumLeaves() {
        return m_root.numLeaves();
    }

    /**
     * Returns the number of rules (same as number of leaves)
     * @return the number of rules
     */
    public double measureNumRules() {
        return m_root.numLeaves();
    }

    /**
     * Get the value of unpruned.
     * @return Value of unpruned.
     */
    public boolean getUnpruned() {
        return m_unpruned;
    }

    /**
     * Set the value of unpruned. Turns reduced-error pruning
     * off if set.
     * @param v  Value to assign to unpruned.
     */
    public void setUnpruned(boolean v) {
        m_unpruned = v;
    }

    /**
     * Get the value of CF.
     *
     * @return Value of CF.
     */
    public float getConfidenceFactor() {
        return m_CF;
    }

    /**
     * Set the value of CF.
     *
     * @param v  Value to assign to CF.
     */
    public void setConfidenceFactor(float v) {

        m_CF = v;
    }

    /**
     * Get the value of minNumObj.
     *
     * @return Value of minNumObj.
     */
    public int getMinNumRow() {

        return m_minNumRow;
    }

    public int getMinNumCol() {

        return m_minNumCol;
    }

    /**
     * Set the value of minNumObj.
     *
     * @param v  Value to assign to minNumObj.
     */
    public void setMinNumRow(int v) {

        m_minNumRow = v;
    }

    public void setMinNumCol(int v) {

        m_minNumCol = v;
    }

    public Node getTree() {
        return m_root;
    }

    /**
     * Get the value of subtreeRaising.
     *
     * @return Value of subtreeRaising.
     */
    public boolean getSubtreeRaising() {

        return m_subtreeRaising;
    }

    /**
     * Set the value of subtreeRaising.
     *
     * @param v  Value to assign to subtreeRaising.
     */
    public void setSubtreeRaising(boolean v) {

        m_subtreeRaising = v;
    }

    public String surrogateInfo() throws Exception {
        StringBuffer sb = new StringBuffer();
        double[][] info = m_root.surrogateInfo();
        Array train = m_root.m_train;
        for (int i = 0; i < info[0].length; i++) {
            sb.append("h." + train.rowAttribute(i) + "\t" + info[0][i] + "\n");
        }
        for (int i = 0; i < info[1].length; i++) {
            sb.append("v." + train.colAttribute(i) + "\t" + info[1][i] + "\n");
        }
        return sb.toString();
    }


    public void printLeaves(String filePrefix, boolean leafStubOnly) throws
            Exception {
        m_root.printLeaves(filePrefix, leafStubOnly);
    }

    public void printDataMatrix(String fileName) throws Exception {
        double[][] matrix = m_root.finalDataMatrix();
        PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(
                fileName)));
        for (int i = 0; i < matrix[0].length; i++) {
            out.print("\t" + "c");
        }
        out.println();
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                out.print("\t" + matrix[i][j]);
            }
            out.println();
        }
        out.flush();
        out.close();
    }

    public String information() {
        int n = m_root.dataSize();
        double SSInRoot = m_root.SS() / n;
        double SSInTree = m_root.SSInTree() / n;
        double SS2InRoot = m_root.SS2() / n;
        double SS2InTree = m_root.SS2InTree() / n;
        double SS3rInRoot = m_root.SS3r() / n;
        double SS3rInTree = m_root.SS3rInTree() / n;
        double SS3cInRoot = m_root.SS3c() / n;
        double SS3cInTree = m_root.SS3cInTree() / n;
        double SS2RatioScoreInRoot = m_root.SS2RatioScore() / n;
        double SS2RatioScoreInTree = m_root.SS2RatioScoreInTree() / n;
        double SS3rRatioScoreInRoot = m_root.SS3rRatioScore() / n;
        double SS3rRatioScoreInTree = m_root.SS3rRatioScoreInTree() / n;
        double SS3cRatioScoreInRoot = m_root.SS3cRatioScore() / n;
        double SS3cRatioScoreInTree = m_root.SS3cRatioScoreInTree() / n;
//        double ratio2 = (hScoreInRoot - hScoreInTree) / (varianceInRoot - varianceInTree);
        StringBuffer sb = new StringBuffer();
        sb.append("SS: " + Utils.roundDouble(SSInRoot, 2)
                  + "\t" + Utils.roundDouble(SSInTree, 2)
                  + "\t" + Utils.roundDouble(SSInRoot - SSInTree, 2) +
                  "\n");
        sb.append("SS2: " + Utils.roundDouble(SS2InRoot, 2)
                  + "\t" + Utils.roundDouble(SS2InTree, 2)
                  + "\t" + Utils.roundDouble(SS2InRoot - SS2InTree, 2) +
                  "\n");
        sb.append("SS3r: " + Utils.roundDouble(SS3rInRoot, 2)
                  + "\t" + Utils.roundDouble(SS3rInTree, 2)
                  + "\t" + Utils.roundDouble(SS3rInRoot - SS3rInTree, 2) +
                  "\n");
        sb.append("SS3c: " + Utils.roundDouble(SS3cInRoot, 2)
                  + "\t" + Utils.roundDouble(SS3cInTree, 2)
                  + "\t" + Utils.roundDouble(SS3cInRoot - SS3cInTree, 2) +
                  "\n");
        sb.append("SS2Ratio: " + Utils.roundDouble(SS2RatioScoreInRoot, 2)
                  + "\t" + Utils.roundDouble(SS2RatioScoreInTree, 2)
                  + "\t" +
                  Utils.roundDouble(SS2RatioScoreInRoot - SS2RatioScoreInTree, 2) +
                  "\n");
        sb.append("SS3rRatio: " + Utils.roundDouble(SS3rRatioScoreInRoot, 2)
                  + "\t" + Utils.roundDouble(SS3rRatioScoreInTree, 2)
                  + "\t" +
                  Utils.roundDouble(SS3rRatioScoreInRoot - SS3rRatioScoreInTree, 2) +
                  "\n");
        sb.append("SS3cRatio: " + Utils.roundDouble(SS3cRatioScoreInRoot, 2)
                  + "\t" + Utils.roundDouble(SS3cRatioScoreInTree, 2)
                  + "\t" +
                  Utils.roundDouble(SS3cRatioScoreInRoot - SS3cRatioScoreInTree, 2) +
                  "\n");
/*
        Node[] leaves = m_root.getLeaves();
        Stat stat = new Stat(m_root.m_train);
        Stat[] subStats = new Stat[leaves.length];
        for (int i = 0; i < leaves.length; i++) {
            subStats[i] = new Stat(leaves[i].m_train);
        }
        double gain = 0;
        gain = -stat.rowEffect() - stat.SS() / stat.nRows();
        for (int i = 0; i < subStats.length; i++) {
            gain += subStats[i].rowEffect();
        }

        sb.append("gain = " + Utils.roundDouble(gain, 2) + "\n");
 */
        return sb.toString();
    }


    /**
     * Main method for testing this class
     *
     * @param String options
     */

    public static void main(String[] argv) {
        try {
            /*
                       argv = new String[6];
                       argv[0] = "-t";
                       argv[1] = "x:/yeast_cell_cycle/dtanalysis/multivar/regtree/bdtree/cc/bdtree.arff";
                       argv[2] = "-x";
                       argv[3] = "0";
                       argv[4] = "-M";
                       argv[5] = "20";
             */
            System.out.println(Evaluation.evaluateModel(new BDTree(), argv));
        } catch (Exception e) {
            e.printStackTrace();
//            System.err.println(e.getMessage());
        }
    }

}
