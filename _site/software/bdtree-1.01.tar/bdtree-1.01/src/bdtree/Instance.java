package bdtree;


/**
 *
 * <p> Copyright (c) 2004</p>
 *
 * <p> Washington University in St Louis</p>
 *
 * @author Jianhua Ruan
 * @version 1.0
 */

public class Instance {
    String name;
    double[] attributes;

    public Instance() {
    }

    public Instance(String name, double[] attributes) {
        this.name = name;
        this.attributes = new double[attributes.length];
        System.arraycopy(attributes, 0, this.attributes, 0, attributes.length);
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAttributes(double[] attributes) {
        if (this.attributes == null) {
            this.attributes = new double[attributes.length];
        }
        System.arraycopy(attributes, 0, this.attributes, 0, attributes.length);
    }

    public double[] getAttributes() {
        double[] f = new double[this.attributes.length];
        System.arraycopy(this.attributes, 0, f, 0, this.attributes.length);
        return f;
    }

    public void setAttribute(int i, double f) {
        this.attributes[i] = f;
    }

    public double getAttribute(int i) {
        return this.attributes[i];
    }

    public int numAttributes() {
        return attributes.length;
    }

    public boolean isMissing(int attIndex) {
        return attributes[attIndex] == Double.NaN;
    }

    public boolean equals(Instance b) {
        return this.name == b.name;
    }

}
