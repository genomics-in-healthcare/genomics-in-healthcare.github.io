package bdtree;

import java.util.Random;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: Washington University in St Louis</p>
 *
 * @author not attributable
 * @version 1.0
 */
public class Test5 {
    public void run() throws Exception {
        Random random = new Random();
        int C = 1024;
        int N = 10000;
        for (int m = 0; m < 5; m++) {
            int c = C >> m;
            double[] array = new double[c];
            double avg = 0;
            double X = 0;
            double Y = 0;
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < c; j++) {
                    array[j] = random.nextDouble();
                }
                double var = Stat.varp(array) * c;
                double[] a1 = new double[c];
                double[] a2 = new double[c];
                int x = 0, y = 0;
                for (int j = 0; j < c; j++) {
                    if (random.nextBoolean() && random.nextBoolean()) {
                        a1[x++] = array[j];
                    } else {
                        a2[y++] = array[j];
                    }
                }
                double[] left = new double[x];
                double[] right = new double[y];
                System.arraycopy(a1, 0, left, 0, x);
                System.arraycopy(a2, 0, right, 0, y);
//                double var1 = Stat.varp(left) * x;
//                double var2 = Stat.varp(right) * y;
//                avg += var - var1 - var2;
                double diff = Stat.average(left) - Stat.average(array);
                avg += diff * diff * c * x / y;
                X += x;
                Y += y;
            }
            System.err.println(avg / N + " " + X / N + " " + Y / N);
        }
    }

    public static void main(String[] args) throws Exception {
        Test5 test = new Test5();
        test.run();
    }
}
