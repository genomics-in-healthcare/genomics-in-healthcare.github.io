package bdtree;

/**
 * <p> Copyright (c) 2004</p>
 *
 * <p> Washington University in St Louis</p>
 *
 * @author Jianhua Ruan
 * @version 1.0
 */

public class Stat {
    int nRows;
    int nCols;
    double totSum;
    double sumOfSq;
    double[] rowSum;
    double[] colSum;

    public Stat(int nR, int nC) {
        nRows = 0;
        nCols = 0;
        totSum = 0;
        sumOfSq = 0;
        rowSum = new double[nR];
        colSum = new double[nC];
    }

    public Stat(Stat s) {
        nRows = s.nRows;
        nCols = s.nCols;
        totSum = s.totSum;
        sumOfSq = s.sumOfSq;
        rowSum = new double[nRows];
        colSum = new double[nCols];
        System.arraycopy(s.rowSum, 0, rowSum, 0, nRows);
        System.arraycopy(s.colSum, 0, colSum, 0, nCols);
    }

    public Stat(Array data) {
        this(data, true);
    }

    public Stat(Array data, boolean addRow) {
        this(data.numRows(), data.numColumns());
        if (addRow) {
            for (int i = data.numRows() - 1; i >= 0; i--) {
                this.addRow(data.row(i));
            }
        } else {
            for (int i = data.numColumns() - 1; i >= 0; i--) {
                this.addColumn(data.column(i));
            }
        }
    }

    public int nRows() {
        return nRows;
    }

    public int nColumns() {
        return nCols;
    }

    public void addRow(double[] row) {
        if (nRows == 0) {
            nCols = row.length;
            colSum = new double[nCols];
        } else if (row.length != nCols) {
            throw new RuntimeException("row.length != nCols");
        }
        if (nRows >= rowSum.length) {
            double[] newRowSum = new double[nRows + 10];
            System.arraycopy(rowSum, 0, newRowSum, 0, rowSum.length);
            rowSum = newRowSum;
        }
        rowSum[nRows] = 0;
        for (int i = 0; i < nCols; i++) {
            rowSum[nRows] += row[i];
            sumOfSq += row[i] * row[i];
            colSum[i] += row[i];
        }
        totSum += rowSum[nRows++];
    }

    public void removeRow(double[] row) {
        if (row.length != nCols) {
            throw new RuntimeException("row.length != nCols");
        }
        if (nRows < 1) {
            throw new RuntimeException("no rows to remove!");
        }
        rowSum[--nRows] = 0;
        for (int i = 0; i < nCols; i++) {
            sumOfSq -= row[i] * row[i];
            colSum[i] -= row[i];
            totSum -= row[i];
        }
    }

    public void shiftRows(Stat s2, Array data, int start, int end) {
        for (int i = start; i < end; i++) {
            double[] row = data.row(i);
            this.addRow(row);
            s2.removeRow(row);
        }
    }

    public void addColumn(double[] col) {
        if (nCols == 0) {
            nRows = col.length;
            rowSum = new double[nRows];
        } else if (col.length != nRows) {
            throw new RuntimeException("col.length != nRows");
        }
        if (nCols >= colSum.length) {
            double[] newColSum = new double[nCols + 10];
            System.arraycopy(colSum, 0, newColSum, 0, colSum.length);
            colSum = newColSum;
        }
        colSum[nCols] = 0;
        for (int i = 0; i < nRows; i++) {
            colSum[nCols] += col[i];
            sumOfSq += col[i] * col[i];
            rowSum[i] += col[i];
        }
        totSum += colSum[nCols++];
    }

    public void removeColumn(double[] col) {
        if (col.length != nRows) {
            throw new RuntimeException("col.length != nRows");
        }
        if (nCols < 1) {
            throw new RuntimeException("no columns to remove!");
        }
        colSum[--nCols] = 0;
        for (int i = 0; i < nRows; i++) {
            sumOfSq -= col[i] * col[i];
            rowSum[i] -= col[i];
            totSum -= col[i];
        }
    }

    public void shiftColumns(Stat s2, Array data, int start, int end) {
        for (int i = start; i < end; i++) {
            double[] col = data.column(i);
            this.addColumn(col);
            s2.removeColumn(col);
        }
    }

    public double[] rowAvg() {
        double[] row = new double[nRows];
        for (int i = 0; i < nRows; i++) {
            row[i] = rowSum[i] / nCols;
        }
        return row;
    }

    /**
     *
     * @return the mean for each column
     */
    public double[] colAvg() {
        double[] col = new double[nCols];
        for (int i = 0; i < nCols; i++) {
            col[i] = colSum[i] / nRows;
        }
        return col;
    }

    /**
     *
     * @param i row index
     * @return the mean for the ith row
     */
    public double rowAvg(int i) {
        return rowSum[i] / nCols;
    }

    /**
     *
     * @param i column index
     * @return the mean for the ith column
     */
    public double colAvg(int i) {
        return colSum[i] / nRows;
    }

    /**
     *
     * @return the mean for the matrix
     */
    public double avg() {
        return totSum / nRows / nCols;
    }

    /**
     *
     * @return double
     */
    public double rowEffect() {
        double tot = 0;
        for (int i = 0; i < nCols; i++) {
            tot += colSum[i] * colSum[i];
        }
        return (tot - totSum * totSum / nCols) / nRows;
    }

    public double colEffect() {
        double tot = 0;
        for (int i = 0; i < nRows; i++) {
            tot += rowSum[i] * rowSum[i];
        }
        return (tot - totSum * totSum / nRows) / nCols;
    }

    public double SS2() {
        return sumOfSq - rowEffect() - colEffect() -
                totSum * totSum / nRows / nCols;
    }

    public double var2() {
        return SS2() / nRows / nCols;
    }

    public double SS() {
        return sumOfSq - totSum * totSum / nRows / nCols;
    }

    public double var() {
        return SS() / (nRows * nCols);
    }

    public double normalFactor() {
        return 1.0 - 1.0 / nRows - 1.0 / nCols;
    }

    public static double average(double[] a) {
        return sum(a) / a.length;
    }

    public static double mean(double[] a) {
        return sum(a) / a.length;
    }

    public static double sum(double[] a) {
        double s = 0;
        for (int i = 0; i < a.length; i++) {
            s += a[i];
        }
        return s;
    }

    public static double variance(double[] a) {
        double sum = sum(a);
        double sum_sqr = 0;
        for (int i = 0; i < a.length; i++) {
            sum_sqr += a[i] * a[i];
        }
        return (sum_sqr - sum * sum / a.length) / (a.length - 1);
    }

    public static double varp(double[] a) {
        double sum = sum(a);
        double sum_sqr = 0;
        for (int i = 0; i < a.length; i++) {
            sum_sqr += a[i] * a[i];
        }
        return (sum_sqr - sum * sum / a.length) / (a.length);
    }


    public static double stdev(double[] a) {
        return Math.sqrt(variance(a));
    }

    public static double stdevp(double[] a) {
        return Math.sqrt(varp(a));
    }

    public static double median(double[] a) {
        double[] b = new double[a.length];
        System.arraycopy(a, 0, b, 0, a.length);
        java.util.Arrays.sort(b);
        int i = (a.length - 1) / 2;
        int j = a.length / 2;
        return (b[i] + b[j]) / 2.;
    }

    public double SS3r() {
        return this.SS() - this.rowEffect();
    }

    public double SS3c() {
        return this.SS() - this.colEffect();
    }

}
