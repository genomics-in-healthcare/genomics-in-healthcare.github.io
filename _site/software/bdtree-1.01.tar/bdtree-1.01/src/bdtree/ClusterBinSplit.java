package bdtree;

import java.util.*;

/**
 * <p>Copyright (c) 2004, Washington University in St Louis</p>
 *
 * <p>@author Jianhua Ruan</p>
 *
 * <p>@version $Revision$</p>
 *
 * <p> </p> not attributable
 */
public class ClusterBinSplit extends NodeSplitModel {
    protected ClusterBinSplit(int minNoObj, boolean hSplit, ArrayList models) {
        this.m_minNoObj = minNoObj;
        this.hSplit = hSplit;
        this.models = models;
        this.m_numSubsets = 2;
    }

    /** Minimum number of objects in a split.   */
    protected int m_minNoObj;

    protected ArrayList models;

    /**
     * Creates a split on the given data.
     *
     * @exception Exception if something goes wrong
     */
    public void buildClassifier(Array data, Stat stat) {
        ArrayList allModels = models;
        this.models = new ArrayList();
        System.err.println("init: " + allModels.size());
/*        for (int i = 0; i < allModels.size(); i++) {
            System.err.print(i + "  ");
           System.err.println(((BinSplit)allModels.get(i)).m_gain);
        }
 */
        Collections.sort(allModels);
        BinSplit currentModel = (BinSplit)allModels.get(0);
        models.add(currentModel);
        Array[] localArrays = currentModel.split(data);
        m_gain = currentModel.gain(data, localArrays);
        Array[] tempArrays = new Array[2];
        for (int i = 1; i < allModels.size(); i++) {
            currentModel = (BinSplit)allModels.get(i);
            tempArrays = currentModel.split(localArrays[0]);
            if (tempArrays[0].numRows() < m_minNoObj) {
                continue;
            }
            for (int j = 0; j < localArrays[1].numRows(); j++) {
                tempArrays[1].addRow(localArrays[1].rowInstance(j), localArrays[1].row(j));
            }
            double gain = currentModel.gain(data, tempArrays);
            if (gain > m_gain) {
                m_gain = gain;
                localArrays = tempArrays;
                models.add(currentModel);
                if (localArrays[0].numRows() < m_minNoObj) break;
            }
        }
        System.err.println("forward: " + models.size());
        Collections.reverse(models);
        for (int i = models.size()-1; i >= 0 && models.size() > 1; i--) {
            currentModel = (BinSplit)models.remove(i);
            localArrays = this.split(data);
            double gain = currentModel.gain(data, localArrays);
            if (gain > m_gain) {
                m_gain = gain;
            } else {
                models.add(currentModel);
            }
        }
        System.err.println("backward: " + models.size());

    }

    double gain(Array parent, Array[] children) {
        Stat stat = new Stat(parent);
        Stat[] subStats = new Stat[children.length];
        for (int i = 0; i < subStats.length; i++) {
            subStats[i] = new Stat(children[i]);
        }
        double gain = 0;
        if (this.hSplit) {
            gain = -stat.rowEffect() -
                   this.FILTER * stat.SS() / stat.nRows();
            for (int i = 0; i < subStats.length; i++) {
                gain += subStats[i].rowEffect();
            }
        } else {
            gain = -stat.colEffect() -
                   this.FILTER * stat.SS() / stat.nColumns();
            for (int i = 0; i < subStats.length; i++) {
                gain += subStats[i].colEffect();
            }
        }
        if (gain < 0) {
            return 0;
        }
        return gain;
    }

    /**
     * Prints left side of condition..
     * @param index of subset and training set.
     */
    public String leftSide(Array data) {
        StringBuffer sb = new StringBuffer();
        if (hSplit) {
            sb.append("h.");
            for (int i = 0; i < models.size(); i++) {
                sb.append(data.rowAttribute(((BinSplit)models.get(i)).attIndex()) + " ");
            }
        } else {
            sb.append("v.");
            for (int i = 0; i < models.size(); i++) {
                sb.append(data.colAttribute(((BinSplit)models.get(i)).attIndex()) + " ");
            }
        }
        return sb.toString();
    }

    /**
     * Prints the condition satisfied by instances in a subset.
     *
     * @param index of subset and training set.
     */
    public String rightSide(int index, Array data) {
        double c = 0;
        if (index == 0) {
            return " < " + Utils.roundDouble(c, 2);
        } else {
            return " >= " + Utils.roundDouble(c, 2);
        }
    }


    /**
     * Returns index of subset instance is assigned to.
     * Returns -1 if instance is assigned to more than one subset.
     *
     * @exception Exception if something goes wrong
     */

    public int whichSubset(Instance instance) {
        for (int i = 0; i < models.size(); i++) {
            int index = ((BinSplit)models.get(i)).whichSubset(instance);
            if (index == 1) return 1;
        }
            return 0;
    }

    public boolean isFuzzy(Instance inst) {
            return false;
    }

}
