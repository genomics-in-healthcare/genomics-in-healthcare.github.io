package bdtree;

/**
 * <p> Copyright (c) 2004</p>
 *
 * <p> Washington University in St Louis</p>
 *
 * @author Jianhua Ruan
 * @version 1.0
 */

public class CVPruneableNode extends Node {

    /** True if the tree is to be pruned. */
    boolean m_pruneTheTree = false;

    boolean ratio = false;

    Array[] m_test = null;
    int numSets = 5;

    /**
     * Constructor for pruneable tree structure. Stores reference
     * to associated training data at each node.
     *
     * @param toSelectLocModel selection method for local splitting model
     * @param pruneTree true if the tree is to be pruned
     * @param cf the confidence factor for pruning
     * @exception Exception if something goes wrong
     */
    public CVPruneableNode(ModelSelection toSelectLocModel,
                           boolean pruneTree) throws Exception {

        super(toSelectLocModel);
        m_pruneTheTree = pruneTree;
    }

    /**
     * Method for building a pruneable classifier tree.
     *
     * @exception Exception if something goes wrong
     */
    public void buildClassifier(Array data) throws Exception {
        data.randomize(new java.util.Random(0));
        buildTree(data.trainCV(numSets, 0), data.testCV(numSets, 0));
        if (m_pruneTheTree) {
            prune();
        }
    }

    public void buildTree(Array train, Array[] test) throws Exception {
        if (train.numRows() <= 0 || train.numColumns() <= 0) {
            throw new Exception("no instances!");
        }
        m_train = train;
        m_stat = new Stat(train);
        m_test = test;
//        data.updateInstances(m_stat);
        if (BDTree.verbose) {
            System.err.println("node: " + m_id + " " + dumpLabel());
        }
        m_localModel = m_modelSelection.selectModel(train, m_stat);
        if (BDTree.verbose) {
            System.err.println("gain = " + m_localModel.gain());
        }
        if (m_localModel.numSubsets() > 1) {
            if (m_localModel.hSplit()) {
                usedRowAtts.set(((BinSplit) m_localModel).attIndex());
            } else {
                usedColAtts.set(((BinSplit) m_localModel).attIndex());
            }
            Array[] localTrain = m_localModel.split(train);
            Array[][] localTest = new Array[m_localModel.numSubsets()][test.
                                  length];
            for (int i = 0; i < test.length; i++) {
                Array[] local = m_localModel.split(test[i]);
                for (int j = 0; j < local.length; j++) {
                    localTest[j][i] = local[j];
                }
            }
            m_sons = new Node[m_localModel.numSubsets()];
            for (int i = 0; i < m_sons.length; i++) {
                m_sons[i] = getNewTree(localTrain[i], localTest[i]);
            }
            m_isLeaf = false;
        }
    }


    /**
     * Returns a newly created tree.
     *
     * @param data the training data
     * @exception Exception if something goes wrong
     */
    protected Node getNewTree(Array train, Array[] test) throws Exception {

        CVPruneableNode newTree = new CVPruneableNode(m_modelSelection,
                m_pruneTheTree);
        newTree.usedRowAtts.or(this.usedRowAtts);
        newTree.usedColAtts.or(this.usedColAtts);
        newTree.level = this.level + 1;
        newTree.parent = this;
        newTree.buildTree(train, test);
        return newTree;
    }


    /**
     * Prunes a tree using C4.5's pruning procedure.
     *
     * @exception Exception if something goes wrong
     */
    public void prune() throws Exception {
        if (!m_isLeaf) {

            // Prune all subtrees.
            for (int i = 0; i < m_sons.length; i++) {
                _son(i).prune();
            }

            // Decide if leaf is best choice.
            if (errorsForLeaf() <= errorsForTree()) {
                this.asLeaf();
            }
        }
    }

    /**
     * Computes estimated errors for tree.
     */
    private double errorsForTree() {

        double errors = 0;
        if (m_isLeaf) {
            return errorsForLeaf();
        } else {
            for (int i = 0; i < m_sons.length; i++) {
                errors = errors + _son(i).errorsForTree();
            }
            return errors;
        }
    }

    public double errorsForLeaf() {
        boolean status = m_isLeaf;
        this.m_isLeaf = true;
        java.util.Vector v = new java.util.Vector();
        for (int i = 0; i < m_test.length; i++) {
            if (m_test[i].size() > 0) {
                v.addAll(this.classifyArray(m_test[i]));
            }
        }
        double error = 0;
        for (int i = 0; i < v.size(); i++) {
            double[][][] pairs = (double[][][]) v.get(i);
            for (int j = 0; j < pairs[0].length; j++) {
                for (int k = 0; k < pairs[0][j].length; k++) {
                    error += (pairs[0][j][k] - pairs[1][j][k]) *
                            (pairs[0][j][k] - pairs[1][j][k]);
                }
            }
        }
        this.m_isLeaf = status;
        return error;
    }

    public CVPruneableNode _son(int i) {
        return (CVPruneableNode) m_sons[i];
    }

}
