package bdtree;

import java.io.Serializable;

/**
 * <p> Copyright (c) 2004</p>
 *
 * <p> Washington University in St Louis</p>
 *
 * @author Jianhua Ruan
 * @version 1.0
 */

public class ModelSelection implements Serializable {

    /** Minimum number of instances in subset */
    protected int m_minNoRow;
    protected int m_minNoCol;

    /**
     * Initializes the split selection method with the given parameters.
     *
     * @param m_minNoObj minimum number of instances that have to occur in at least two
     * subsets induced by split
     */
    public ModelSelection(int minNoRow, int minNoCol) {
        m_minNoRow = minNoRow;
        m_minNoCol = minNoCol;
    }

    /**
     * Sets reference to training data to null.
     */
    public void cleanup() {
    }

    /**
     * Selects a split for the given dataset.
     */
    public NodeSplitModel selectModel(Array data, Stat stat) {
        NodeSplitModel currentModel;

        double r = data.numRows();
        double c = data.numColumns();

//        double gain = (r * c) / (r * c - r - c) * stat.totVar();
//        double gain = 1.0;

        double hGain = 0;
        double vGain = 0;
        NodeSplitModel bestHModel = null;
        NodeSplitModel bestVModel = null;

//        if (stat.avgVar() <= 1e-5) {
//            return new NoSplit();
//        }
        if (r >= 2 * m_minNoRow) {
            for (int i = 0; i < data.numRowAttributes(); i++) {
                switch (BDTree.split) {
                case 0:
                    currentModel = new BinSplit(i, m_minNoRow, true);
                    break;
                case 1:
                    currentModel = new BinSplit_ratio(i, m_minNoRow, true);
                    break;
                case 2:
                    currentModel = new BinSplit_row_or_column_variance(i,
                            m_minNoRow, true);
                    break;
                case 3:
                    currentModel = new BinSplit_ratio_row_or_column(i,
                            m_minNoRow, true);
                    break;
                default:
                    currentModel = new BinSplit(i, m_minNoRow, true);
                }
                currentModel.buildClassifier(data, stat);
                if (currentModel.checkModel()) {
                    if (currentModel.gain() > hGain) {
                        bestHModel = currentModel;
                        hGain = currentModel.gain();
                    }
                }
            }
        }

        if (BDTree.rowFirst && bestHModel != null) {
            return bestHModel;
        }
        if (c >= 2 * m_minNoCol) {
            for (int i = 0; i < data.numColAttributes(); i++) {
                if (data.colAttributesMapped != null) {
                    String name = data.colAttributesMapped[i];
                    boolean inRows = false;
                    for (int j = 0; j < data.numRows(); j++) {
                        if (data.rowInstance(j).getName().equalsIgnoreCase(name)) {
                            inRows = true;
                            break;
                        }
                    }
                    if (inRows)continue;
                }
                switch (BDTree.split) {
                case 0:
                    currentModel = new BinSplit(i, m_minNoCol, false);
                    break;
                case 1:
                    currentModel = new BinSplit_ratio(i, m_minNoCol, false);
                    break;
                case 2:
                    currentModel = new BinSplit_row_or_column_variance(i,
                            m_minNoCol, false);
                    break;
                case 3:
                    currentModel = new BinSplit_ratio_row_or_column(i,
                            m_minNoCol, false);
                    break;
                default:
                    currentModel = new BinSplit(i, m_minNoCol, false);
                }
                currentModel.buildClassifier(data, stat);
                if (currentModel.checkModel()) {
                    if (currentModel.gain() > vGain) {
                        bestVModel = currentModel;
                        vGain = currentModel.gain();
                    }
                }
            }
        }

        if (bestHModel == null && bestVModel == null) {
            return new NoSplit();
        }
        NodeSplitModel bestModel = bestVModel;
        if (!BDTree.diffRowCol && hGain > vGain) {
            bestModel = bestHModel;
        } else if (!BDTree.diffRowCol) {
            bestModel = bestVModel;
        } else if (hGain * r > vGain * c) {
            bestModel = bestHModel;
        }
        return bestModel;
    }

}
