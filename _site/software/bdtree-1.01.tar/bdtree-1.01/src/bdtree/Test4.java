package bdtree;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Random;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: Washington University in St Louis</p>
 *
 * @author not attributable
 * @version 1.0
 */
public class Test4 {
    public void run() throws Exception {
        BufferedReader reader = new BufferedReader(new FileReader(
                "x:/yeast_cell_cycle/dtanalysis/multivar/regtree/bdtree/cc/bdtree.arff"));
        Array arr = new Array(reader);
        Random random = new Random(0);
        int R = 1024;
        int C = 1024;
        int N = 10;
        for (int m = 0; m < 10; m++) {
            int r = R >> m;
            int c = C << m;
            double ratio = 1.0 - 1. / r - 1. / c;
            double[][] array = new double[r][c];
            double avg1 = 0;
            double avg2 = 0;
            for (int n = 0; n < N; n++) {
                Stat stat = new Stat(r, c);
                for (int i = 0; i < r; i++) {
                    for (int j = 0; j < c; j++) {
                        int p = (int) (random.nextDouble() * arr.numRows());
                        int q = (int) (random.nextDouble() * arr.numColumns());
                        array[i][j] = arr.value(p, q);
                    }
                    stat.addRow(array[i]);
                }
                avg1 += stat.var2();
                avg2 += stat.var2() / stat.var();
            }
            System.out.println(avg1 / N + "\t" + avg2 / N + "\t" +
                               avg1 / N / ratio + "\t" + avg2 / N / ratio);
        }
    }

    public static void main(String[] args) throws Exception {
        Test4 test = new Test4();
        test.run();
    }
}
