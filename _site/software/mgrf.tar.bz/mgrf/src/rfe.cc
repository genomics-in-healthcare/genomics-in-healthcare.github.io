#include "random_forests.h"
#include "misc.h"
#include "rfe.h"

using namespace std;

// get the rmse for cross-validation
double RecursiveFe::Evaluate(const vector<const Instance*>& insts, const vector<const Instance*>& valid_insts, const ArgType& args) {
    const double bfe_ratio = 0.8;
    int m = insts[0]->num_features;

    RfGuide* guide = NULL;
    if (args.guide!="") {
        guide = new RfGuide();
        guide->ReadNetwork(args.guide.c_str());
    }

    vector<int> ft_idxs; // All features
    for (int j=0; j<m; ++j)
        ft_idxs.push_back(j);

    int availible_m = m;

    int best_t = 0;
    double best_trainerr = 0.0;
    double best_ooberr = RF_DBL_MAX;
    double best_validerr = 0.0;
    int best_m = 0;
    int best_nummod = 0;
    vector<double> best_vi;
    
    // Do no more than 25 iteration
    for (int t=0; t<25; ++t) {
        ArgType new_args = args;
        new_args.mtry = max(availible_m / 3, 1);

        RandomForests rf;
        rf.guide(guide);
        rf.Train(insts, valid_insts, ft_idxs, new_args);

        cout << t << "," << availible_m;
        if (guide)
            cout << "," << guide->num_modules();

        double trainerr = rf.train_err();
        double ooberr = rf.oob_err();
        cout << "," << trainerr << "," << ooberr;
        
        double valid_err = 0;
        if (valid_insts.size() > 0) {
            vector<double> valid_preds = rf.Predict(valid_insts);
            valid_err = rf.Evaluate(valid_insts, valid_preds);
            cout << "," << valid_err;
        }
        cout << endl;
        cout.flush();

        char filename[256];

        // recursively remove features
        vector<double> cvi; 
        if (guide) {
            //sprintf(filename, "rfe_%d_orig.tsv", t);
            //vector<int> tmpidx(rf.vi().size());
            //for (size_t j=0; j<rf.vi().size(); ++j)
            //    tmpidx[j] = j;

            //WriteFeatures(filename, tmpidx, rf.vi());

            //cvi = guide->CorrectVariableImportance(rf.vi());  // if it's guided then correct the vi
            cvi.assign(rf.vi().begin(), rf.vi().end());
        } else {
            cvi.assign(rf.vi().begin(), rf.vi().end());
        }

        if (best_ooberr>=ooberr) {
            best_ooberr = ooberr;
            best_t = t;
            best_validerr = valid_err;
            best_trainerr = trainerr;
            best_vi = cvi;
            best_m = availible_m;
            if (guide)
                best_nummod = guide->num_modules();
        }

        vector<double> vi(availible_m, 0.0);
        for (int j=0; j<availible_m; ++j)
            vi[j] = cvi[ft_idxs[j]];

        vector<int> vi_idxs = SortVi(vi);

        // output selected feature
        sprintf(filename, "rfe_%d.tsv", t);
        vector<double> sorted_vi(vi.size());
        vector<int> sorted_idxs(vi.size());
        for (int j=0; j<availible_m; ++j) {
            sorted_vi[j] = vi[vi_idxs[j]];
            sorted_idxs[j] = ft_idxs[vi_idxs[j]];
        }
        WriteFeatures(filename, sorted_idxs, sorted_vi); 

        availible_m = (int)(availible_m * bfe_ratio);
        if (availible_m == 1)
            break;
        ft_idxs.assign( sorted_idxs.begin(), sorted_idxs.begin() + availible_m );
    }

    // Report best
    cout << "#Best at:" << endl;
    cout << best_t << "," << best_m << ",";
    if (guide)
        cout << best_nummod;
    cout << "," << best_trainerr << "," << best_ooberr;

    if (valid_insts.size() > 0)
        cout << "," << best_validerr;
    cout << endl;
    cout.flush();
    
    // write best weight to file
    misc::write_vector(best_vi, args.weight_output.c_str());

    delete guide;
    return 0;
}

void RecursiveFe::RowSum(const vector<double>& data, int m, vector<double>* rowsum) {
    rowsum->clear();
    rowsum->assign(m, 0.0);
    for (int j=0; j<m; ++j) {
        for (int i=0; i<m; ++i) {
            (*rowsum)[j] += data[i*m+j];
        }
    }
}

vector<int> RecursiveFe::SortVi(const vector<double>& data) {
    int n = (int)data.size();
    vector<int> index(n);
    vector< pair<int, double> > order(n);
    for (int i=0; i<n; i++)
        order[i] = make_pair(i, data[i]);
    sort(order.begin(), order.end(), greater_ordering());
    for (int i=0; i<n; i++)
        index[i] = order[i].first;
    return index;
}


void RecursiveFe::WriteFeatures(const char * filename, const std::vector<int>& ft_idxs, const std::vector<double>& vi) {
    FILE *file;
    if ((file = fopen(filename, "w")) == NULL) { 
        perror(filename); 
        exit(-1); 
    }

    int n = (int)ft_idxs.size();
    
    for (int i=0; i<n; i++) {
        fprintf(file, "%d\t%lf\n", ft_idxs[i], vi[i]);     
    }
    fclose(file);
}
