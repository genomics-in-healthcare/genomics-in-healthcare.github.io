#ifndef RF_SPARSE_MATRIX_H
#define RF_SPARSE_MATRIX_H

#include <vector>

typedef struct _sm_coo_tuple {
    int i;
    int j;
    double val;
} CooTuple;

struct coo_ordering { // functor for coo tuple sorting
    bool operator ()(CooTuple const& a, CooTuple const& b) {
        if (a.i == b.i)
            return a.j< b.j;
        else
            return a.i<b.i;
    }
};

class SparseMatrix {
public:
    SparseMatrix() {};
    ~SparseMatrix() {};

    void ReadSparse(const char* filename);
    std::vector<double> Multiply(const std::vector<double>& col_vec);

    void Test();

private:
    static std::vector<CooTuple> SortCooTuples(std::vector<CooTuple> const& tuples);

    int nnz_;
    int n_;
    int m_;

    std::vector<double> vals_;
    std::vector<int>    row_ptr_;
    std::vector<int>    col_ind_;
};

#endif
