#ifndef RF_REGRESSION_TREE_H
#define RF_REGRESSION_TREE_H

#include <vector>
#include <iostream>
#include "instance.h"
#include "presorter.h"
#include "rf_guide.h"
#include "args.h"


class RegressionTree {
public:
    RegressionTree(); 
    ~RegressionTree();

    void Train(const std::vector<const Instance*>& insts, const std::vector<int>& ft_idxs, const ArgType& args);  // build a regreesion tree given training data

    double                 Predict(const Instance& inst);
    std::vector<double>    Predict(const std::vector<const Instance*>& insts);
    double  Evaluate(const std::vector<const Instance*>& insts, const std::vector<double>& predicts);

    void SetErrorDcrs(std::vector<double>* error_dcrs) { error_dcrs_ = error_dcrs; }
    //void SetFeatureCorr(std::vector<double>* counts) { feature_corr_ = counts; }

    // I/O
    friend std::ostream& operator<< (std::ostream& o, const RegressionTree& rt); // output tree structure to stream 
    friend int operator>> (std::istream& i, RegressionTree& rt); // read tree from stream

    std::vector<int>* feature_count_;
    //std::vector<double>* fs_guide_;

    void guide(RfGuide* g) { guide_ = g; }
    void weighted_sampling(bool v) {weighted_sampling_ = v;}

protected:
    void PutTree(std::ostream& ost) const; // write tree nodes to an output stream
    bool GetTree(std::istream& ist); // read tree nodes from stream


private:    
    typedef struct _st_rt_node {
        int feature; //feature index that this node split on
        double value; // feature value that this node split on
        double pred; // what this node predicts if it is a leaf node
        int leftchild; // index of left child node
        int rightchild; // index of right child node

        bool leaf; // whether it is a leaf node
        struct _st_rt_node * parent;
    } RtNode;

    /*
    typedef struct _st_rt_split_params {
        int * ft_idxs;
        int start;
        int end;
        double r;
        double ybr;
    } SplitParams;
    */

    // split a node with given data samples
    double   SplitNode(const std::vector<const Instance*>& insts, const std::vector<int>& ft_idxs, 
                       std::vector<const Instance*>* left_insts, std::vector<const Instance*>* right_insts, 
                       int* fsplit, double* vsplit); 

    // find a spliting point for a given range of features
    //static void  FindSplitInRange(const std::vector<const Instance*>& data, const SplitParams* sparam, int* best_splition_id, double* vsplit, double* se_dcr, 
    //                              std::vector< std::vector<int> >* splition); 

    // find a spliting point for a given feature
    static void   FindSplit(const std::vector<const Instance*>& data, double r, double ybr, 
                     int fsplit, double* vsplit, double* se_dcr, std::vector<int>* splition);  

    double   Average(const std::vector<const Instance*>& insts);
    bool     IsSame(const std::vector<const Instance*>& insts);
    double   GetSe(const std::vector<const Instance*>& insts);
    bool     IsTerminal(const std::vector<const Instance*>& insts);
    void     RemoveNodes();

    static void SortInstances(const std::vector<const Instance *>& data, std::vector<const Instance *>* sorted_data, std::vector<int>* index, int f);


    const std::vector<const Instance*>* instances_; // pointer to the instances_ 

    ArgType args_; // Program parameters that will be used during the training
    std::vector< RtNode* > nodes_; // vector of all nodes
    //int * sample_count_; // A pre-allocated space to store the sample count used in each node. 
    std::vector<double>* error_dcrs_; // error decrease for each feature (given by random forest instance) 
    //std::vector<double>* feature_corr_; // feature correlation

    RfGuide* guide_;
    bool weighted_sampling_;

};

#endif

