//parse command line arguments
#ifndef RF_ARGS_H
#define RF_ARGS_H

#include <cstdio>
#include <boost/program_options.hpp>

typedef struct arg_t {
    bool usestream;
    char mode; // l: learn; d: diagnose; t:test; c: cross-validation 
    char type; // c: classification r: regression
    std::string input_file;
    std::string output_file;
    std::string valid_input;
    std::string test_input;
    std::string test_output;
    std::string guide;
    std::string weight_output;
    
    int numthreads;
    int ntrees;
    int mtry;
    int nodesize;
    int maxdepth;
    int numfolds;
    int bootstrap;
} ArgType;

int parse_parameter(int argc, char* argv[], ArgType* args);




#endif
