#include <cstdio>
#include "attribute.h"

#define MAX_LINE 2097152

void Attribute::ReadAttributes(const char* filename, std::vector<const Attribute*>* attrs) {
    // open file
    FILE *file;
    if ((file = fopen (filename, "r")) == NULL) { 
        perror(filename); 
        exit(-1); 
    }
    char name[2048];
    int type, num_classes;

    attrs->clear();

    char * line = new char[MAX_LINE];
    while (fgets(line, MAX_LINE, file) != NULL) { // for each line
        size_t len = strlen(line);
        if (len!=0 && line[len-1] == '\n') {
            line[len-1] = '\0';
        } else if (len == MAX_LINE - 1) {
            printf("Line length exceeds the MAX_LINE!\n");
            exit(1);
        }

        if (line[0] == '#') continue;
        if (sscanf(line,"%s\t%d\t%d", name, &type, &num_classes) == EOF) continue;
        Attribute* attr = new Attribute();
        if (type==0)
            attr->type = Attribute::NUMERIC;
        else
            attr->type = Attribute::CATEGORICAL;
        attr->num_classes = num_classes;
        attrs->push_back(attr);
    }
}
