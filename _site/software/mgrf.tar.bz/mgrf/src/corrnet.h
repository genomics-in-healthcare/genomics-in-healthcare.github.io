//co-expression network
#ifndef RF_COEXPNET_H
#define RF_COEXPNET_H

#include <cmath>
#include <vector>
#include <map>
#include "instance.h"

class CorrelationNet {
public:
    CorrelationNet(const std::vector<const Instance*>& insts, const std::vector<const Attribute*>& attrs);

    const std::map<int, std::map<int, double> >& GetCorrNet() const { return sp_net_; } 

private:
    void Sparsify(const std::vector<const Attribute*>& attrs);
    void PartialSort(std::vector< std::pair<int, double> >& order, int partial_k, std::vector<int>* index);

    static double NormMutualInformation(const std::vector<int>& x, const std::vector<int>& y, int nc1, int nc2);
    static void Discretize(const std::vector<const Instance*>& insts, const std::vector<const Attribute*>& attrs, std::vector< std::vector<int> >* ddata);


    std::vector<double> corr_net_;
    std::map<int, std::map<int, double> > sp_net_;

#ifdef _WIN32
    static double log2(double val) { return log(val) / log(2.0); }
#endif
};

#endif
