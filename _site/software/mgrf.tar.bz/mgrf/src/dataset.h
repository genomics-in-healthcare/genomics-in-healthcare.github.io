#ifndef MGRF_DATASET_H
#define MGRF_DATASET_H

#include <string>
#include <vector>
#include "instance.h"
#include "attribute.h"


class Dataset {
public:
    Dataset();
    ~Dataset();

    size_t num_features() const { return attributes_.size(); }
    size_t num_instances() const { return instances_.size(); }

    const std::vector<const Instance*> instances() const;
    const Instance* instance(int i) const { return instances_[i]; }

    const std::vector<const Attribute*> attributes() const { return attributes_; }
    const Attribute* attribute(int j) const { return attributes_[j]; }

    const Attribute& label_type() const { return label_type_; }

    void SetLabel(int i, double label) { instances_[i]->label = label; }
    
    void ReadFile(const char * filename); // A wrapper function for data input
    void ReadCsv(const char * filename, char sep);  // populate data vector with instances from csv/tsv file
    void ReadSvmFile(const char * filename);  // populate data vector with instances from svm-light file

private:
    bool IsInteger(double value) { int ival = (int)value; return (value - ival) == 0; }

    void ReleaseInstances();
    void ReleaseAttributes();

private:
    std::vector<Instance*> instances_;    // data instance
    std::vector<const Attribute*> attributes_;  // feature descriptions

    Attribute label_type_;   // class label or regression target information
};

#endif
