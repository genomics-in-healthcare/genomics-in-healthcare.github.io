#include <cstdio>
#include <cstdlib> //atof
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <set>
#include <algorithm>
#include "misc.h"
#include "dataset.h"

using namespace std;

Dataset::Dataset() {
}


Dataset::~Dataset() {
    ReleaseInstances();
    ReleaseAttributes();
}


// get a const copy of instances vector
const vector<const Instance*> Dataset::instances() const {
    int n = instances_.size();
    vector<const Instance*> insts;
    for (int i=0; i<n; i++)
        insts.push_back(instances_[i]);
    return insts;
}


void Dataset::ReadFile(const char* filename) {
    // read data based on file extension
    const char* ext = strrchr(filename,'.');
    if (ext!=NULL) {
        if (misc::cmp_string(ext, ".csv")) {
            ReadCsv(filename, ',');
        } else if (misc::cmp_string(ext, ".tsv")) {
            ReadCsv(filename, '\t');
        } else {
            ReadSvmFile(filename);
        }
    } else {
        ReadSvmFile(filename);
    }
}


// Read instances from CSV file
// Comma/Tab-delimited file, each row is a feature, each coumn is a sample
// The first row is the label and the first column is the feature name
void Dataset::ReadCsv(const char * filename, char sep) {    
    ReleaseAttributes();
    ReleaseInstances();
    
    // open file
    ifstream infile(filename);
    if (infile.fail()) {
        perror(filename); 
        exit(-1);
    }

    vector<double*> feat_data;
    vector<Attribute*> attrs; // a temporary vector holds the newly-created Attributes
    vector<double> labels;
    string line;
    string cell;
    char * endptr;
    double value;
    
    // the first line is the label line
    label_type_.name = "Label";
    label_type_.type = Attribute::CATEGORICAL;
    getline(infile, line);
    stringstream ls_label(line);
    getline(ls_label, cell, sep); // ignore the first cell
    while (getline(ls_label, cell, sep)) {
        value = strtod(cell.c_str(), &endptr); 
        if (*endptr == '\0' || *endptr == '\r' || *endptr == '\n') {
            labels.push_back(value);
            if (!IsInteger(value))
                label_type_.type = Attribute::NUMERIC;
        }
        else {
            labels.push_back(MISSING);
        }
    }

    if (label_type_.type == Attribute::CATEGORICAL) {// get number of classes
        set<double> uniq_count(labels.begin(), labels.end());
        label_type_.num_classes = (int)uniq_count.size();
    }
    
    size_t num_samples = labels.size();
    
    // read following data rows
    while (!infile.eof()) {
        getline(infile, line);
        if (line == "")
            continue;
        
        stringstream lineStream(line);
        // get feature name
        getline(lineStream, cell, sep);
        Attribute * att = new Attribute();
        att->name = cell;

        double * rowData = new double[num_samples];
        int j=0;
        while(getline(lineStream, cell, sep)) {
            value = strtod(cell.c_str(), &endptr); 
            if (*endptr == '\0' || *endptr == '\r' || *endptr == '\n') {
                rowData[j++] = value;
                if (!IsInteger(value))
                    att->type = Attribute::NUMERIC;
            }
            else
                rowData[j++] = MISSING;
        }

        if (att->type == Attribute::CATEGORICAL) {// get number of classes
            set<int> uniq_count;
            for (size_t i=0; i<num_samples; ++i)
                uniq_count.insert((int)rowData[i]);
            att->num_classes = (int)uniq_count.size();
        }

        attrs.push_back(att);
        feat_data.push_back(rowData);
    }
    
    int num_features = attrs.size();
    
    // transform FeatureData into instances vector 
    for (size_t i=0; i<num_samples; i++) {
        Instance * inst = new Instance();
        inst->features = new double[num_features];
        inst->label = labels[i];
        inst->weight = 1.0;
        inst->num_features = num_features;
        for (int j=0; j<num_features; j++)
            inst->features[j] = feat_data[j][i];    
        instances_.push_back(inst);
    }

    // free memory for feature data
    attributes_.resize(attrs.size());
    for (int j=0; j<num_features; j++) {
         delete[] feat_data[j];
         feat_data[j] = NULL;
         attributes_[j] = attrs[j];
    }
}


void Dataset::ReadSvmFile(const char * filename) {
    ReleaseAttributes();
    ReleaseInstances();

    FILE *file;
    if ((file = fopen (filename, "r")) == NULL) { 
        perror(filename); 
        exit(-1); 
    }

    int wnum, qid, nrow, numread, pos;
    char token[2048], junk[2048];
    double value, target;
    vector<double> words;
    vector<int> fidxs;
    vector<Attribute*> attrs; // a temporary vector holds the newly-created Attributes
    
    pos = 0;
    nrow = 0;
    target = MISSING;

    label_type_.name = "Label";
    label_type_.type = Attribute::CATEGORICAL;

    int num_features = 0;

    char * line = new char[MAX_LINE];
    while (fgets(line, MAX_LINE, file) != NULL) { // for each line
        nrow++;
        size_t len = strlen(line);
        if (len!=0 && line[len-1] == '\n') {
            line[len-1] = '\0';
        } else if (len == MAX_LINE - 1) {
            printf("Line length exceeds the MAX_LINE!\n");
            exit(1);
        }

        if (line[0] == '#') continue;
        if (sscanf(line,"%s",token) == EOF) continue;
        pos=0;
        while((token[pos] != ':') && token[pos]) pos++;
        if (token[pos] == ':') {
            perror ("Line must start with label or 0!!!\n"); 
            printf("LINE: %s\n",line);
            exit(1); 
        }
        // read the target value
        if (sscanf(line,"%lf", &target) == EOF) 
            continue;

        if (!IsInteger(target))
            label_type_.type = Attribute::NUMERIC;

        pos=0;
        while (isspace((int)line[pos])) pos++; //skip space
        while((!isspace((int)line[pos])) && line[pos]) pos++; //skip target
        
        // for each token
        while(((numread=sscanf(line+pos,"%s",token)) != EOF) &&
                numread > 0) {
            while(isspace((int)line[pos])) pos++;
            while((!isspace((int)line[pos])) && line[pos]) pos++;

            if (token[0] == '#') break;
            if (sscanf(token,"qid:%d%s",&wnum,junk)==1) { // qid
                qid = (int)wnum; // NOTE: qid is ignored in this version
            } else if (sscanf(token,"%d:%lf%s",&wnum,&value,junk)==2) { // regular feature pair
                fidxs.push_back(wnum); // feature index
                words.push_back(value); // feature value

                // resize the attributes vector if more attributes are read
                int old_size = attrs.size();
                if (wnum > old_size) {
                    attrs.resize(wnum, NULL);
                    for (int j=old_size; j<wnum; ++j) {
                        attrs[j] = new Attribute();
                    }
                }

                if (!IsInteger(value))
                    attrs[wnum-1]->type = Attribute::NUMERIC;

                if (wnum<=0) { 
                    perror("Feature number must be larger or equal to 1!!!\n"); 
                    printf("LINE: %d\n",nrow);
                    exit(1); 
                }
            } else {
                perror("Cannot parse feature/value pair!!!\n"); 
                printf("'%s' in LINE: %d\n",token, nrow);
                exit(1);         
            }
        }

        if (num_features < fidxs[fidxs.size()-1])
            num_features = fidxs[fidxs.size()-1];

        Instance * inst = new Instance();
        inst->features = new double[num_features];
        inst->num_features = num_features;
        fill(inst->features, inst->features+num_features, MISSING);
        inst->label = target;
        inst->weight = 1.0;
        for (size_t f=0; f<fidxs.size(); f++)
            inst->features[fidxs[f]-1] = words[f];    
        instances_.push_back(inst);
        
        fidxs.clear();
        words.clear();
    }

    delete[] line;
    // Check label type


    // Check all attributes 
    for (size_t j=0; j<attrs.size(); ++j) {
        if (attrs[j]->type == Attribute::CATEGORICAL) {// get number of classes
            set<int> uniq_count;
            for (size_t i=0; i<instances_.size(); ++i) {
                uniq_count.insert((int) instances_[i]->features[j]);
            }
            attrs[j]->num_classes = uniq_count.size();
        }
    }

    // Spanning each Instance to the the num_features
    for (size_t i=0; i<instances_.size(); i++) {
        Instance* inst = instances_[i];
        if (inst->num_features < num_features) {
            double* fts = new double[num_features];
            copy(inst->features, inst->features + inst->num_features, fts);
            fill(fts + inst->num_features, fts + num_features, MISSING);
            delete[] inst->features;
            inst->features = fts;
        }
    }

    // Put Attributes to the member variables
    attributes_.reserve(attrs.size());
    for (size_t j=0; j<attrs.size(); ++j) {
        attributes_.push_back(attrs[j]);
    }
}


void Dataset::ReleaseInstances() {
    for (size_t i=0; i<instances_.size(); ++i) {
        delete instances_[i];
        instances_[i] = NULL;
    }
    instances_.clear();
}


void Dataset::ReleaseAttributes() {
    for (size_t i=0; i<attributes_.size(); ++i) {
        delete attributes_[i];
        attributes_[i] = NULL;
    }
    attributes_.clear();
}
