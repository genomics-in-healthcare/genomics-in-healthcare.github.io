#ifndef RF_PRESORTER_H
#define RF_PRESORTER_H

#include <vector>
#include "instance.h"

// Sort instances by each feature and store the results
class PreSorter {
    std::vector<int*> sorted_list_;
    
public:
    PreSorter(const std::vector<const Instance*>& instances);
    ~PreSorter();

    // get sorted instances orderred by feature fIdx
    const int * sorted_list(int fid) const {return sorted_list_[fid];}
};


#endif
