#include "weighted_sampling.h"

#include <cstdlib>


using namespace std;

WeightedSampler::WeightedSampler(const std::vector<double>& weights) {
    m_ = (int)weights.size();
    weights_ = new double[m_];
    cum_weights_ = new double[m_];

    remaining_ = new int[m_];
    cum_remaining_ = new int[m_];

    for (int i=0; i<m_; ++i) {
        weights_[i] = weights[i];
        cum_weights_[i] = weights[i];
        remaining_[i] = 1;
        cum_remaining_[i] = 1;
    }

    // make the binary tree; cweights[0] contains the total weights
    for (int i = m_-1; i>0; --i) {
        cum_weights_[(i - 1) >> 1] += cum_weights_[i];
        cum_remaining_[(i - 1) >> 1] += cum_remaining_[i];
    }

}



WeightedSampler::~WeightedSampler() {
    delete[] weights_;
    delete[] cum_weights_;
    delete[] remaining_;
    delete[] cum_remaining_;
}

int WeightedSampler::SampleByWeight() {
    double gas = cum_weights_[0] * (rand() / (double)RAND_MAX);

    int i = 0;
    while (gas > weights_[i]) {
        gas -= weights_[i];
        i = (i<<1) + 1; //Move to left child
         
        if (gas > cum_weights_[i]) {
            gas -= cum_weights_[i];
            i+=1;
        }
    }
    int idx = i; 
    double w = weights_[i];
    weights_[idx] = 0;
    remaining_[idx] = 0; 
    
    while (i>0) {
        cum_weights_[i] -= w;
        cum_remaining_[i] -= 1;
        i = (i-1) >> 1;
    }
    cum_weights_[i] -= w;
    cum_remaining_[i] -= 1;

    return idx;
}

int WeightedSampler::SampleRemaining() {
    double gas = cum_remaining_[0] * (rand() / (double)RAND_MAX);

    int i = 0;
    while (gas > remaining_[i]) {
        gas -= remaining_[i];
        i = (i<<1) + 1; //Move to left child
        if (gas > cum_remaining_[i]) {
            gas -= cum_remaining_[i];
            i+=1;
        }
    }
    int idx = i; 
    remaining_[idx] = 0; 
    
    while (i>0) {
        cum_remaining_[i] -= 1;
        i = (i-1) >> 1;
    }
    cum_remaining_[i] -= 1;

    return idx;
}


vector<int> WeightedSampler::Sample(int k) {
    vector<int> idxs(k);
    int i = 0;
    while ( (i<k) && (cum_weights_[0] > 0.00001) ) {
        idxs[i] = SampleByWeight();
        ++i;
    }
    while (i<k) {
        idxs[i] = SampleRemaining();
        ++i;
    }
    return idxs;
}
