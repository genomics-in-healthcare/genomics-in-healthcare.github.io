#include <algorithm>
#include <iostream>
#include "misc.h"

#include "corrnet.h"

using namespace std;

CorrelationNet::CorrelationNet(const vector<const Instance*>& insts, const vector<const Attribute*>& attrs) {
    int m = (int)attrs.size();
    int n = (int)insts.size();


    vector< vector<int> > dscrt_data;
    Discretize(insts, attrs, &dscrt_data);

    corr_net_.assign(m*m, 0.0);
        
    for (int j1=0; j1<m; ++j1) {                 // for each feature 
        corr_net_[j1*m+j1] = 0.0;                // set the self-correlation to 0.0 for better ranking  
        for (int j2=j1+1; j2<m; ++j2) {          // for each feature
            /////////////////////////////////////////////////////////////////////////////////////////////////////////
            // For continuous features
            if (attrs[j1]->type == Attribute::NUMERIC
                && attrs[j2]->type == Attribute::NUMERIC) {
                // if both attributes are continuous then calculate the pearson's correlation coefficient (PCC)
                double x, y, x2, y2, xy;
                double a,b, denom;
                x = y = x2 = y2 = xy = 0.0;
                for (int i=0; i<n; ++i) {
                    a = insts[i]->features[j1];
                    b = insts[i]->features[j2];
                    x += a;
                    y += b;
                    x2 += a*a;
                    y2 += b*b;
                    xy += a*b;
                }
                denom = (n*x2 - x*x)*(n*y2 - y*y);
                if (denom != 0) {
                    corr_net_[j1*m+j2] = abs((double)(n*xy - x*y) / sqrt((double)denom));
                    corr_net_[j2*m+j1] = corr_net_[j1*m+j2];
                }
            /////////////////////////////////////////////////////////////////////////////////////////////////////////
            // For categorical features
            } else {
                // if both attributes are categorical then calculate the mutual information (MI)
                double nmi = NormMutualInformation( dscrt_data[j1], dscrt_data[j2], 3, 3);      
                corr_net_[j1*m+j2] = nmi;
                corr_net_[j2*m+j1] = nmi;
            }
        }
    }

    Sparsify(attrs);

    FILE *file;
    if ((file = fopen("corrnet.tsv", "w")) == NULL) { 
        perror("corrnet.tsv"); 
        exit(-1); 
    }

    map<int, map<int, double> >::const_iterator row_it = sp_net_.begin();
    map<int, double>::const_iterator col_it;
    for (row_it = sp_net_.begin(); row_it != sp_net_.end(); ++row_it) {
        for (col_it = row_it->second.begin(); col_it != row_it->second.end(); ++col_it) {
            fprintf(file, "%d %d %lf\n", row_it->first + 1, col_it->first+1, col_it->second);
        }
    }
    fclose(file);
}


void CorrelationNet::Sparsify(const vector<const Attribute*>& attrs) {
    const int rank1 = 5;
    const double t1 = 0.5;
    const int rank2 = 50;
    const double t2 = 0.8;

    int m = (int)attrs.size();

    vector< pair<int, double> > num_order;
    vector< pair<int, double> > cat_order;
    num_order.reserve(m);
    cat_order.reserve(m);

    for (int j1=0; j1<m; ++j1) {
        num_order.clear();
        cat_order.clear();
        for (int j2=0; j2<m; ++j2) {
            if (attrs[j2]->type == Attribute::NUMERIC) {
                num_order.push_back(make_pair(j2, corr_net_[j1*m + j2]));
            } else if (attrs[j2]->type == Attribute::CATEGORICAL) {
                cat_order.push_back(make_pair(j2, corr_net_[j1*m + j2]));
            }
        }
        int nnumeric = (int)num_order.size(); // number of numeric attributes
        int ncategorical = (int)cat_order.size(); // number of categorical attributes
        int nnum_top = min(rank2, nnumeric);      
        int ncat_top = min(rank2, ncategorical);

        vector<int> num_rank(nnumeric);
        vector<int> cat_rank(ncategorical);

        PartialSort(num_order, nnum_top, &num_rank);
        PartialSort(cat_order, ncat_top, &cat_rank);

        for (int j=0; j<nnum_top; ++j) {
            if (j<=rank1 && num_order[j].second > t1) {
                sp_net_[j1][num_order[j].first] = num_order[j].second;
                sp_net_[num_order[j].first][j1] = num_order[j].second;
            } else if (j <= rank2 && num_order[j].second > t2) {
                sp_net_[j1][num_order[j].first] = num_order[j].second;
                sp_net_[num_order[j].first][j1] = num_order[j].second;
            } else 
                break;
        }

        for (int j=0; j<ncat_top; ++j) {
            if (j<=rank1 && cat_order[j].second > t1) {
                sp_net_[j1][cat_order[j].first] = cat_order[j].second;
                sp_net_[cat_order[j].first][j1] = cat_order[j].second;
            } else if (j <= rank2 && cat_order[j].second > t2) {
                sp_net_[j1][cat_order[j].first] = cat_order[j].second;
                sp_net_[cat_order[j].first][j1] = cat_order[j].second;
            } else 
                break;
        }
    }
}

void CorrelationNet::PartialSort(vector< pair<int, double> >& order, int partial_k, vector<int>* index) {
    int n = (int)order.size();
    partial_sort(order.begin(), order.begin() + partial_k, order.end(), greater_ordering());
    for (int i=0; i<n; i++) {
        (*index)[i] = order[i].first;
    }
}


double CorrelationNet::NormMutualInformation(const vector<int>& x, const vector<int>& y, int nc1, int nc2) {
    int n = (int)x.size();
    vector<int> xy(nc1*nc2, 0);
    vector<int> marx(nc1, 0);
    vector<int> mary(nc2, 0);
    int a,b;            
    for (int i=0; i<n; ++i) {  // get the frequency count
        a = x[i];
        b = y[i];
        xy[a*nc2+b] += 1;
        marx[a] += 1;
        mary[b] += 1;
    }
    double mi = 0.0;
    double hxy = 0.0;
    for (int a=0; a<nc1; ++a) {
        for (int b=0; b<nc2; ++b) {
            if (xy[a*nc2+b] != 0) {
                mi += xy[a*nc2+b] * log2(xy[a*nc2+b]*n /(double)(marx[a]*mary[b]));
                hxy -= xy[a*nc2+b] * log2((double)xy[a*nc2+b] / n);
            }
        }
    }
    return mi/hxy;
}


void CorrelationNet::Discretize(const vector<const Instance*>& insts, const vector<const Attribute*>& attrs,
                                vector< vector<int> >* ddata)
{
    int n = (int)insts.size();
    int m = (int)attrs.size();

    ddata->reserve(m);
    for (int j=0; j<m; ++j) {
        ddata->push_back(vector<int>(n, 0));
        vector<int>& d = (*ddata)[j];
        if (attrs[j]->type == Attribute::NUMERIC) {
            double x = 0.0;
            double x2 = 0.0;
            for (int i=0; i<n; ++i) {
                x += insts[i]->features[j];
                x2 += insts[i]->features[j] * insts[i]->features[j];
            }
            double mean = x / n;
            double stdev = sqrt((x2 - x*x/n) / (n-1));
           
            for (int i=0; i<n; ++i) {
                if (insts[i]->features[j] < mean - stdev) {
                    d[i] = 0;
                } else if (insts[i]->features[j] >= mean + stdev) {
                    d[i] = 2;
                } else {
                    d[i] = 1;
                }
            }
        } else {
            for (int i=0; i<n; ++i) {
                d[i] = (int)insts[i]->features[j];
            }
        }
    }
}
