#include <cmath> // sqrt
#include <stack>
#include <algorithm> // sort

#include "misc.h"
#include "regression_tree.h"
#include "weighted_sampling.h"

using namespace std;

// an empty constructor
RegressionTree::RegressionTree() : 
    error_dcrs_(NULL) ,
    weighted_sampling_(false){
}


RegressionTree::~RegressionTree() {
    RemoveNodes();
}


// build a regreesion tree using the original data
void RegressionTree::Train(const vector<const Instance*>& insts, const vector<int>& ft_idxs, const ArgType& args) {
    instances_ = &insts;
    args_ = args;

    vector<int> shuffled_ft_idxs(ft_idxs); // shuffled feature idxs
   
    //
    // Stack based implmentation of recursion
    //
    stack<int> st_nodes;
    stack< vector<const Instance*> > st_insts;

    nodes_.push_back(new RtNode());
    st_nodes.push(0);
    st_insts.push(insts);

    while (!st_nodes.empty() && !st_insts.empty()) {
        int nodeidx = st_nodes.top(); 
        st_nodes.pop();
        vector<const Instance*>& insts = st_insts.top();
        
        RtNode* node = nodes_[nodeidx];

        // Initialize node attributes
        node->feature = -1;
        node->value = MISSING;
        node->leaf = false;
        node->pred = Average(insts);
        node->leftchild = -1;
        node->rightchild = -1;

        // Check if it satisfy the termination criteria
        if (IsTerminal(insts)) {    
            node->leaf = true;
            st_insts.pop();
            continue;
        }

        vector<int> selected_ids;
        if (guide_ && weighted_sampling_) {
            selected_ids = guide_->SampleFeatures();  
        }
        else {
            random_shuffle(shuffled_ft_idxs.begin(), shuffled_ft_idxs.end());
            selected_ids.assign(shuffled_ft_idxs.begin(), shuffled_ft_idxs.begin() + args_.mtry);
        }

        int fsplit;
        double vsplit;
        vector<const Instance*> leftinsts, rightinsts;
        // Decide the splitting crietia based on given data
        double error_dcrs = SplitNode(insts, selected_ids, &leftinsts, &rightinsts, &fsplit, &vsplit); 
        if (error_dcrs > 0) {
            node->feature = fsplit;
            node->value = vsplit;
            node->leaf = false;

            // Record feature contributions to error_decreasing
            if (error_dcrs_ && insts.size() >= 3) {
                (*error_dcrs_)[fsplit] += error_dcrs;
                (*feature_count_)[fsplit] += 1;
            }

            st_insts.pop();
            
            if (leftinsts.size() != 0) { // create Left node
                node->leftchild = nodes_.size();
                st_insts.push(leftinsts);
                st_nodes.push(node->leftchild);
                RtNode * child = new RtNode();
                child->parent = node;
                nodes_.push_back(child);
            }
            
            if (rightinsts.size() != 0) { // create Right node
                node->rightchild = nodes_.size();
                st_insts.push(rightinsts);
                st_nodes.push(node->rightchild);
                RtNode * child = new RtNode();
                child->parent = node;
                nodes_.push_back(child);
            }
        } else { // No further splitting is needed
            node->feature = -1;
            node->value = MISSING;
            node->leaf = true;
        }
    }
} 


// Split at a node with given data samples
// Return the minial squared loss on this node
// If all selected features are the same then
// return RF_DBL_MAX
double RegressionTree::SplitNode(const vector<const Instance*>& insts, const vector<int>& selected_ids, vector<const Instance*>* left_insts, 
                                 vector<const Instance*>* right_insts, int* fsplit, double* vsplit){
    int n = insts.size();
    int mtry = (int)selected_ids.size();

    double max_error_dcrs = 0.0;

    // r and ybr is the same for all features so it is calculated outside the features loop
    double r, ybr;
    r = ybr = 0.0;
    for (int i = 0; i < n; i++) {
        double lbl = insts[i]->label;
        r += lbl * lbl;
        ybr += lbl;
    }
    ybr /= n;

    // vector of vector indicate which instance should be put into the left child 
    vector< vector<int> > splition;
    splition.resize(mtry);
    for (int j=0; j<mtry; ++j)
        splition[j].assign(n,0);

    vector<int>* best_splition = NULL;
    
    /*
    int numthreads = args_.numthreads;
    SplitParams * splitparams = new SplitParams[numthreads];
    double * error_dcrs = new double[numthreads];
    double * vs = new double[numthreads];
    int * fids = new int[numthreads];
    boost::thread** threads = new boost::thread*[numthreads];

    // for each selected feature
    for (int p=0; p < numthreads; ++p) {
        error_dcrs[p] = 0.0;
        splitparams[p].ft_idxs = ft_idxs;
        splitparams[p].start = p*mtry/numthreads;
        splitparams[p].end = (p+1)*mtry/numthreads;
        splitparams[p].r = r;
        splitparams[p].ybr = ybr;
        threads[p] = new boost::thread(boost::bind(FindSplitInRange, boost::ref(insts), &splitparams[p], &fids[p], &vs[p], &error_dcrs[p], &splition)); 
    }

    for (int p=0; p < numthreads; ++p) {
        threads[p]->join(); 
        delete threads[p];

        if (error_dcrs[p] > max_error_dcrs) {
            max_error_dcrs = error_dcrs[p];
            *fsplit = ft_idxs[fids[p]];
            *vsplit = vs[p];
            best_splition = &splition[fids[p]];
        }
    }
 
    delete[] threads;
    delete[] error_dcrs;
    delete[] vs;
    delete[] fids;
    delete[] splitparams;
    */
    
    double vs = 0.0;
    double err_dcrs = 0.0;
    for (int j=0; j<mtry; ++j) {
        
        int f = selected_ids[j];
        FindSplit(insts, r, ybr, f, &vs, &err_dcrs, &splition[j]);

        if (err_dcrs > max_error_dcrs) {
            max_error_dcrs = err_dcrs;
            *fsplit = f;
            *vsplit = vs;
            best_splition = &splition[j];
        }
    }


    // Output left and right child instances
    for (int i=0; i<n; ++i) {
        if ((*best_splition)[i] != 0) {
            left_insts->push_back(insts[i]);
        } else {
            right_insts->push_back(insts[i]);
        }
    }

    // calculate the correlation between features
    /*
    double* corrs = new double[mtry];
    int* corrs_idx = new int[mtry];
    for (int j=0; j<mtry; ++j) {
        // get the Pearson's correlation
        corrs[j] = 0.0;
        int x, y, x2, y2, xy;
        x = y = x2 = y2 = xy = 0;
        for (int i=0; i<n; ++i) {
            int a = splition[j][i];
            int b =  (*best_splition)[i];
            x += a;
            y += b;
            x2 += a*a;
            y2 += b*b;
            xy += a * b;
        }
        int denom = (n*x2 - x*x)*(n*y2 - y*y);
        if (denom != 0) {
            corrs[j] = abs((double)(n*xy - x*y) / sqrt((double)denom));
        }
        //(*feature_corr_)[ft_idxs[j]*m + *fsplit] += 1;
        //(*feature_count_)[ft_idxs[j]*m + *fsplit] += 1;
    }
    */

    /*
    misc::sort_by_index_descend(corrs, corrs_idx, mtry);
    for (int j=0; j<64; j++) {
        int f = ft_idxs[corrs_idx[j]];
    }
    */

    //delete[] corrs;
    //delete[] corrs_idx;

    return max_error_dcrs;
}

/*
void RegressionTree::FindSplitInRange(const vector<const Instance*>& insts, const SplitParams* sparam, 
                                       int* best_fid, double* vsplit, double* max_error_dcrs, vector< vector<int> >* splition)
{
    int start = sparam->start;
    int end = sparam->end;

    double v;
    double err_dcr;
    for (int j=start; j<end; ++j) {
        int f = sparam->ft_idxs[j];
        FindSplit(insts, sparam->r, sparam->ybr, f, &v, &err_dcr, &((*splition)[j]));
        if (err_dcr > *max_error_dcrs) {
            *max_error_dcrs = err_dcr;
            *vsplit = v;
            *best_fid = j;
        }
    }
}
*/


// Find the best splitting point given a feature and data using Dynamic Programming
// Return square loss decrease (NOTE: not the root mean square loss)
void RegressionTree::FindSplit(const vector<const Instance*>& insts, double r, double ybr, 
                                 int f, double* vsplit, double* se_dcr, vector<int>* splition) 
{
    int n = insts.size();
    vector<const Instance*> sorted_data(n);
    vector<int> dataidxs(n);
    SortInstances(insts, &sorted_data, &dataidxs, f);

    // we have squared error = \sum_{i=1..n} (yi - ybar)^2
    // we want the squared error for left and right splits for all splits k
    // let ybl = ybar left, ybr = ybar right
    //     s = E_{i=0..k} yi^2
    //     r = E_{i=k+1..n} yi^2
    // NOTE: The initial value of r and ybr is calculated before hand because it is independent of feature  
    double ybl, s, L, R, SE;
    L = R = ybl = s = 0.0;

    double orignal_se = r - n*ybr*ybr; //squared error at ervything on the right
    double min_se = orignal_se; // minimum squared error achived

    int bestidx = 0;  // default split point
    *vsplit = sorted_data[0]->features[f];


    // for every i
    // put yi into left side, remove it from the right side, and calculate squared loss
    for (int i = 0; i<n-1; i++) {
        int j = i;

        double yn = sorted_data[i]->label; // next y
        s += yn * yn;
        r -= yn * yn;
        
        ybl = (j*ybl + yn) / (j+1);
        ybr = ((n-j)*ybr - yn) / (n-j-1);

        // do not consider splitting here if data is the same as next
        if ( sorted_data[i]->features[f] ==  sorted_data[i+1]->features[f])
            continue;
        
        L = s - (j+1)*ybl*ybl;
        R = r - (n-j-1)*ybr*ybr;
        
        SE = L + R; // total square error

        if (SE < min_se) {
            min_se = SE;
            for (int u = bestidx; u <= i; ++u) {
                (*splition)[dataidxs[u]] = 1;
            }
            bestidx = i;
            *vsplit = (sorted_data[i]->features[f] +  sorted_data[i+1]->features[f]) / 2; // split in the middle
        }
    }

    (*se_dcr) = orignal_se - min_se;
}


// Get the Average label of given data indices
double RegressionTree::Average(const vector<const Instance*>& insts) {
    double sum = 0.0;
    int n = insts.size();
    for (int i=0; i<n; i++) {
        sum += insts[i]->label;
    }
    return sum/n;
}


// Check if the termination condition is satisfied
bool RegressionTree::IsTerminal(const vector<const Instance*>& insts) {
    int n = insts.size(); 
    if (n <= args_.nodesize)
        return true;
    else
        return IsSame(insts); // If all samples have the same label then it's a leaf
}


// Check if all given samples have the same label
bool RegressionTree::IsSame(const vector<const Instance*>& insts) {
    int n = insts.size();
    double first = insts[0]->label;
    for (int i=1; i<n; i++) {
        if (insts[i]->label != first)
            return false;
    }
    return true;
}


// Get the squared loss of given data
double RegressionTree::GetSe(const vector<const Instance*>& insts) {
    double pred = Average(insts);
    int n = insts.size();
    double sum = 0.0;
    for (int i=0; i<n; i++) {
        sum += (insts[i]->label - pred)*(insts[i]->label - pred);
    }
    return sum;
}


// Clear all nodes and release the memory
void RegressionTree::RemoveNodes() {
    int n = nodes_.size();
    for (int i=0; i<n; i++) {
        delete nodes_[i];
        nodes_[i] = NULL;
    }
}


// Get the prediction of one Instance 
double RegressionTree::Predict(const Instance& inst) {
    int n = nodes_.size();
    int i = 0;
    double pred = MISSING;
    while (i>=0 && i<n) {
        RtNode* node = nodes_[i];
        pred = node->pred;
        if (node->leaf) {
            return pred;
        }

        int f = node->feature;
        double v = node->value;
        if (inst.features[f] < v) 
            i = node->leftchild;
        else
            i = node->rightchild;
    }

    return pred;
}


// Predict the label of given instances. Output to predicts vector
vector<double> RegressionTree::Predict(const vector<const Instance*>& insts) {
    int n = insts.size();
    vector<double> preds(n);
    for (int i=0; i<n; i++)
        preds[i] = Predict(*insts[i]);
    return preds;
}


// Evaluate the RMSE of the tree given the prediction
double RegressionTree::Evaluate(const vector<const Instance*>& insts, const vector<double>& predicts) {
    int n = insts.size();
    double err = 0.0;
    for (int i=0; i<n; i++) {
        err += (predicts[i] - insts[i]->label)*(predicts[i] - insts[i]->label);
    }
    return sqrt(err/n);
}


void RegressionTree::SortInstances(const vector<const Instance*>& data, vector<const Instance*>* sorted_data, vector<int>* index, int f) {
    int n = (int)data.size();
    vector< pair<int, double> > order(n);
    for (int i=0; i<n; i++)
        order[i] = make_pair(i, data[i]->features[f]);
    sort(order.begin(), order.end(), less_ordering());
    for (int i=0; i<n; i++) {
        (*index)[i] = order[i].first;
        (*sorted_data)[i] = data[order[i].first];
    }
}


//==================================================================================
// I/O functions


// Output one tree to a output stream
void RegressionTree::PutTree(std::ostream& ost) const {
    int n = nodes_.size();
    string sep = " ";
    ost << n << endl;
    for (int i=0; i<n; i++) {
        ost << nodes_[i]->feature << sep;
        ost << nodes_[i]->value << sep;
        ost << nodes_[i]->pred << sep;
        ost << nodes_[i]->leftchild << sep;
        ost << nodes_[i]->rightchild << endl;
    }
}
ostream& operator<< (ostream& o, const RegressionTree & rt) { rt.PutTree(o); return o; }


// Create a tree from an input stream (recover nodes info)
bool RegressionTree::GetTree(istream& ist) {
    RemoveNodes();
    int n;
    ist >> n;
    for (int i=0; i<n; i++) {
        RtNode * node = new RtNode();
        nodes_.push_back(node);

        ist >> node->feature;
        ist >> node->value; 
        ist >> node->pred;
        ist >> node->leftchild;
        ist >> node->rightchild;
        
        if (node->leftchild == -1 && node->rightchild == -1)
            node->leaf = true;
    }
    return true;
}
int operator>> (istream& i, RegressionTree& rt) {return rt.GetTree(i);}
