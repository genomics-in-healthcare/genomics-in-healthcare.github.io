#include <cstdio>
#include <cmath>
#include <iostream>
#include <algorithm>
#include "rf_guide.h"

using namespace std;

RfGuide::RfGuide() {
    
}

RfGuide::~RfGuide() {
    
}


// Read correlation network and module structure from file
void RfGuide::ReadNetwork(const char* prefix) {
    char filename[2045];
    sprintf(filename, "%s.mod", prefix);

    FILE *file;
    if ((file = fopen (filename, "r")) == NULL) { 
        perror(filename); 
        exit(-1); 
    }

    int fid, mid;
    num_mods_ = -1;
    while (fscanf(file, "%d\t%d", &fid, &mid)!=EOF) {
            ft2mod_.push_back(mid);
            if (num_mods_ < (mid+1))
                num_mods_ = mid+1;
    }
    fclose(file);

    num_features_ = (int)ft2mod_.size();
    mod_idxs_.resize(num_mods_);
    for (int k=0; k<num_mods_; ++k)
        mod_idxs_[k] = k;

    vector<int> ft_idxs(num_features_);
    for (int j=0; j<num_features_; ++j)
        ft_idxs[j] = j;

    sprintf(filename, "%s.cor", prefix);
    net_.ReadSparse(filename);

    // Initialize module and feature weights
    SetFeatureWeights(vector<double>(num_features_, 0.0), ft_idxs);
}


// Update both module and feature weights
void RfGuide::SetFeatureWeights(const std::vector<double>& weights, const std::vector<int>& fids) {
    vector<int> availible_mods(num_mods_, 0);
    
    // remap availible features
    module_struct_.assign(num_mods_, vector<int>()); 
    ft2sub_.resize(num_features_);

    for (size_t j=0; j<fids.size(); ++j) {
        int fid = fids[j];
        int mid =  ft2mod_[fid];
        ft2sub_[fid] = (int)module_struct_[mid].size();
        module_struct_[mid].push_back(fid);
        availible_mods[mid] = 1;  // set used flag
    }

    // renew mod_idxs_ (modules which have active features)
    mod_idxs_.clear();
    for (int k=0; k<num_mods_; ++k) {
        if (availible_mods[k]==1)
            mod_idxs_.push_back(k);
    }

    // resize weights vectors
    vector<double> allmod_wts(num_mods_);
    ft_weights_.assign(num_mods_, vector<double>());
    for (int k=0; k<num_mods_; ++k) {
        ft_weights_[k].assign( module_struct_[k].size(), 0.0);
    }
    
    for (size_t j=0; j<fids.size(); ++j) {
        int fid = fids[j];
        int modidx = ft2mod_[fid];
        int idx = ft2sub_[fid];
        allmod_wts[modidx] += weights[fid];
        ft_weights_[modidx][idx] = weights[fid];
    }

    mod_weights_.assign(mod_idxs_.size(), 0.0);
    for (size_t k=0; k<mod_idxs_.size(); ++k) {
        mod_weights_[k] = allmod_wts[mod_idxs_[k]];
    }

}


// SampleFeatures
vector<int> RfGuide::SampleFeatures() {
    int nmods = (int)mod_idxs_.size();
    int mod_k1 = min(max(nmods / 3, 3), nmods);
    int mod_k2 = min(max((int)sqrt((double)nmods), 3), mod_k1);
    //int mod_k2 = min(max(nmods/10, 3), mod_k1);

    vector<int> sampled_fts;

    vector<int> idxs = Sampling(mod_weights_, mod_k1, mod_k2);  
    // For each select module
    for (int i=0; i<mod_k2; ++i) {
        int mid = mod_idxs_[idxs[i]];
        int n_i = module_struct_[mid].size();

        int ft_k1 = /*min(n_i, 5);*/  max(n_i / 3, 1);
        int ft_k2 = min(ft_k1, 1);

        vector<int> selected = Sampling(ft_weights_[mid],ft_k1, ft_k2);
        
        for (size_t j=0; j<selected.size(); ++j) {
            sampled_fts.push_back( module_struct_[mid][selected[j]] );
        }
    }

    return sampled_fts; 
}


// Two-step sampling
vector<int> RfGuide::Sampling(const vector<double>& weights, int k1, int k2) {
    vector<int> idxs(k2);

    WeightedSampler ws(weights);
    vector<int> idxs1 = ws.Sample(k1);

    random_shuffle(idxs1.begin(), idxs1.end());
    for (int i=0; i<k2; ++i)
        idxs[i] = idxs1[i];
    return idxs;
}



vector<double> RfGuide::CorrectVariableImportance(const vector<double>& vi) {
    return net_.Multiply(vi);
}



void RfGuide::WriteModudleWeights(const char* filename) {
    FILE *file;
    if ((file = fopen(filename, "w")) == NULL) { 
        perror(filename); 
        exit(-1); 
    }

    double sum = 0.0;
    for(size_t i=0; i<mod_idxs_.size(); ++i) {
        sum += mod_weights_[i];
    }

    for(size_t i=0; i<mod_idxs_.size(); ++i) {
        fprintf(file, "%d\t%lf\n", mod_idxs_[i], mod_weights_[i] / sum);
    }

    fclose(file);
}
