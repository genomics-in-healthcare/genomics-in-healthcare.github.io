#ifndef RF_TREE_NODE_H
#define RF_TREE_NODE_H

#include <set>

typedef struct _st_tree_node {
    int feature; //feature index which the node splits on
    double value; // feature value which the node splits on for continous feature type (for continous variable)
    std::set<int> leftcates; // categories go to the left child (for categorical variable)
    double pred; // label prediction
    int leftchild; // index of left child node
    int rightchild; // index of right child node

    bool leaf; // whether it is a leaf node
    struct _st_tree_node * parent;
} TreeNode;


#endif
