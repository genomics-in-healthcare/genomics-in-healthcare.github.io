#ifndef RF_CROSSVALID_H
#define RF_CROSSVALID_H

#include <vector>
#include "instance.h"
#include "args.h"

class CrossValid {

public:
    static double Evaluate(const std::vector<const Instance*>& data, const ArgType& args);
};


#endif
