#ifndef RF_FEATURE_MODULES_H
#define RF_FEATURE_MODULES_H

#include <vector>
#include "sparse_matrix.h"
#include "weighted_sampling.h"

class RfGuide {
public:
    RfGuide();
    ~RfGuide();

    void ReadNetwork(const char* prefix);

    void SetFeatureWeights(const std::vector<double>& weights, const std::vector<int>& ft_idxs); // This will update both module and feature weights
    
    std::vector<int> SampleFeatures(); 

    std::vector<double> CorrectVariableImportance(const std::vector<double>& vi);

    void WriteModudleWeights(const char* filename);

    size_t num_modules() {return mod_idxs_.size();}

private:
    std::vector<int> Sampling(const std::vector<double>& weights, int k1, int k2);


private:
    int num_mods_; // number of modules
    int num_features_; // number of total features

    SparseMatrix net_;



    std::vector< std::vector<int> > module_struct_;          // indices of feature in each module
    std::vector<int> ft2mod_;   // map from a feature index to module index
    std::vector<int> ft2sub_;   // given a feature map to its sub index in its module
    std::vector<int> mod_idxs_;  // all availible modules
     

    std::vector<double> mod_weights_;
    std::vector< std::vector<double> > ft_weights_;
};

#endif
