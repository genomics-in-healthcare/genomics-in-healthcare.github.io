#ifndef RF_WEIGHTED_SAMPLING_H
#define RF_WEIGHTED_SAMPLING_H

#include <vector>

class WeightedSampler {
public:
    WeightedSampler(const std::vector<double>& weights);
    ~WeightedSampler();
    std::vector<int> Sample(int k);



private:
    int SampleByWeight();
    int SampleRemaining();
    
    double * weights_;    // weights
    double * cum_weights_;   //cumulative weights
    int * remaining_;
    int * cum_remaining_;
    int m_;

};

#endif


