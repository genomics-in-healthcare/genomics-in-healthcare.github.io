#include <iostream>
#include <fstream>
#include <cmath>
#include <ctime>

#include "misc.h"
#include "instance.h"
#include "regression_tree.h"
#include "random_forests.h"
#include "cross_valid.h"
#include "rfe.h"
#include "args.h"
#include "corrnet.h"
#include "rf_guide.h"

using namespace std;

int main(int argc, char* argv[]) {
    srand ( (unsigned int)time(NULL) );

    ArgType args;
    if (parse_parameter(argc, argv, &args) != 0) {
        exit(-1);
    }

    cerr << misc::current << " Read input file at \"" << args.input_file << "\"" << endl;
    
    Dataset data; 
    data.ReadFile(args.input_file.c_str());
    const vector<const Instance*> insts = data.instances();
    cerr << "           " << " number of instances: " << data.num_instances() << endl;
    cerr << "           " << " number of features: " << data.num_features() << endl;

    Dataset data_valid;
    Dataset data_test;
    // Read validation file
    if (args.valid_input != "") {
        cerr << misc::current << " Read validation data at \"" << args.valid_input << "\"" << endl;
        data_valid.ReadFile(args.valid_input.c_str());
        cerr << "           " << " number of instances: " << data_valid.num_instances() << endl;
        cerr << "           " << " number of features: " << data_valid.num_features() << endl;
    }

    //Read test file
    if (args.test_input != "") {
        cerr << misc::current << " Read test data at \"" << args.test_input << "\"" << endl;
        data_test.ReadFile(args.test_input.c_str());
        cerr << "           " << " number of instances: " << data_test.num_instances() << endl;
        cerr << "           " << " number of features: " << data_test.num_features() << endl;
    }


    // set default mtry if mtry is not set
    if (args.mtry == -1)
        args.mtry = (int)sqrt((float)data.num_features());

    //==========================================================================================
    // learning or diagnose
    if (args.mode == 'l' || args.mode == 'd') {

        RfGuide* guide = NULL;
        if (args.guide!="") {
            guide = new RfGuide();
            guide->ReadNetwork(args.guide.c_str());
        }

        string mode_info;
        if (args.mode == 'l')
            mode_info = "Learning";
        else
            mode_info = "Debuging";

        cerr << misc::current << " Start training the Random Forest..." << endl;
        cerr << "           " << " Mode: " << mode_info << endl;
        cerr << "           " << " number of trees: " << args.ntrees << endl;
        cerr << "           " << " number of random features: " << args.mtry << endl;
        cerr << "           " << " maximum node size: " << args.nodesize << endl;
        cerr << "           " << " maximum depth: " << args.maxdepth << endl;

        vector<int> all_fts(data.num_features());
        for (int j=0; j<(int)all_fts.size(); ++j)
            all_fts[j] = j;

        RandomForests rf;

        rf.guide(guide);
        rf.Train(insts, data_valid.instances(), all_fts, args); // build the random forest
        
        // Test on test dataset if available
        if (args.test_input != "") {
            const vector<const Instance*>& test_insts = data_test.instances();
            vector<double> preds = rf.Predict(test_insts);
            
            // Write predicts
            if (args.usestream) {
                int nte = preds.size();
                for (int i=0; i<nte; i++) {
                    cout << preds[i] << endl;
                }
            } else {
                FILE *pred_file;
                if ((pred_file = fopen (args.test_output.c_str(), "w")) == NULL) { 
                    perror(args.test_output.c_str()); 
                    exit(1); 
                }
                int npreds = preds.size();
                for (int i=0; i<npreds; i++) {
                    fprintf(pred_file, "%lf\n", preds[i]);
                }
                fclose(pred_file);
            }
        }

        if (guide)
            delete guide;

    } else if (args.mode == 'c') { // cross-validation
        if (args.numfolds != -1)
            cerr << misc::current << " Start " << args.numfolds << "-Folds Cross-Validation..." << endl;
        else
            cerr << misc::current << " Start Leave-One-Out-Cross-Validation..." << endl;
        cout << "Average rmse: " << CrossValid::Evaluate(data.instances(), args) << endl;
    } else if (args.mode == 'r') {
        cerr << misc::current << " Start Recursive Feature Elimination..." << endl;
        RecursiveFe::Evaluate(insts, data_valid.instances(), args);
    }
    

    cerr << misc::current << " End." << endl;

    return 0;
}
