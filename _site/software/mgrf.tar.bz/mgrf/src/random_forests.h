#ifndef RF_RANDOMFOREST_H
#define RF_RANDOMFOREST_H

#include <vector>
#include "instance.h"
#include "regression_tree.h"
#include "args.h"
#include "rf_guide.h"


class RandomForests {

public:
    RandomForests();
    ~RandomForests() {};

    void Train(const std::vector<const Instance*>& train_insts, 
               const std::vector<const Instance*>& valid_insts, 
               const std::vector<int>& ft_idxs, const ArgType& args);

    double                 Predict(const Instance& inst);
    std::vector<double>    Predict(const std::vector<const Instance*>& insts);
    double  Evaluate(const std::vector<const Instance*>& insts, const std::vector<double>& preds);

    void    guide(RfGuide* g) {guide_ = g;}
    double  train_err() const {return trainerror_;}
    double  oob_err() const {return ooberror_;}


    const std::vector<double>& vi() const { return vi_; }
    std::vector<double>& vi() { return vi_; }
    void vi(const std::vector<double>& v) { vi_ = v; } 

private:
    void DestoryTrees();
    void NormalizeVi();


private:
    std::vector<RegressionTree*> trees_;
    
    std::vector<double> feature_corr_;
    std::vector<double> fs_guide_;
    std::vector<int> feature_count_;

    std::vector<double> vi_; // error decreasing on each feature

    RfGuide * guide_;

    double ooberror_;
    double trainerror_;

    

};

#endif
