#include "random_tree.h"

using namespace std;

RandomTree::~RandomTree() {
    RemoveNodes();
}

// Get the prediction of one Instance 
double RandomTree::Predict(const Instance& inst) {
    int n = nodes_.size();
    int i = 0;
    double pred = MISSING;
    while (i>=0 && i<n) {
        TreeNode* node = nodes_[i];
        pred = node->pred;
        if (node->leaf) {
            return pred;
        }
        int f = node->feature;
        double v = node->value;
        if (inst.features[f] < v) 
            i = node->leftchild;
        else
            i = node->rightchild;
    }

    return pred;
}


// Predict the label of given instances. Output to predicts vector
void RandomTree::Predict(const std::vector<const Instance*>& insts, std::vector<double>* predicts) {
    int n = insts.size();
    for (int i=0; i<n; i++) {
        double pred = Predict(*insts[i]);
        predicts->push_back(pred);
    }
}


void RandomTree::RemoveNodes() {
    for (size_t i=0; i<nodes_.size(); ++i) {
        delete nodes_[i];
        nodes_[i] = NULL;
    }
    nodes_.clear();
}



//==================================================================================
// I/O functions


// Output one tree to a output stream
void RandomTree::PutTree(std::ostream& ost) const {
    int n = nodes_.size();
    string sep = " ";
    ost << n << endl;
    for (int i=0; i<n; i++) {
        ost << nodes_[i]->feature << sep;
        ost << nodes_[i]->value << sep;
        ost << nodes_[i]->pred << sep;
        ost << nodes_[i]->leftchild << sep;
        ost << nodes_[i]->rightchild << endl;
    }
}
ostream& operator<< (ostream& o, const RandomTree & tree) { tree.PutTree(o); return o; }


// Create a tree from an input stream (recover nodes info)
bool RandomTree::GetTree(istream& ist) {
    RemoveNodes();
    int n;
    ist >> n;
    for (int i=0; i<n; i++) {
        TreeNode * node = new TreeNode();
        nodes_.push_back(node);

        ist >> node->feature;
        ist >> node->value; 
        ist >> node->pred;
        ist >> node->leftchild;
        ist >> node->rightchild;
        
        if (node->leftchild == -1 && node->rightchild == -1)
            node->leaf = true;
    }
    return true;
}
int operator>> (istream& i, RandomTree& tree) {return tree.GetTree(i);}
