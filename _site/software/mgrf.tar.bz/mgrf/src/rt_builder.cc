// Random Tree Builder

#include <cmath> // sqrt 
#include <stack>

#include "misc.h"
#include "rt_builder.h"

using namespace std;

// an empty constructor
RandomTreeBuilder::RandomTreeBuilder(const vector<const Attribute*>& attrs, const Attribute& label_attr) :
    attrs_(attrs), label_attr_(label_attr), guide_(NULL) 
{
}


// build a regreesion tree using the original data
RandomTree * RandomTreeBuilder::Train(const vector<const Instance*>& insts, const vector<int>& attr_idxs, const ArgType& args) {
    args_ = args;

    RandomTree * rt = new RandomTree();
    vector<TreeNode*>& nodes = rt->nodes(); 
    
    vector<int> shuffled_ft_idxs(attr_idxs); // shuffled feature idxs
   
    //
    // Stack based implmentation of recursion
    //
    stack<int> st_nodes;
    stack< vector<const Instance*> > st_insts;

    nodes.push_back(new TreeNode());
    st_nodes.push(0);
    st_insts.push(insts);

    while (!st_nodes.empty() && !st_insts.empty()) {
        int nodeidx = st_nodes.top(); 
        st_nodes.pop();
        vector<const Instance*>& node_insts = st_insts.top();
        
        TreeNode* node = nodes[nodeidx];

        // Initialize node attributes
        node->feature = -1;
        node->value = MISSING;
        node->leaf = false;
        
        node->leftchild = -1;
        node->rightchild = -1;

        if (args.type == 'c') 
            node->pred = Instance::Mode(node_insts, label_attr_.num_classes); // majority vote for classification
        else
            node->pred = Instance::Average(node_insts); // average for regression

        // Check if it satisfy the termination criteria
        if (IsTerminal(node_insts)) {    
            node->leaf = true;
            st_insts.pop();
            //printf("Leaf at: %d\n", nodeidx);
            continue;
        }

        vector<int> selected_fids; // sampled feature ids
        if (guide_ && weighted_sampling_) {
            selected_fids = guide_->SampleFeatures();  // Guided smapling
        }
        else {
            random_shuffle(shuffled_ft_idxs.begin(), shuffled_ft_idxs.end()); // Uniform smapling
            selected_fids.assign(shuffled_ft_idxs.begin(), shuffled_ft_idxs.begin() + args_.mtry);
        }

        int fsplit;
        vector<const Instance*> leftinsts, rightinsts;
        // Decide the splitting crietia based on given data
        double imp_dcrs = SplitNode(node_insts, selected_fids, &leftinsts, &rightinsts, node); 

        printf("%f, %d, %f\n", imp_dcrs, node->feature, node->value);

        if (imp_dcrs > 0) {
            fsplit = node->feature;
            node->leaf = false;

            // Record feature contributions to impurity decreasing
            if (impurity_dcrs_ && node_insts.size() >= 3) {
                (*impurity_dcrs_)[fsplit] += imp_dcrs;
            }

            st_insts.pop();
            
            if (leftinsts.size() != 0) { // create Left node
                node->leftchild = nodes.size();
                st_insts.push(leftinsts);
                st_nodes.push(node->leftchild);
                TreeNode * child = new TreeNode();
                child->parent = node;
                nodes.push_back(child);
            }
            
            if (rightinsts.size() != 0) { // create Right node
                node->rightchild = nodes.size();
                st_insts.push(rightinsts);
                st_nodes.push(node->rightchild);
                TreeNode * child = new TreeNode();
                child->parent = node;
                nodes.push_back(child);
            }
        } else { // No further splitting is needed
            node->feature = -1;
            node->value = MISSING;
            node->leaf = true;
        }
    }

    return rt;
}


// Split at a node with given data samples
// Return the improvment of impurity
// If all selected features are the same then
// return RF_DBL_MAX
double RandomTreeBuilder::SplitNode(const vector<const Instance*>& insts, const vector<int>& ft_idxs, 
                                 vector<const Instance*>* left_insts, vector<const Instance*>* right_insts, 
                                 TreeNode* node)
{
    int n = insts.size();
    int mtry = args_.mtry;
    
    double min_imp = RF_DBL_MAX; // minimum impurity
    double vs = 0.0;
    double orig_impurity = 0.0; // original impurity before split
    set<int> left_cates;

    // Classification  ==================================== 
    if (args_.type == 'c') {
        vector<int> counts(label_attr_.num_classes, 0);
        // calculate count table beforehand
        for (int i=0; i<n; ++i) {
            counts[(int)insts[i]->label] += 1;
        }
        orig_impurity = GiniIndex(counts, n);
        //printf("Orignal impurity: %f", orig_impurity);

        // For each selected feature calculate impurity
        for (int j=0; j<mtry; ++j) {
            int f = ft_idxs[j];

            if (attrs_[f]->type == Attribute::CATEGORICAL) { // for categorical feature
                double impurity = FindSplit_GI_cate(insts, counts, f, &left_cates);
                if (impurity < min_imp) {
                    min_imp = impurity;
                    node->feature = f;
                    node->value = 0;
                    node->leftcates = left_cates;
                }
            } else { // for continuous feature
                double impurity = FindSplit_GI_cont(insts, counts, f, &vs);
                if (impurity < min_imp) {
                    min_imp = impurity;
                    node->feature = f;
                    node->value = vs;
                    node->leftcates.clear();
                }
            }
        }
    } else { // Regression  ==================================== 
        // r and ybr is the same for all features so it is calculated outside the features loop
        double r, ybr;
        r = ybr = 0.0;
        for (int i = 0; i < n; i++) {
            double lbl = insts[i]->label;
            r += lbl * lbl;
            ybr += lbl;
        }
        ybr /= n;
        orig_impurity = r - n*ybr*ybr;

        // For each selected feature calculate impurity
        for (int j=0; j<mtry; ++j) {
            int f = ft_idxs[j];
            
            if (attrs_[f]->type == Attribute::CATEGORICAL) { // for categorical feature
                double impurity = FindSplit_SL_cate(insts, r, ybr, f, &left_cates);
                if (impurity < min_imp) {
                    min_imp = impurity;
                    node->feature = f;
                    node->value = 0;
                    node->leftcates = left_cates;
                }
            } else { // for continuous feature
                double impurity = FindSplit_SL_cont(insts, r, ybr, f, &vs);
                if (impurity < min_imp) {
                    min_imp = impurity;
                    node->feature = f;
                    node->value = vs;
                    node->leftcates.clear();
                }
            }
        }
    }

    // Output left and right child instances
    int fsplit = node->feature;
    if (attrs_[fsplit]->type == Attribute::CATEGORICAL) { // for categorical feature
        for (int i=0; i<n; ++i) {
            int fval = (int)insts[i]->features[fsplit];
            if (node->leftcates.find(fval) != node->leftcates.end()) {
                left_insts->push_back(insts[i]);
            } else {
                right_insts->push_back(insts[i]);
            }
        }
    } else { // for continuous feature
        for (int i=0; i<n; ++i) {
            double fval = insts[i]->features[fsplit];
            if (fval <= node->value) {
                left_insts->push_back(insts[i]);
            } else {
                right_insts->push_back(insts[i]);
            }
        }
    }

    return orig_impurity - min_imp;
}


double RandomTreeBuilder::FindSplit_GI_cont(const vector<const Instance*>& insts, const vector<int>& counts, int f, double *vsplit) {
    int n = insts.size();
    vector<const Instance*> sorted_insts(n);
    vector<int> dataidxs(n);
    Instance::SortInstances(insts, &sorted_insts, &dataidxs, f); // For continous variables sort first

    double min_imp = RF_DBL_MAX; // minimum impurity

    *vsplit = sorted_insts[0]->features[f];

    double impurity = 0.0;
    int nL =0;
    int nR = n;
    vector<int> counts_l;
    vector<int> counts_r(counts);
    counts_l.assign(label_attr_.num_classes, 0);
    
    // for every i
    // put yi into left side, remove it from the right side, and calculate entropy of both sides
    for (int i = 0; i<n-1; i++) {
        int lbl = (int)sorted_insts[i]->label;
        ++(counts_l[lbl]);
        --(counts_r[lbl]);
        ++nL;
        --nR;

        // do not consider splitting here if the feature value is the same as next
        if ( sorted_insts[i]->features[f] ==  sorted_insts[i+1]->features[f])
            continue;

        impurity = (nL * GiniIndex(counts_l, nL) + nR * GiniIndex(counts_r, nR)) / n;

        if (impurity < min_imp) {
            min_imp = impurity;
            *vsplit = (sorted_insts[i]->features[f] +  sorted_insts[i+1]->features[f]) / 2; // split in the middle
        }
    }

    return min_imp;
}


double RandomTreeBuilder::FindSplit_GI_cate(const vector<const Instance*>& insts, const vector<int>& counts, int f, set<int>* left_cates) {
    int n = insts.size();
    vector<const Instance*> sorted_insts = Instance::SortInstancesByLabelCount(insts, f, attrs_[f]->num_classes);
    double min_imp = RF_DBL_MAX; // minimum impurity
    set<int> current_left_cates;

    double impurity = 0.0;
    int nL =0;
    int nR = n;
    vector<int> counts_l;
    vector<int> counts_r(counts);
    counts_l.assign(label_attr_.num_classes, 0);
    
    // for every i
    // put yi into left side, remove it from the right side, and calculate entropy of both sides
    for (int i = 0; i<n-1; i++) {
        int lbl = (int)sorted_insts[i]->label;
        ++(counts_l[lbl]);
        --(counts_r[lbl]);
        ++nL;
        --nR;

        // do not consider splitting here if the feature value is the same as next
        if ( sorted_insts[i]->features[f] ==  sorted_insts[i+1]->features[f])
            continue;

        current_left_cates.insert((int)sorted_insts[i]->features[f]);

        impurity = (nL * GiniIndex(counts_l, nL) + nR * GiniIndex(counts_r, nR)) / n;

        if (impurity < min_imp) {
            min_imp = impurity;
            (*left_cates) = current_left_cates;
        }
    }

    return min_imp;
}



// Find the best splitting point given a feature and data using Dynamic Programming
// Return Square Loss decrease (NOTE: not the root mean square loss)
double RandomTreeBuilder::FindSplit_SL_cont(const vector<const Instance*>& insts, double r, double ybr, int f, double* vsplit) 
{
    int n = insts.size();
    vector<const Instance*> sorted_data(n);
    vector<int> dataidxs(n);
    Instance::SortInstances(insts, &sorted_data, &dataidxs, f);

    // we have squared error = \sum_{i=1..n} (yi - ybar)^2
    // we want the squared error for left and right splits for all splits k
    // let ybl = ybar left, ybr = ybar right
    //     s = E_{i=0..k} yi^2
    //     r = E_{i=k+1..n} yi^2
    // NOTE: The initial value of r and ybr is calculated before hand because it is independent of feature  
    double ybl, s, L, R, SE;
    L = R = ybl = s = 0.0;

    double min_se = r - n*ybr*ybr; // minimum squared error achived
    *vsplit = sorted_data[0]->features[f];

    // for every i
    // put yi into left side, remove it from the right side, and calculate squared loss
    for (int i = 0; i<n-1; i++) {
        int j = i;

        double yi = sorted_data[i]->label; // next y
        s += yi * yi;
        r -= yi * yi;
        
        ybl = (j*ybl + yi) / (j+1);
        ybr = ((n-j)*ybr - yi) / (n-j-1);

        // do not consider splitting here if data is the same as next
        if ( sorted_data[i]->features[f] ==  sorted_data[i+1]->features[f])
            continue;
        
        L = s - (j+1)*ybl*ybl;
        R = r - (n-j-1)*ybr*ybr;
        
        SE = L + R; // total square error

        if (SE < min_se) {
            min_se = SE;
            *vsplit = (sorted_data[i]->features[f] +  sorted_data[i+1]->features[f]) / 2; // split in the middle
        }
    }

    return min_se;
}


// Find the best splitting point given a feature and data using Dynamic Programming
// Return Square Loss decrease (NOTE: not the root mean square loss)
double RandomTreeBuilder::FindSplit_SL_cate(const vector<const Instance*>& insts, double r, double ybr, int f, set<int>* left_cates) {
    int n = insts.size();
    vector<const Instance*> sorted_data = Instance::SortInstancesByLabelMean(insts, f, attrs_[f]->num_classes);
    vector<int> dataidxs(n);
    set<int> current_left_cates;

    // we have squared error = \sum_{i=1..n} (yi - ybar)^2
    // we want the squared error for left and right splits for all splits k
    // let ybl = \bar{y}_left, ybr = \bar{y}_right
    //     s = E_{i=0..k} yi^2
    //     r = E_{i=k+1..n} yi^2
    // NOTE: The initial value of r and ybr is calculated before hand because it is independent of feature  
    double ybl, s, L, R, SE;
    L = R = ybl = s = 0.0;

    double min_se = r - n*ybr*ybr; // minimum squared error achived
    left_cates->clear();  

    // for every i
    // put yi into left side, remove it from the right side, and calculate squared loss
    for (int i = 0; i<n-1; i++) {
        int j = i;

        double yi = sorted_data[i]->label; // next y
        s += yi * yi;
        r -= yi * yi;
        
        ybl = (j*ybl + yi) / (j+1);
        ybr = ((n-j)*ybr - yi) / (n-j-1);

        // do not consider splitting here if data is the same as next
        if ( sorted_data[i]->features[f] ==  sorted_data[i+1]->features[f])
            continue;
        
        L = s - (j+1)*ybl*ybl;
        R = r - (n-j-1)*ybr*ybr;
        
        SE = L + R; // total square error

        current_left_cates.insert((int)sorted_data[i]->features[f]);

        if (SE < min_se) {
            min_se = SE;
            (*left_cates) = current_left_cates;
        }
    }

    return min_se;
}



double RandomTreeBuilder::Entropy(const std::vector<int>& counts, int n) {
    double sum = 0.0;
    for (size_t k=0; k<counts.size(); ++k) {
        sum += counts[k] * log2((double)counts[k]);
    }
    return log2((double)n) - sum/n;
}


double RandomTreeBuilder::GiniIndex(const std::vector<int>& counts, int n) {
    int sum = 0;
    for (size_t k=0; k<counts.size(); ++k) {
        sum += counts[k] * (n-counts[k]);
    }
    return (double)sum/(n*n);
}


// Check if the termination condition is satisfied
bool RandomTreeBuilder::IsTerminal(const vector<const Instance*>& insts) {
    int n = insts.size(); 
    if (n <= args_.nodesize)
        return true;
    else
        return Instance::HasSameLabel(insts); // If all samples have the same label then it's a leaf
}


