#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <algorithm>
#include "sparse_matrix.h" 

using namespace std;

void SparseMatrix::ReadSparse(const char* filename) {
    CooTuple tuple;
    vector<CooTuple> coo_tuples; 
    
    FILE *file;
    if ((file = fopen(filename, "r")) == NULL) { 
        perror(filename); 
        exit(-1); 
    }
    fscanf(file, "%d %d", &n_, &m_);
    while (fscanf(file, "%d %d %lf", &tuple.i, &tuple.j, &tuple.val)!=EOF) {
        coo_tuples.push_back(tuple);
    }
    fclose(file);

    sort(coo_tuples.begin(), coo_tuples.end(), coo_ordering());

    /*for (size_t t=0; t<coo_tuples.size(); ++t)
        printf("%d %d %lf\n", coo_tuples[t].i, coo_tuples[t].j, coo_tuples[t].val);*/

    // From COO to CSR format
    nnz_ = coo_tuples.size();
    vals_.assign(nnz_, 0.0);
    row_ptr_.assign(n_+1, 0);
    col_ind_.assign(nnz_, 0);

    int ridx, old_ridx; // row index
    old_ridx = -1;
    for (int i=0; i<nnz_; ++i) {
        ridx = coo_tuples[i].i;
        if (ridx!=old_ridx) {
            for (int j=old_ridx+1; j<=ridx; ++j)
                row_ptr_[j] = i;
        }
        old_ridx = ridx;
        vals_[i] = coo_tuples[i].val;
        col_ind_[i] = coo_tuples[i].j;
    }

    for (int j=old_ridx+1; j<=n_; ++j)
        row_ptr_[j] = nnz_;
}



// Multiply matrix with a column vector
vector<double> SparseMatrix::Multiply(const vector<double>& col_vec) {
    vector<double> rslt(n_);
    for (int i=0; i<n_; ++i) {
        double row_sum = 0.0;
        for (int j=row_ptr_[i]; j < row_ptr_[i+1]; ++j) {
            row_sum += vals_[j]*col_vec[col_ind_[j]];
        }
        rslt[i] = row_sum;
    }

    return rslt;
}


void SparseMatrix::Test() {
    ReadSparse("test.net");

    printf("%d %d\n", n_, m_);

    for (int i=0; i<nnz_; ++i) {
        printf("%lf,", vals_[i]); 
    }
    printf("\n");

    for (int i=0; i<nnz_; ++i) {
        printf("%d,", col_ind_[i]); 
    }
    printf("\n");

    for (int i=0; i<n_+1; ++i) {
        printf("%d,", row_ptr_[i]); 
    }
    printf("\n");


    vector<double> vec;
    vec.push_back(4.0);
    vec.push_back(1.0);
    vec.push_back(2.0);
    vec.push_back(16.0);

    vector<double> r = Multiply(vec);
    for (size_t i=0; i<r.size(); ++i) {
        printf("%f\n", r[i]);
    }
}
