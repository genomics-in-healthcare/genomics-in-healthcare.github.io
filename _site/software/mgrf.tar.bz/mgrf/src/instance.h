#ifndef RF_INSTANCE_H
#define RF_INSTANCE_H

#include <string>
#include <vector>

#define RF_DBL_MAX 99999999999999.999999
#define RF_DBL_MIN (-RF_DBL_MAX)
#define MISSING RF_DBL_MIN
#define MAX_LINE 2097152

class Instance {
public:
    double* features; // feature data
    double label; // class label or regression target
    double weight; // Instance weight
    int num_features; // number of features  

    Instance();
    ~Instance();

    static void SortInstances(const std::vector<const Instance *>& data, std::vector<const Instance *>* sorted_data, std::vector<int>* index, int f);
    static void RemoveFeatures(const std::vector<const Instance *>& data, const std::vector<int> &ft_idxs, std::vector<const Instance *>* filterred_data);
};

class Attribute {
public:
    typedef enum enum_AttributeType {
        NUMERIC = 0,
        CATEGORICAL 
    } AttributeType;

    AttributeType type;
    int num_classes;

    static void ReadAttributes(const char* filename, std::vector<const Attribute*>* attrs);
};


class Dataset {
private:
    std::vector<Instance*> instances_;
    int num_features_; 

public:
    Dataset() : num_features_(0) {};
    ~Dataset() {};

    int num_features() const { return num_features_; }
    int num_instances() const { return instances_.size(); }

    void SetLabel(int i, double label) { instances_[i]->label = label; }

    const std::vector<const Instance*> instances() const;
    const Instance* instance(int i) const { return instances_[i]; }
    
    void ReadCsv(const char * filename, char sep);  // populate data vector with instances from csv/tsv file
    void ReadSvmFile(const char * filename);  // populate data vector with instances from svm-like file

    void ReadFile(const char * filename); // A wrapper function for data input

};

#endif
