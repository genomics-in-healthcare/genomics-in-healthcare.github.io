#ifndef MGRF_ATTRIBUTE_H
#define MGRF_ATTRIBUTE_H

#include <string>
#include <vector>

class Attribute {
public:
    Attribute() : type(CATEGORICAL), num_classes(0) {}

    typedef enum enum_AttributeType {
        NUMERIC = 0,
        CATEGORICAL 
    } AttributeType;

    
    AttributeType type;
    std::string name;
    int num_classes;

    static void ReadAttributes(const char* filename, std::vector<const Attribute*>* attrs);
};

#endif
