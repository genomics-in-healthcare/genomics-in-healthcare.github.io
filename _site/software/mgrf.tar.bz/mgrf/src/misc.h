#ifndef RF_MISC_H
#define RF_MISC_H

#include <cstdio>
#include <string>
#include <vector>
#include <ctype.h>
#include <algorithm>


struct less_ordering { // functor for index sorting
    bool operator ()(std::pair<int, double> const& a, std::pair<int, double> const& b) {
        return a.second < b.second;
    }
};

struct greater_ordering { // functor for index sorting
    bool operator ()(std::pair<int, double> const& a, std::pair<int, double> const& b) {
        return a.second > b.second;
    }
};

class misc {
private:
    
public:
    static bool cmp_string(const char* str1, const char* str2);
    static void sort_by_index(const double* data, int* index, int n);
    static void sort_by_index_descend(const double* data, int* index, int n);

    static std::ostream& current(std::ostream& out);

    static void write_vector(const std::vector<double>& data, const char *filename);

    template <typename T>
    static void write_sparse(const std::vector<T>& data, int n, int m, const char *filename) {
        FILE *file;
        if ((file = fopen(filename, "w")) == NULL) { 
            perror(filename); 
            exit(-1); 
        }
    
        for (int i=0; i<n; i++) {
            for (int j=0; j<m; j++) {
                double val = (double)data[i*m+j];
                if (val>0) {
                    fprintf(file, "%d %d %lf\n", i+1, j+1, val);     
                }
            }
        }

        if (data[n*m -1] <= 0) {
            fprintf(file, "%d %d %lf\n", n, m, 0.0);
        }

        fclose(file);
    }

    template <typename T>
    static void read_sparse(std::vector<T>* data, int n, int m, const char *filename) {
        FILE *file;
        if ((file = fopen(filename, "r")) == NULL) { 
            perror(filename); 
            exit(-1); 
        }
        (*data).assign(n*m, 0);
        int i,j;
        T val;
        while (fscanf(file, "%d %d %lf", &i, &j, &val)!=EOF) {
            (*data)[(i-1)*m + j-1] = val;
        }
        fclose(file);
    }
};




#endif

