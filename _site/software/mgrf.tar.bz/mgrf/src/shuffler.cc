// NOTE: This class has no boundary check please use with caution

#include <cstdlib>
#include "shuffler.h"

Shuffler::Shuffler() : vec_(0), size_(0) {
}

// Construct a Shuffler which can shuffle number from 0 to size-1
Shuffler::Shuffler(int size) : vec_(0), size_(0) {
    set_size(size);
}

Shuffler::~Shuffler() {
    if (vec_) 
        delete[] vec_;
    vec_ = NULL;
}

void Shuffler::set_size(int size){
    if (vec_) 
        delete[] vec_;
    size_ = size;
    vec_ = new int[size_];
    for (int i=0; i<size_; i++) 
        vec_[i] = i;

    Shuffle(size_);
}

// Output a pointer to an array where the first n elements is shuffled 
int* Shuffler::Shuffle(int k) {
    for (int i=0; i<k; i++) {
        int c = rand() / (RAND_MAX / size_ + 1);
        int t = vec_[i];
        vec_[i] = vec_[c];
        vec_[c] = t;
    }
    return vec_;
}
