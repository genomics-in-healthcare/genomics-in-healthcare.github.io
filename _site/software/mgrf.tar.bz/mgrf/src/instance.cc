#include <cstdio>
#include <cstdlib> //atof
#include <cstring>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

#include "misc.h"
#include "instance.h"

using namespace std;

Instance::Instance() : features(NULL), label(MISSING), weight(0.0), num_features(0) {
}

Instance::~Instance() {
    if (features) {
        delete[] features;
        features = NULL;
    }
}

void Instance::SortInstances(const vector<const Instance*>& data, vector<const Instance*>* sorted_data, vector<int>* index, int f) {
    int n = (int)data.size();
    vector< pair<int, double> > order(n);
    for (int i=0; i<n; i++)
        order[i] = make_pair(i, data[i]->features[f]);
    sort(order.begin(), order.end(), less_ordering());
    for (int i=0; i<n; i++) {
        (*index)[i] = order[i].first;
        (*sorted_data)[i] = data[order[i].first];
    }
}

void Instance::RemoveFeatures(const vector<const Instance *>& data, const vector<int> &ft_idxs, vector<const Instance *>* filterred_data) {
    int n = (int)data.size();
    int new_m = (int)ft_idxs.size(); 

    filterred_data->clear();
    filterred_data->reserve(n);

    for (int i=0; i<n; ++i) {
        const Instance * inst = data[i];
        Instance * new_inst = new Instance();
        new_inst->label = inst->label;
        new_inst->features = new double[new_m];
        new_inst->num_features = new_m;
        new_inst->weight = inst->weight;
        for (int j=0; j<new_m; ++j)
            new_inst->features[j] = inst->features[ft_idxs[j]];

        filterred_data->push_back(new_inst);
    }

}

void Attribute::ReadAttributes(const char* filename, std::vector<const Attribute*>* attrs) {
    // open file
    FILE *file;
    if ((file = fopen (filename, "r")) == NULL) { 
        perror(filename); 
        exit(-1); 
    }
    char name[2048];
    int type, num_classes;

    attrs->clear();

    char * line = new char[MAX_LINE];
    while (fgets(line, MAX_LINE, file) != NULL) { // for each line
        size_t len = strlen(line);
        if (len!=0 && line[len-1] == '\n') {
            line[len-1] = '\0';
        } else if (len == MAX_LINE - 1) {
            printf("Line length exceeds the MAX_LINE!\n");
            exit(1);
        }

        if (line[0] == '#') continue;
        if (sscanf(line,"%s\t%d\t%d", name, &type, &num_classes) == EOF) continue;
        Attribute* attr = new Attribute();
        if (type==0)
            attr->type = Attribute::NUMERIC;
        else
            attr->type = Attribute::CATEGORICAL;
        attr->num_classes = num_classes;
        attrs->push_back(attr);
    }
}


// get a const copy of instances vector
const vector<const Instance*> Dataset::instances() const {
    int n = instances_.size();
    vector<const Instance*> insts;
    for (int i=0; i<n; i++)
        insts.push_back(instances_[i]);
    return insts;
}


void Dataset::ReadFile(const char* filename) {
    // read data based on file extension
    const char* ext = strrchr(filename,'.');
    if (ext!=NULL) {
        if (misc::cmp_string(ext, ".csv")) {
            ReadCsv(filename, ',');
        } else if (misc::cmp_string(ext, ".tsv")) {
            ReadCsv(filename, '\t');
        } else {
            ReadSvmFile(filename);
        }
    } else {
        ReadSvmFile(filename);
    }
}


// Read instances from CSV file
// Comma/Tab-delimited file, each row is a feature, each coumn is a sample
// The first row is the label and the first column is the feature name
void Dataset::ReadCsv(const char * filename, char sep) {    
    // open file
    ifstream infile(filename);
    if (infile.fail()) {
        perror(filename); 
        exit(-1);
    }

    vector<string> feat_names;
    vector<double*> feat_data;
    vector<double> labels;
    string line;
    string cell;
    char * endptr;
    double value;
    
    // the first line is the label line
    getline(infile, line);
    stringstream ls_label(line);
    getline(ls_label, cell, sep); // ignore the first cell
    while (getline(ls_label, cell, sep)) {
        value = strtod(cell.c_str(), &endptr); 
        if (*endptr == '\0' || *endptr == '\r' || *endptr == '\n') {
            labels.push_back(value);
        }
        else {
            labels.push_back(MISSING);
            
        }
    }
    
    int num_samples = labels.size();
    
    // read following data rows
    while (!infile.eof()) {
        getline(infile, line);
        if (line == "")
            continue;
        
        stringstream lineStream(line);
        // get feature name
        getline(lineStream, cell, sep);
        feat_names.push_back(cell);
        double * rowData = new double[num_samples];
        int j=0;
        while(getline(lineStream, cell, sep)) {
            value = strtod(cell.c_str(), &endptr); 
            if (*endptr == '\0' || *endptr == '\r' || *endptr == '\n') 
                rowData[j++] = value;
            else
                rowData[j++] = MISSING;
        }
        feat_data.push_back(rowData);
    }
    
    num_features_ = feat_data.size();
    
    // transform FeatureData into instances vector 
    for (int i=0; i<num_samples; i++) {
        Instance * inst = new Instance();
        inst->features = new double[num_features_];
        inst->label = labels[i];
        inst->weight = 1.0;
        inst->num_features = num_features_;
        for (int j=0; j<num_features_; j++)
            inst->features[j] = feat_data[j][i];    
        instances_.push_back(inst);
    }

    // free memory for feature data
    for (int j=0; j<num_features_; j++) {
         delete[] feat_data[j];
         feat_data[j] = NULL;
    }
}


void Dataset::ReadSvmFile(const char * filename) {
    FILE *file;
    if ((file = fopen (filename, "r")) == NULL) { 
        perror(filename); 
        exit(-1); 
    }

    int wnum, qid, nrow, numread, pos;
    char token[2048], junk[2048];
    double value, target;
    vector<double> words;
    vector<int> fidxs;
    
    pos = num_features_ = 0;
    nrow = 0;
    target = MISSING;

    char * line = new char[MAX_LINE];
    while (fgets(line, MAX_LINE, file) != NULL) { // for each line
        nrow++;
        size_t len = strlen(line);
        if (len!=0 && line[len-1] == '\n') {
            line[len-1] = '\0';
        } else if (len == MAX_LINE - 1) {
            printf("Line length exceeds the MAX_LINE!\n");
            exit(1);
        }

        if (line[0] == '#') continue;
        if (sscanf(line,"%s",token) == EOF) continue;
        pos=0;
        while((token[pos] != ':') && token[pos]) pos++;
        if (token[pos] == ':') {
            perror ("Line must start with label or 0!!!\n"); 
            printf("LINE: %s\n",line);
            exit (1); 
        }
        // read the target value
        if (sscanf(line,"%lf", &target) == EOF) 
            continue;
        pos=0;
        while (isspace((int)line[pos])) pos++; //skip space
        while((!isspace((int)line[pos])) && line[pos]) pos++; //skip target
        
        // for each token
        while(((numread=sscanf(line+pos,"%s",token)) != EOF) &&
                numread > 0) {
            while(isspace((int)line[pos])) pos++;
            while((!isspace((int)line[pos])) && line[pos]) pos++;

            if (token[0] == '#') break;
            if (sscanf(token,"qid:%d%s",&wnum,junk)==1) { // qid
                qid = (int)wnum;
            } else if (sscanf(token,"%d:%lf%s",&wnum,&value,junk)==2) { // regular feature pair
                fidxs.push_back(wnum);
                words.push_back(value);
                //printf("Feature read:%d:%lf\n", wnum,value);
                if (wnum<=0) { 
                    perror("Feature number must be larger or equal to 1!!!\n"); 
                    printf("LINE: %d\n",nrow);
                    exit(1); 
                }
            } else {
                perror("Cannot parse feature/value pair!!!\n"); 
                printf("'%s' in LINE: %d\n",token, nrow);
                exit(1);         
            }
        }

         if (num_features_ < fidxs[fidxs.size()-1])
            num_features_ = fidxs[fidxs.size()-1];

        Instance * inst = new Instance();
        inst->features = new double[num_features_];
        inst->num_features = num_features_;
        fill(inst->features, inst->features+num_features_, MISSING);
        inst->label = target;
        inst->weight = 1.0;
        for (size_t f=0; f<fidxs.size(); f++)
            inst->features[fidxs[f]-1] = words[f];    
        instances_.push_back(inst);
        
        fidxs.clear();
        words.clear();
    }

    delete[] line;

    // Spanning each Instance to the the num_features
    int nsamples = instances_.size();
    for (int i=0; i<nsamples; i++) {
        Instance* inst = instances_[i];
        if (inst->num_features < num_features_) {
            double* fts = new double[num_features_];
            copy(inst->features, inst->features + inst->num_features, fts);
            fill(fts + inst->num_features, fts + num_features_, MISSING);
            delete[] inst->features;
            inst->features = fts;
        }
    }
}


