#ifndef MGRF_RANDOM_TREE_H
#define MGRF_RANDOM_TREE_H

#include <vector>
#include <iostream>
#include "tree_node.h"
#include "instance.h"

//Classification or Regression Tree Wrapper
class RandomTree {
public:
    ~RandomTree();

    std::vector<TreeNode*>& nodes() {return nodes_;}
    const std::vector<TreeNode*>& nodes() const {return nodes_;}

    double    Predict(const Instance& inst);
    void      Predict(const std::vector<const Instance*>& insts, std::vector<double>* predicts);

    // I/O
    friend std::ostream& operator<< (std::ostream& o, const RandomTree& tree); // output tree structure to stream 
    friend int operator>> (std::istream& i, RandomTree& tree); // read tree from stream

protected:
    void PutTree(std::ostream& ost) const; // write tree nodes to an output stream
    bool GetTree(std::istream& ist); // read tree nodes from stream

private:
    void     RemoveNodes(); // Release allocated space for nodes

    std::vector<TreeNode*> nodes_;

};

#endif
