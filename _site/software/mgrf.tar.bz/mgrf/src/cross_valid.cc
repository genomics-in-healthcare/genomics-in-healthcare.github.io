#include "random_forests.h"
#include "cross_valid.h"

using namespace std;

// get the rmse for cross-validation
double CrossValid::Evaluate(const std::vector<const Instance*>& data, const ArgType& args) {
    int n = data.size();
    int m = data[0]->num_features;
    int numfolds = args.numfolds;
    if (numfolds == -1) // leave-one-out-cross-validation
        numfolds = n;
    
    double foldbin = n / (double)numfolds;
    
    vector<const Instance*> train_insts;
    vector<const Instance*> test_insts;

    vector<int> ft_idxs(m);
    for (int j=0; j<m; ++j)
        ft_idxs[j] = j;

    double rmse = 0.0;
    for (int t=0; t<numfolds; t++) {
        test_insts.clear();
        train_insts.clear();
        int start = (int)(t*foldbin);
        int end = (int)((t+1)*foldbin);
        for (int i=0; i<n; i++) {
            if (i >= start && i < end) {
                test_insts.push_back(data[i]);
            } else {
                train_insts.push_back(data[i]);
            }
        }

        RandomForests rf;
        rf.Train(train_insts, vector<const Instance*>(), ft_idxs, args);

        vector<double> preds = rf.Predict(test_insts);
        double tmp = rf.Evaluate(test_insts, preds);
        rmse += tmp;
        cout << "Fold " << t << " rmse: " << tmp << endl; 
    }

    return rmse/numfolds;
}
