#include "args.h"
#include <iostream>

namespace po = boost::program_options;
using namespace po;
using namespace std;

string version = "0.0.1";

void print_usage() {
    printf("Usage:\n");
    printf(" rf [-m l] [options] <training data> [model output] or\n");
    printf(" rf -m t [options] <test data> [prediction output]\n");

    printf("\n\nGeneral options:\n");
    printf("-h, --help                     print help message\n");
    printf("--version                      print version message\n");
    printf("-p, --num-threads <int>        number of threads [default: 1]\n"); 
    printf("-u, --use-stream               read training label from stdin\n");
    printf("                               write all prediction to stdout\n");
    printf("-g, --guide <filename>         guide the training with module information\n");

    printf("\nModes:\n");
    printf("-m, --mode <l|t|c|d|r>           [default: l]\n");
    printf("                               - l: learn mode, output model\n");
    printf("                               - t: test mode, given data output prediction\n");
    printf("                               - c: cross-validation mode,\n");
    printf("                               - d: diagnose mode, trace training process,\n");
    printf("                                    e.g. print training error, out-of-bag error\n");
    printf("                               - r: recursive feature elimination (RFE) mode.\n");


    printf("\nLearning/Diagnose mode options:\n");
    printf("-t, --ntrees <int>             number of trees [default: 100]\n");
    printf("-k, --mtrys <int>              number of random features to choose at each node\n");
    printf("                               [default: sqrt(num_features)]\n");
    printf("-s, --nodesize <int>           stop spliting a node, if it contains s or less\n"); 
    printf("                               samples [default: 1]\n"); 
    printf("-d, --max-depth <int>          the maximum depth a tree can grow. [default: -1]\n");

    printf("\nDiagnose mode options: (implicitly turn on the diagnose mode)\n");
    printf("-V, --valid-input <filename>   provide a validation dataset. This will turn on\n");
    printf("                               the diagnose mode. Omitted in mode -m t.\n");
    printf("-T, --test-input <filename>    provide a test dataset. Output prediction to the\n");
    printf("                               file speficied by -P. Omitted in mode -m t.\n");
    printf("-P, --test_output <filename>   output the test prediction to <filename>\n");
    printf("                               [default: 'rf.pred']\n");

    printf("\nDiagnose mode options: \n");
    printf("-f, --num-folds [int]          specify number of cross validation folds.\n");
    printf("                               [default: -1 indicates LOOCV]. Values other than\n");
    printf("                               0 will turn off some diagnose message.\n");

    printf("\nAdvance options: \n");
    printf("-b, --bootstrap <0|1>          [default: 0]\n");
    printf("                               - 0: subbagging, 73%% samples without replacement.\n");
    printf("                               - 1: bagging, sample with replacement\n");
    printf("-w, --weight-output <filename> output attribute weights to file. \n");
    printf("                               [default: weights.tsv]\n");
}


int parse_parameter(int argc, char* argv[], ArgType* args) {
    // set default parameters
    args->mode = 'l';
    args->type = 'r';
    args->usestream = false;
    args->input_file = "";
    args->output_file = "";
    args->valid_input = "";
    args->test_input = "";
    args->test_output = "out.pred";
    args->numthreads = 1;
    args->ntrees = 100;
    args->mtry = -1;
    args->nodesize = 1;
    args->maxdepth = -1;
    args->numfolds = -1;
    args->bootstrap = 0;
    args->guide = "";
    args->weight_output = "weights.tsv";

    options_description general("Usage: \n rf [options] <training data> <model output>\n\nOptions");
    general.add_options()
        ("help,h", "help")
        ("version", "version")
        ("num-threads,p", value<int>(), "num-threads")
        ("use-stream,u", "use-stream")
        ("mode,m", value<char>(), "mode")
        ("type,C", value<char>(), "type")
        ("ntrees,t", value<int>(), "ntrees")
        ("mtry,k", value<int>(), "mtry")
        ("nodesize,s", value<int>(), "nodesize")
        ("max-depth,d", value<int>(), "max-depth")
        ("num-folds,f", value<int>(), "num-folds")
        ("valid-input,V", value<string>(), "valid-input")    
        ("test-input,T", value<string>(), "test-input")
        ("test-output,P", value<string>(), "test-output")
        ("guide,g", value<string>(), "guide")
        ("bootstrap,b", value<int>(), "bootstrap")
        ("weight-output,w", value<string>(), "weight-output")
    ;

    options_description hidden("Options");  
    hidden.add_options()
        ("input-file", value<string>(), "" )
        ("output-file", value<string>(), "" )
    ;

    // Declare an options description instance which will include
    // all the options
    options_description all("Options");
    all.add(general).add(hidden);

    // Declare an options description instance which will be shown
    // to the user
    options_description visible("");
    visible.add(general);
    
    positional_options_description pd; 
    pd.add("input-file", 1);
    pd.add("output-file", 2);

    variables_map vm;
    try { 
        store(command_line_parser(argc, argv).options(all).positional(pd).run(), vm);
    } catch (exception& e) {
        cerr << "ERROR: Unable to parse program options: " << e.what() << endl;
        cerr << endl;
        print_usage();
        return -1;
    }
    
    notify(vm);

    if (vm.empty() || vm.count("help")) {
        print_usage();
        return -1;
    }

    if (vm.count("version")) {
        cout << "rf version: " << version << endl;
        return -1;
    }

    if (vm.count("mode")) {
        args->mode = vm["mode"].as<char>();
        if (args->mode != 'l' && args->mode != 't' && args->mode != 'd' && args->mode != 'c' && args->mode != 'r') {
            cerr << "ERROR: invalid mode. Please choose among: l: learn, t: test, d: diagnose, c: cross-validation, r: recursive feature elimination;" << endl;
            return -1;
        }
    }
    
    if (vm.count("input-file")) {
       args->input_file = vm["input-file"].as<string>();
    } else {
       cerr << "ERROR: Please specify an input dataset." << endl;
       return -1;
    }

    if (vm.count("output-file")) {
       args->output_file = vm["output-file"].as<string>();
    } else if (args->mode=='t') {
       cerr << "ERROR: Please specify an input dataset." << endl;
       return -1;
    }

    if (vm.count("guide")) {
        args->guide = vm["guide"].as<string>();
    }

    if (vm.count("weight-output")) {
        args->weight_output = vm["weight-output"].as<string>();
    }

    if (vm.count("bootstrap")) { 
        args->bootstrap = vm["bootstrap"].as<int>();
    }


    if (vm.count("type")) {
        args->type = vm["type"].as<char>();
        if (args->type != 'c' && args->type != 'r') {
            cerr << "ERROR: invalid type. Please choose among: c: classifier, r: regression." << endl;
            return -1;
        }
    }

    if (vm.count("num-threads")) {
        args->numthreads = vm["num-threads"].as<int>();
        if (args->ntrees <= 0) {
            cerr << "ERROR: The number of threads must be a positive integer." << endl;
            return -1;    
        }
    }

    if (vm.count("ntrees")) {
        args->ntrees = vm["ntrees"].as<int>();
        if (args->ntrees <= 0) {
            cerr << "ERROR: The number of trees must be a positive integer." << endl;
            return -1;    
        }
    }

    if (vm.count("mtry")) {
        args->mtry = vm["mtry"].as<int>();
        if (args->mtry <= 0) {
            cerr << "ERROR: The number of features been selected must be a positive integer." << endl;
            return -1;    
        }
    }

    if (vm.count("nodesize")) {
        args->nodesize = vm["nodesize"].as<int>();
        if (args->nodesize <= 0) {
            cerr << "ERROR: The size of node must be a positive integer." << endl;
            return -1;    
        }
    }

    if (vm.count("max-depth")) {
        args->maxdepth = vm["max-depth"].as<int>();
        if (args->nodesize <= 0) {
            cerr << "ERROR: The maximum depth of tree must be a positive integer." << endl;
            return -1;    
        }
    }

    if (args->mode == 'l') {
        args->usestream = (vm.count("use-stream") > 0);
    }

    if (args->mode == 'c') { // cross-validation mode 
        if (vm.count("num-folds")) {
            args->numfolds = vm["num-folds"].as<int>();
        }
    } else if (args->mode=='d') { // diagnose mode we might want to check valid and test data
        
    }

    if (vm.count("valid-input")) {
        args->valid_input = vm["valid-input"].as<string>();
    }
    if (vm.count("test-input")) {
        args->test_input = vm["test-input"].as<string>();
    }
    if (vm.count("test-output")) {
        args->test_output = vm["test-output"].as<string>();
    }

    return 0;
}
