#ifndef RF_BACKWARDFE_H
#define RF_BACKWARDFE_H

#include <vector>
#include "instance.h"
#include "args.h"

class RecursiveFe {

public:
    static double Evaluate(const std::vector<const Instance*>& insts, const std::vector<const Instance*>& valid_insts, const ArgType& args);
    static void RowSum(const std::vector<double>& data, int m, std::vector<double>* rowsum);
    static std::vector<int> SortVi(const std::vector<double>& data);

    static void WriteFeatures(const char * filename, const std::vector<int>& ft_idxs, const std::vector<double>& vi);
};


#endif

