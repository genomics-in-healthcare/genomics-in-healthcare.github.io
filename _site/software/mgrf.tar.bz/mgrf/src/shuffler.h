// shuffler.h

// NOTE: This class has no boundary check please use with extra caution!


#ifndef RF_SHUFFLER_H
#define RF_SHUFFLER_H

class Shuffler {
    int* vec_;
    int size_;

public:
    Shuffler();
    Shuffler(int size);
    ~Shuffler();

    void set_size(int size);
    int* Shuffle(int k);
};

#endif
