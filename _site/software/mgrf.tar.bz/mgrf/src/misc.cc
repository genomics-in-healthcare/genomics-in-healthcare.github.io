#include <cstring>
#include <ctime>
#include <vector>
#include <iostream>
#include <iomanip>
#include "misc.h"

using namespace std;

// Case-insensitive string comparison
bool misc::cmp_string(const char* str1, const char* str2) {
    int n1 = strlen(str1);
    int n2 = strlen(str2);
    if (n1!=n2)
        return false;
    for (int i=0; i<n1; i++) {
        if (tolower(str1[i]) != tolower(str2[i]))
            return false;
    }
    return true;
}


// sort data and return the sorted index
void misc::sort_by_index(const double* data, int* index, int n) {
    vector< pair<int, double> > order(n);
    for (int i=0; i<n; i++)
        order[i] = make_pair(i, data[i]);
    sort(order.begin(), order.end(), less_ordering());
    for (int i=0; i<n; i++)
        index[i] = order[i].first;
}

// sort data and return the sorted index
void misc::sort_by_index_descend(const double* data, int* index, int n) {
    vector< pair<int, double> > order(n);
    for (int i=0; i<n; i++)
        order[i] = make_pair(i, data[i]);
    sort(order.begin(), order.end(), greater_ordering());
    for (int i=0; i<n; i++)
        index[i] = order[i].first;
}


std::ostream& misc::current(std::ostream& out) {
    time_t now;
    time(&now);
    struct tm* cur;
    cur = localtime(&now);

    out << "[" << std::setw(2) << std::setfill('0');
    out << cur->tm_hour << ":" << std::setw(2) << std::setfill('0');
    out << cur->tm_min << ":" << std::setw(2) << std::setfill('0');
    out << cur->tm_sec << "]";
    return out;
}


void misc::write_vector(const vector<double>& data, const char *filename) {
    FILE *file;
    if ((file = fopen(filename, "w")) == NULL) { 
        perror(filename); 
        exit(-1); 
    }
    
    for (size_t i = 0; i<data.size(); ++i) {
        fprintf(file, "%lf\n", data[i]);
    }

    fclose(file);
}



