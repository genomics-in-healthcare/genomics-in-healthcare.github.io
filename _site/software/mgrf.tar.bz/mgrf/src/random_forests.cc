#include <math.h> // sqrt
#include <algorithm>  // random_shuffle
#include "misc.h"
#include "random_forests.h"


using namespace std;

RandomForests::RandomForests() {
    guide_ = NULL;
}

void RandomForests::Train(const vector<const Instance*>& insts, const vector<const Instance*>& valid_insts, const vector<int>& fids, const ArgType& args) {
    int n = insts.size();
    int m = insts[0]->num_features; // number of all features

    int ntrees = args.ntrees;

    std::vector<int> random_deck(n);  // used to generate random sampling without replacment
    for (int j=0; j<n; ++j) 
        random_deck[j] = j;

    ArgType newargs = args;

    vi_.assign(m, 0.0);
    feature_count_.assign(m, 0);
    
    vector<int> samplecount(n, 0);

    // Training trace
    vector<double> trainpreds;     // prediction of all instances
    vector<double> trainpreds_sum; // prediction sum for all instances
    vector<double> validpreds;     // prediction of validation data
    vector<double> validpreds_sum; // prediction sum of validation data
    vector<double> oobpreds;       // prediction of oob instances only
    vector<double> oobpreds_sum;   // prediction sum for oob instances only
    vector<int>    oobpreds_count; 

    // build ntrees
    int stage_size = 1000;
    for (int t = 0; t<ntrees; t++) {
        int t1 = t % stage_size;
        if (t % stage_size == 0) {

            if (guide_ && t!=0)
                guide_->SetFeatureWeights(vi_, fids);
            
            vi_.assign(m, 0.0);
            feature_count_.assign(m, 0);
            trainpreds.assign(n, 0.0);
            oobpreds.assign(n, 0.0);
            trainpreds_sum.assign(n, 0.0);
            oobpreds_sum.assign(n, 0.0);
            oobpreds_count.assign(n, 0);
            trees_.clear();

            if (valid_insts.size() != 0) { 
                validpreds.assign(valid_insts.size(), 0.0);
                validpreds_sum.assign(valid_insts.size(), 0.0);
            }
            if (args.mode == 'd')
                cout << "#=========== New iteration " << t/stage_size << " ============\n";
        }

        vector<const Instance*> train_instances;
        vector<const Instance*> oob_instances;

        samplecount.assign(n, 0);
        if (args.bootstrap == 0) {
            //subagging: sampling without replacement
            random_shuffle(random_deck.begin(), random_deck.end());
            int subn = (int)(n * 0.73);
            for (int i=0; i<subn; i++) {
                train_instances.push_back(insts[random_deck[i]]);
                samplecount[random_deck[i]]++;
            }
        } else {
            // bagging: sampling with replacement
            for (int i=0; i<n; i++) {
                int c = rand() / (RAND_MAX / n + 1);
                train_instances.push_back(insts[c]);
                samplecount[c]++;
            }
        }

        // Build Tree
        RegressionTree * tree = new RegressionTree();
        tree->SetErrorDcrs(&vi_);
        tree->feature_count_ = &feature_count_;
        tree->guide(guide_);
        tree->weighted_sampling(t1!=0);


        tree->Train(train_instances, fids, newargs);
        trees_.push_back(tree);


        if (args.mode == 'd' || args.mode == 'r') {
            //get out-of-bag instances
            for (int i=0; i<n; i++) {
                if (samplecount[i]==0) {
                    oob_instances.push_back(insts[i]);
                }
            }

            //accumulate training and oob predictions
            for (int i=0; i<n; i++) {
                double pred = tree->Predict(*(insts[i]));
                trainpreds_sum[i] += pred;
                if (samplecount[i]==0) {
                    oobpreds_sum[i] += pred;
                    oobpreds_count[i] += 1;
                    
                    if (oobpreds_count[i] != 0)
                        oobpreds[i] = oobpreds_sum[i] / oobpreds_count[i];
                }
                trainpreds[i] = trainpreds_sum[i] / (t1+1);
            }
            
            if (args.mode == 'd') {  // For debug mode only
                cout << t << ", " << Evaluate(insts ,trainpreds) << ", " << Evaluate(insts, oobpreds);
                if (args.valid_input != "") {                    // predict validation data if availible
                    int numval = valid_insts.size();
                    for (int i=0; i<numval; i++) {
                        double pred = tree->Predict(*(valid_insts[i]));
                        validpreds_sum[i] += pred;
                        validpreds[i] = validpreds_sum[i] / (t1+1);
                    }

                    cout << ", " << Evaluate(valid_insts, validpreds);
                }
                cout << endl;
            }
            cout.flush();
        }
    }

    trainerror_ = Evaluate(insts, trainpreds);
    ooberror_ = Evaluate(insts, oobpreds);

    NormalizeVi();
    
    misc::write_vector(vi_, args.weight_output.c_str());
    //misc::write_sparse(feature_count_, 1, m, "ft_counts.bin");

    if (guide_) {
        guide_->SetFeatureWeights(vi_, fids);
    }
}


void RandomForests::DestoryTrees() {
    size_t T = trees_.size();
    for (size_t t=0; t<T; t++) {
        if (trees_[t]) {
            delete trees_[t];
            trees_[t] = NULL;
        }
    }
}


// Given an instance predicts its label
double RandomForests::Predict(const Instance& inst) {
    double pred = 0.0;
    int ntrees = trees_.size();
    for (int t=0; t<ntrees; t++) {
        pred += trees_[t]->Predict(inst);
    }
    return pred/ntrees;
}


// Given a set of instances predicts their labels
vector<double> RandomForests::Predict(const std::vector<const Instance*>& insts) {
    vector<double> preds(insts.size());
    size_t n =  insts.size();
    for (size_t i=0; i<n; i++) {
        preds[i] = Predict(*insts[i]);
    }
    return preds;
}


// Calculate the RMSE for given prediction
double RandomForests::Evaluate(const vector<const Instance*>& insts, const vector<double>& pred) {
    size_t n = pred.size();
    double sum = 0.0;
    for (size_t i=0; i<n; i++) {
        sum += (pred[i] - insts[i]->label)*(pred[i] - insts[i]->label);
    }
    return sqrt(sum/n);
}


void RandomForests::NormalizeVi() {
    size_t m = vi_.size();
    double sum = 0.0;
    for (size_t j=0; j<m; ++j)
        sum += vi_[j];
    
    for (size_t j=0; j<m; ++j)
        vi_[j] /= (sum/100.0);
}
