#ifndef RANDOM_FORESTS_BUILDER_H
#define RANDOM_FORESTS_BUILDER_H

#include <vector>
#include "instance.h"
#include "attribute.h"
#include "args.h"
#include "rf_guide.h"
#include "random_forests.h"
#include "rt_builder.h"

class RandomForestsBuilder {
public:
    RandomForestsBuilder(const std::vector<const Attribute*>& attrs, const Attribute& label_attr);
    ~RandomForestsBuilder();

    void    guide(RfGuide* g) {guide_ = g;}  // set the guide network
    double  train_err() const {return trainerror_;}
    double  oob_err() const {return ooberror_;}
    const std::vector<double>& vi() const { return vi_; }
    std::vector<double>& vi() { return vi_; }
    void vi(const std::vector<double>& v) { vi_ = v; } 

    RandomForests * Train(const std::vector<const Instance*>& train_insts, 
                          const std::vector<const Instance*>& valid_insts,
                          const std::vector<int>& attr_idxs, const ArgType& args);


private:
    void NormalizeVi();

    const std::vector<const Attribute*>& attrs_;
    const Attribute& label_attr_;
    RfGuide* guide_;

    std::vector<double> vi_; // variable importance
    double ooberror_;
    double trainerror_;
};


#endif
