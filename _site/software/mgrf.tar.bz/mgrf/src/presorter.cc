#include "misc.h"
#include "presorter.h"


using namespace std;

PreSorter::PreSorter(const vector<const Instance*>& instances) {
    int m = instances[0]->num_features;
    size_t n = instances.size();
    double* f_vals = new double[n];
    
    for (int j=0; j<m; j++) {
        int* indices = new int[n];
        for (size_t i=0; i<n; i++) 
            f_vals[i] = instances[i]->features[j];
        misc::sort_by_index(f_vals, indices, n);
        sorted_list_.push_back(indices);
    }
}

PreSorter::~PreSorter() {
    int m = sorted_list_.size();
    for (int i=0; i<m; i++) {
        if (sorted_list_[i]) {
            delete[] sorted_list_[i];
            sorted_list_[i] = NULL;
        }
    }
}
