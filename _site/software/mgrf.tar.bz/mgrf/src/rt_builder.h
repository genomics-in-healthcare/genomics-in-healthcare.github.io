#ifndef RANDOM_TREE_BUILDER_H
#define RANDOM_TREE_BUILDER_H

#include <vector>
#include <set>
#include "args.h"
#include "random_tree.h"
#include "dataset.h"
#include "rf_guide.h"


class RandomTreeBuilder {
public:
    RandomTreeBuilder(const std::vector<const Attribute*>& attrs, const Attribute& label_attr);

    void    guide(RfGuide* g) {guide_ = g;}  // set the guide network

    RandomTree * Train(const std::vector<const Instance*>& insts, const std::vector<int>& attr_idxs, const ArgType& args);  

    void SetImpurityDcrs(std::vector<double>* error_dcrs) { impurity_dcrs_ = error_dcrs; }

private:
    #ifdef _MSC_VER
    static double log2(double x) { return log(x) / log(2.0);}
    #endif

    // split a node with given data samples
    double  SplitNode(const std::vector<const Instance*>& insts, const std::vector<int>& ft_idxs, 
                       std::vector<const Instance*>* left_insts, std::vector<const Instance*>* right_insts, 
                       TreeNode* node); 

    // Find the best split point given a feature based on Gini Index
    double FindSplit_GI_cont(const std::vector<const Instance*>& insts, const std::vector<int>& counts, int f, double* vsplit);
    double FindSplit_GI_cate(const std::vector<const Instance*>& insts, const std::vector<int>& counts, int f, std::set<int>* left_cates);

    // Find the best split point given a feature based on squared loss for regression
    double FindSplit_SL_cont(const std::vector<const Instance*>& insts, double r, double ybr, int f, double* vsplit);
    double FindSplit_SL_cate(const std::vector<const Instance*>& insts, double r, double ybr, int f, std::set<int>* left_cates);

    bool IsTerminal(const std::vector<const Instance*>& insts);  // Check if given instances satifies the terminal condition

    static double Entropy(const std::vector<int>& counts, int n);
    static double GiniIndex(const std::vector<int>& counts, int n);


    const std::vector<const Attribute*>& attrs_;
    const Attribute& label_attr_;

    RfGuide* guide_;
    //std::vector<double> freqs_;

    ArgType args_; // Program parameters that will be used during the training

    std::vector<double>* impurity_dcrs_; // impurity decrease for each feature (given by random forest instance) 
    
    bool weighted_sampling_; // an indicator for whether to use weighted sampling on features
};


#endif
