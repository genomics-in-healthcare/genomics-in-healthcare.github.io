#include <math.h> // sqrt
#include <algorithm>  // random_shuffle
#include "misc.h"
#include "rf_builder.h"

using namespace std;

RandomForestsBuilder::RandomForestsBuilder(const vector<const Attribute*>& attrs, const Attribute& label_attr) : 
    attrs_(attrs), label_attr_(label_attr), guide_(NULL) 
{    
}


RandomForestsBuilder::~RandomForestsBuilder() {
}


RandomForests* RandomForestsBuilder::Train(const vector<const Instance*>& insts, 
               const vector<const Instance*>& valid_insts,
               const vector<int>& attr_idxs, const ArgType& args)
{
    int n = insts.size();
    int m = attrs_.size(); // number of all features

    int ntrees = args.ntrees;

    vector<int> random_deck(n);  // used to generate random sampling without replacment
    for (int j=0; j<n; ++j) 
        random_deck[j] = j;

    vi_.assign(m, 0.0);
    vector<int> samplecount(n, 0);

    RandomForests * rf = new RandomForests();
    vector<RandomTree*>& trees = rf->trees();
    trees.reserve(ntrees);

    // Training trace
    vector<double> trainpreds;     // prediction of all instances
    vector<double> trainpreds_sum; // prediction sum for all instances
    vector<double> validpreds;     // prediction of validation data
    vector<double> validpreds_sum; // prediction sum of validation data
    vector<double> oobpreds;       // prediction of oob instances only
    vector<double> oobpreds_sum;   // prediction sum for oob instances only
    vector<int>    oobpreds_count;

    vector< vector<int> > train_cls_count; // [i,j]: count of prediction for label j in i-th instance
    vector< vector<int> > valid_cls_count;
    vector< vector<int> > oob_cls_count;

    // build ntrees
    int stage_size = 1000;
    for (int t = 0; t<ntrees; t++) {
        int t1 = t % stage_size;
        if (t % stage_size == 0) {

            if (guide_ && t!=0)
                guide_->SetFeatureWeights(vi_, attr_idxs);
            
            vi_.assign(m, 0.0);
            trainpreds.assign(n, 0.0);
            oobpreds.assign(n, 0.0);
            trainpreds_sum.assign(n, 0.0);
            oobpreds_sum.assign(n, 0.0);
            oobpreds_count.assign(n, 0);

            train_cls_count.assign(n, vector<int>(label_attr_.num_classes, 0));
            oob_cls_count.assign(n, vector<int>(label_attr_.num_classes, 0));

            if (valid_insts.size() != 0) { 
                validpreds.assign(valid_insts.size(), 0.0);
                validpreds_sum.assign(valid_insts.size(), 0.0);
                valid_cls_count.assign(valid_insts.size(), vector<int>(label_attr_.num_classes, 0));
            }
            if (args.mode == 'd')
                cout << "#=========== Stage " << t/stage_size << " ============\n";
        }

        vector<const Instance*> train_instances;
        vector<const Instance*> oob_instances;

        samplecount.assign(n, 0);
        if (args.bootstrap == 0) {
            //subagging: sampling without replacement
            random_shuffle(random_deck.begin(), random_deck.end());
            int subn = (int)(n * 0.73);
            for (int i=0; i<subn; i++) {
                train_instances.push_back(insts[random_deck[i]]);
                samplecount[random_deck[i]]++;
            }
        } else {
            // bagging: sampling with replacement
            for (int i=0; i<n; i++) {
                int c = rand() / (RAND_MAX / n + 1);
                train_instances.push_back(insts[c]);
                samplecount[c]++;
            }
        }

        // Build Tree
        RandomTreeBuilder rtb(attrs_, label_attr_);
        rtb.SetImpurityDcrs(&vi_);
        rtb.guide(guide_);
        //rtb.weighted_sampling(t1!=0);

        RandomTree * tree = rtb.Train(train_instances, attr_idxs, args);
        trees.push_back(tree);
        cout << (*tree) << endl;

        if (args.mode == 'd' || args.mode == 'r') {
            //get out-of-bag instances
            for (int i=0; i<n; i++) {
                if (samplecount[i]==0)
                    oob_instances.push_back(insts[i]);
            }

            //accumulate training and oob predictions
            if (args.type == 'c') { // for classification
                for (int i=0; i<n; i++) {
                    int pred = (int)tree->Predict(*(insts[i]));
                    train_cls_count[i][pred] += 1;
                    if (samplecount[i]==0) {
                        oob_cls_count[i][pred] += 1;
                        oobpreds[i] = misc::IndexMax(oob_cls_count[i]);
                    }
                    trainpreds[i] = misc::IndexMax(train_cls_count[i]);
                }
            } else { // for regression

                for (int i=0; i<n; i++) {
                    double pred = tree->Predict(*(insts[i]));
                    trainpreds_sum[i] += pred;
                    if (samplecount[i]==0) {
                        oobpreds_sum[i] += pred;
                        oobpreds_count[i] += 1;
                    
                        if (oobpreds_count[i] != 0)
                            oobpreds[i] = oobpreds_sum[i] / oobpreds_count[i];
                    }
                    trainpreds[i] = trainpreds_sum[i] / (t1+1);
                }
            }
            
            if (args.mode == 'd') {  // For debug mode only
                if (args.type == 'c')
                    cout << t << ", " << Instance::ZeroOneLoss(insts, trainpreds) << ", " << Instance::ZeroOneLoss(insts, oobpreds);
                else
                    cout << t << ", " << Instance::Rmse(insts, trainpreds) << ", " << Instance::Rmse(insts, oobpreds);
                
                if (args.valid_input != "") {                    // predict validation data if availible
                    int num_val = valid_insts.size();
                    
                    if (args.type == 'c') { // for classification
                        for (int i=0; i<num_val; i++) {
                            int pred = (int)tree->Predict(*(valid_insts[i]));
                            valid_cls_count[i][pred] += 1;
                            validpreds[i] = misc::IndexMax(valid_cls_count[i]);
                        }
                        cout << ", " << Instance::ZeroOneLoss(valid_insts, validpreds);
                    } else {
                        for (int i=0; i<num_val; i++) {
                            double pred = tree->Predict(*(valid_insts[i]));
                            validpreds_sum[i] += pred;
                            validpreds[i] = validpreds_sum[i] / (t1+1);
                        }
                        cout << ", " << Instance::Rmse(valid_insts, validpreds);
                    }
                }
                cout << endl;
            }
            cout.flush();
        }
    }

    if (args.type == 'c') {
        trainerror_ = Instance::ZeroOneLoss(insts, trainpreds);
        ooberror_ = Instance::ZeroOneLoss(insts, oobpreds);
    } else {
        trainerror_ = Instance::Rmse(insts, trainpreds);
        ooberror_ = Instance::Rmse(insts, oobpreds);
    }

    NormalizeVi();
    
    misc::write_vector(vi_, args.weight_output.c_str());

    if (guide_) {
        guide_->SetFeatureWeights(vi_, attr_idxs);
    }

    return rf;
}


void RandomForestsBuilder::NormalizeVi() {
    size_t m = vi_.size();
    double sum = 0.0;
    for (size_t j=0; j<m; ++j)
        sum += vi_[j];
    
    for (size_t j=0; j<m; ++j)
        vi_[j] /= (sum/100.0);
}
