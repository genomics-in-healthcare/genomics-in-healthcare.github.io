function vi = variationOfInformation (clust1, clust2)

% vi = variationOfInformation (clust1, clust2)
% compute the variation of information between two clusterng results


p1 = [];
for i=1:length(clust1)
    p1(i) = length(clust1{i});
end
p1 = p1 ./ sum(p1);
p1 = p1(find(p1));
H1 = -sum(p1 .* log2(p1));

p2 = [];
for i=1:length(clust2)
    p2(i) = length(clust2{i});
end
p2 = p2 ./ sum(p2);
p2 = p2(find(p2));
H2 = -sum(p2 .* log2(p2));

cm = confusionMatrix(clust1, clust2);

cm = cm ./ sum(sum(cm));

d = p1' * p2;

cm2 = (cm+eps) .* ((d+eps).^(-1));

vi = H1 + H2 - 2 *sum(sum(cm .* log2(cm2)));
