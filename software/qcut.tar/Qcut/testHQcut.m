%% Generates a random network with 100 vertices and 4 communities. 
%% The intra-community and inter-community edge density is 0.5 and 0.02 respectively.
[net, ct] = simulatedBlocks(1000, 40, 0.5, 0.02); 

% find community structure
clus = QcutPlus(net); 
hclus = HQcut(net, clus);

% show the true community structure.
showClusters(ct, net, 1); 

% show the community structure predicted by Qcut.
 showClusters(clus, net, 2);

% show the community structure predicted by HQcut.
 showClusters(hclus, net, 3);

% compute the confusion matrix between the predicted communities and true communities
cm1 = confusionMatrix(clus, ct);
cm2 = confusionMatrix(hclus, ct);
figure
imagesc(cm1);
figure
imagesc(cm2);

% compute the agreement between the predicted communities and true communities using three
% different types of measurement
ji1 = JaccardIndex(clus, ct)
ji2 = JaccardIndex(hclus, ct)

[w11, w12] = WallaceIndex(clus, ct)
[w21, w22] = WallaceIndex(hclus, ct)

vi1 = variationOfInformation(clus, ct)
vi2 = variationOfInformation(hclus, ct)
