function [clus, q] = HQcut(A, clus, mz, minq)

%% similar to QcutPlus, except that QcutPlus is executed recursively on each community.
%% A - the adjacency matrix
%% clus - the first-level community (eg., obtained by Qcut)
%% mz and minq determine when the recursion should terminate.
%% minq - the minimum Q value for sub-communities to be accepted. default value is 0.3
%% mz - the minimum Z-score of the Q value. default value is 2

if (nargin < 2)
    clus = QcutPlus(A);
end

if (nargin < 3)
    mz = 2;
end

if (nargin < 4)
    minq = 0.3;
end

i = 1;
while (i <= length(clus))
    if (size(clus{i}) < 2)  % ignore small communities
        i = i + 1;
        continue;
    end
    a = A(clus{i}, clus{i});
    [sca, q, z, dq] = QcutPlusSig(a, 20, minq, 0.03);
%    [q z dq]
    if (z > mz)
        for j=1:length(sca)
            sca{j} = clus{i}(sca{j});
        end
        clus{i} = sca;
        clus = flat(clus);
    else
        i = i + 1;
    end
end

q = Q(clus, A);
