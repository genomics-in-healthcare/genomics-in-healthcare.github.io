function cm = confusionMatrix (clust1, clust2)

% cm = confusionMatrix (clust1, clust2)
% compute the confusion matrix of two clustering results

cm = zeros(length(clust1), length(clust2));

for i = 1:length(clust1)
    for j = 1:length(clust2)
        cm(i, j) = length(intersect(clust1{i}, clust2{j}));
    end
end
