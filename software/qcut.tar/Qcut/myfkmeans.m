function [clusts, bestQ] = myfkmeans(data, nClusts, nIter)
  bestQ = inf;
  clear bestC;
  for i = 1:nIter
     [centers,mincenter,mindist,q2,quality] = fkmeans(data,nClusts, 1);
     if quality < bestQ
        bestC = mincenter;
        bestQ = quality;
     end
  end

  clear clusts;
  for i=1:nClusts
    I = find(bestC == i);
    clusts{i} = I';
  end
