% Generates a random network with 100 vertices and 4 communities. 
% The intra-community and inter-community edge density is 0.5 and 0.1 respectively.
[a, ct] = simulatedBlocks(100, 4, 0.5, 0.1); 

% finds community structure
clus = QcutPlus(a); 

% shows the true community structure.
%showClusters(ct, a, 1); 

% shows the detected community structure.
% showClusters(clus, a, 2);

% compute the confusion matrix between the predicted communities and true communities
cm = confusionMatrix(clus, ct)

% compute the consistency between the predicted communities and true communities using three
% types of measurement
ji = JaccardIndex(clus, ct)

[w1, w2] = WallaceIndex(clus, ct)

vi = variationOfInformation(clus, ct)
