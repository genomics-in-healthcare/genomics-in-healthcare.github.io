% load cell-cycle yeast gene expression data
expr = dlmread('cc.expr', '\t', 0,1);

% for two nodes to be considered as co-expressed, their expression profiles
% need to satisfy: (1) Pearson correlation coefficient is higher than 0.5,
% and (2) one gene is within the top-10 most correlated gene of the other; 
net = getCoexpNet(expr, .5, 10); 

% find the community structure
clust = QcutPlus(net);

% present the community structure in adjancency matrix
showClusters(clust, net, 1);
xlabel('Gene');
ylabel('Gene');

% present the expression patterns for the genes in each community
showRowClusters(clust, expr, 2);
xlabel('Sample');
ylabel('Gene');
