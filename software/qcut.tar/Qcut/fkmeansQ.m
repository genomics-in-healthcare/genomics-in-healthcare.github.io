function [clust, bestQ] = fkmeansQ(data, A, nClusts, nIter)
  bestQ = -1;
  clear bestC;
  for i = 1:nIter
     [centers,mincenter,mindist] = fkmeans(data,nClusts, 1);
     clust = center2clust(mincenter);
     q = Q(clust, A);
     if q > bestQ
        bestC = clust;
        bestQ = q;
     end
  end
  
  clust = bestC;
