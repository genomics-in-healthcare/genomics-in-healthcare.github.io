%% Generates a random network with 100 vertices and 4 communities. 
%% The intra-community and inter-community edge density is 0.5 and 0.1 respectively.
[net, ct] = simulatedBlocks(100, 4, 0.5, 0.1); 

%% or alternatively, load a network from file: 

% data = load('network.dat');
% n = max(max(data));
% net = sparse(data(:, 1), data(:, 2), 1, n, n);
% net = max(net, net');
% ct = {1:25, 26:50, 51:75, 76:100};

% find community structure
clus = QcutPlus(net); 

% show the true community structure.
showClusters(ct, net, 1); 

% show the detected community structure.
 showClusters(clus, net, 2);

% compute the confusion matrix between the predicted communities and true communities
cm = confusionMatrix(clus, ct)

% compute the agreement between the predicted communities and true communities using three
% different types of measurement
ji = JaccardIndex(clus, ct)

[w1, w2] = WallaceIndex(clus, ct)

vi = variationOfInformation(clus, ct)
