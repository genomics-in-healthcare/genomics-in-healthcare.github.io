function b = biparize (a)
[i, j] = size(a);
b = sparse(i+j, i+j);
b(1:i, i+1:end) = a;
b(i+1:end, 1:i) = a';
