function ji = JaccardIndex(c1, c2)

% ji = JaccardIndex(c1, c2)
% compute the Jaccard Index between two clusterng results

cm = confusionMatrix(c1, c2);
N11 = sum(sum(cm .^ 2 - cm));
d1 = sum(cm, 2);
d2 = sum(cm, 1);
d1 = sum(d1 .* (d1 - 1));
d2 = sum(d2 .* (d2 - 1));

ji = N11 ./ (d1 + d2 + eps - N11);
