function clust = center2clust(center)
  clust = {};
  for i=1:max(center)
    I = find(center == i);
    if (length(I) > 0)
      clust{end+1} = I';
    end
  end
