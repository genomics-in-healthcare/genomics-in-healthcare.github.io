function [clus1, clus2] = showBiClusters(clusts, a, j, noLine)
% [clus1, clus2] = showBiClusters(clusts, a, j, noLine) shows the reorganized adjacency matrix of a bi-partite graph.
% input:
% clusts - the clusters returned by Qcut. 
% a - the adjancency matrix. 
% j - the figure you want the adjacency matrix to be draw. e.g., 1.
% noLine - a flag to show if lines should be drawn to separate clusters
% the rows and columns of the adjacency matrix represent two different types of vertices, although 
% all vertices are indexed sequentially in clusts. So if a graph contains m type 1 vertices and n type 2 vertices,
% "a" should be a (mxn) matrix, while the IDs in clusts are from 1 to m+n, with type 1 vertices indexed from 1 to m, 
% and type 2 vertices indexed from m+1 to m+n.
% output:
% clus1 - the clusters for type 1 vertices
% clus2 - the clusters for type 2 vertices

if (nargin < 4)
    noLine = 0;
end
figure (j);
[m, n] = size(a);
row=[];
col=[];
for i=1:length(clusts)
    c = clusts{i};
    clus1{i} = c (find(c <= m));
    clus2{i} = c (find(c > m)) - m;
    row = [row clus1{i}];
    col = [col clus2{i}];
end
imagesc(a(row, col));
x = 0.5;
y = 0.5;
width =length(col) + .5;
height = length(row) + .5; 
for i=1:(length(clusts)-1)
    x = x + length(clus2{i});
    y = y + length(clus1{i});
    if (~noLine)
        line([x, x], [0, height], 'Color', [.5, .5, .5], 'LineWidth', .5);
        line([0, width], [y, y], 'Color', [.5, .5, .5], 'LineWidth', .5);
    end
end
