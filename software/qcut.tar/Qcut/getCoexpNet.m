function net = getCoexpNet(expr, min_cc, max_rank)

%% net = getCoexpNet(expr, min_cc, max_rank)
%% construct a WEIGHTED gene co-expression network given a gene expression data
%% expr: gene expression data. Each row is a gene, each column is a sample
%% min_cc: threshold on Pearson Correlation Coefficient
%% max_rank: threshold on the ranks of the correlation coeffient values

cc = corrcoef(expr');
n = size(expr, 1);
cc = cc - sparse(1:n, 1:n, 1);
net = sparse(cc >= min_cc); 

if (nargin == 3 & max_rank < length(cc))
   [Y, I] = sort(cc);
   [Y, I] = sort(I);
   net = net & sparse(I > n - max_rank);
end

net = net .* cc;
net = max(net, net');
