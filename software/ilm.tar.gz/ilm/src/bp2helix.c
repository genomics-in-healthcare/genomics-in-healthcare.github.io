#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>
#include "grafio.h"
#include "profile.h"

int min_hlx = 2;

int seqLen;

typedef struct Helix {
  int start;
  int end;
  int len;
  int score;
} Helix;

typedef struct CompositeHelix {
  Helix* vHelix;
  int n;
  int len;
  double score;
} CompHelix;

void displayHelix(Helix h);

int compareHelix(const void* h1, const void* h2) {
   if (((Helix*)h1)->score > ((Helix*)h2)->score) return -1;
   if (((Helix*)h1)->score < ((Helix*)h2)->score) return 1;
   return 0;
}

int compareCompHelix(const void* h1, const void* h2) {
   if (((CompHelix*)h1)->score > ((CompHelix*)h2)->score) return -1;
   if (((CompHelix*)h1)->score < ((CompHelix*)h2)->score) return 1;
   return 0;
}

getHelices(Helix** ret_vHelix, int* ret_nHelix, int* mate, int seqLen) {
   int i, j, k;
   Helix* vHelix;
   int nHelix;
   int start, len;

   vHelix = malloc(seqLen * sizeof(Helix));
   start = 1;
   len = 1;
   nHelix = 0;
   for(i = 1; i < seqLen; i++) {
       if (i > mate[i]) { 
           start = i+1; 
           len = 1; 
           continue;
       }
       if (mate[i] == (mate[i+1] + 1)) {
           len++;
       } else {
           if (len >= min_hlx) {
              Helix helix;
              helix.start = start;
              helix.end = mate[start];
              helix.len = len;
              helix.score = 0;
              vHelix[nHelix++] = helix;
           }
           start = i+1;
           len = 1;
       }
   }

   vHelix = realloc(vHelix, nHelix*sizeof(Helix));

   *ret_vHelix = vHelix;
   *ret_nHelix = nHelix;
}

fillHelixScore(Helix* vHelix, int nHelix, struct Graph* graf) {
   int i, j;
   for(i = 0; i < nHelix; i++) {
     for(j = 0; j < vHelix[i].len; j++) {
        vHelix[i].score += Edge(*graf, vHelix[i].start+j, vHelix[i].end-j);
     }
   }
}

int canCombine(Helix* h1, Helix* h2) {
   int gap1 = h2->start - h1->start - h1->len;
   int gap2 = h1->end - h2->end - h1->len; 
   if (gap1 > 1 || gap2 > 1) return 0;
   if (gap1 + gap2 > 1) return 0;
   if (h1->score <= 0 || h2->score <= 0) return 0;
   if (h1->score*h2->len / (h2->score*h1->len) > 5) return 0;
   if (h2->score*h1->len / (h1->score*h2->len) > 5) return 0;
   return 1;
}

freeVCompHelix(CompHelix* vCompHelix, int n) {
   int i;
   for (i = 0; i < n; i++) {
      free(vCompHelix[i].vHelix);
   }
   free(vCompHelix);
}

makeCompositeHelix(CompHelix** ret_vCompHelix, int* ret_nCompHelix, Helix* vHelix, int nHelix) {
   CompHelix* vCompHelix = malloc(nHelix * sizeof(CompHelix)); 
   int i, j = 0, k = 0;
   int score = 0, len = 0;
   for(i = 1; i < nHelix; i++) {
      j++;
      score += vHelix[i-1].score;
      len += vHelix[i-1].len;
      if(!canCombine(vHelix+i-1, vHelix+i)) {
        if (len >= min_hlx_len) {
           vCompHelix[k].len = len;
           vCompHelix[k].n = j;
           vCompHelix[k].score = score;
           vCompHelix[k].vHelix = malloc(j * sizeof(Helix));
           for(; j > 0; j--) {
             vCompHelix[k].vHelix[vCompHelix[k].n-j] = vHelix[i-j];
           }
           k++;
        }
        j = 0;
        score = 0;
        len = 0;
      }
   }
   j++;
   score += vHelix[i-1].score;
   len += vHelix[i-1].len;
   if (len >= min_hlx_len) {
      vCompHelix[k].vHelix = malloc(j * sizeof(Helix));
      vCompHelix[k].n = j;
      vCompHelix[k].len = len;
      vCompHelix[k].score = score;
      for(; j > 0; j--) {
         vCompHelix[k].vHelix[vCompHelix[k].n-j] = vHelix[i-j];
      }
      k++;
   }
   vCompHelix = realloc(vCompHelix, sizeof(CompHelix) * (k));
   *ret_nCompHelix = k;
   *ret_vCompHelix = vCompHelix; 
}

void displayHelix(Helix h) {
   fprintf(stderr, "%4d-%4d : %4d-%4d   %4d\n", h.start, h.start+h.len-1, h.end-h.len+1, h.end, h.len);
}

void displayCompHelix(CompHelix cHelix) {
   int i;
   fprintf(stderr, "comphelix len=%d\n", cHelix.len);
   for(i = 0; i < cHelix.n; i++) {
      displayHelix(cHelix.vHelix[i]);
   }
   fprintf(stderr, "\n");
}

void display(CompHelix* vCompHelix, int n) {
   int i;
   for(i = 0; i < n; i++) {
      displayCompHelix(vCompHelix[i]);
   }
   fprintf(stderr, "\n");
}
