#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <math.h>
#include "seqio.h"
#include "grafio.h"

#define DEFAULT_MIN_LOOP 3
#define OFF 0
#define ON  1

int Encode(char base)
{
  int ret;

  switch(toupper(base))
    {
    case 'A': ret = 0; break;
    case 'C': ret = 1; break;
    case 'G': ret = 2; break;
    case 'T':
    case 'U': ret = 3; break;
    default : ret = 4; break;
    }

  return ret;
}


int main(int argc, char *argv[])
{
  struct Sequence seq;
  struct Graph graf;
  char **seq_list;
  int   *Hx;
  int    Hxy;
  int    mi;
  int   *base_freq[5];
  int    dinuc_freq[5][5];
  int   *table;
  char  *curr_arg;
  int    num_seqs;
  float  f;
  int    min_loop = DEFAULT_MIN_LOOP;
  int    text_mode = OFF;
  int    coded_base_1, coded_base_2;
  int    i, j, k, m;

  for (i = 0; i < 5; i++)
    for (j = 0; j < 5; j++)
      dinuc_freq[i][j] = 0;
  
  for (i = 0;;) {
    if (++i > argc - 1) {
      fprintf(stderr, "\nUsage: jmixy [-options] filename\n");
      fprintf(stderr, "  Options:\n");
      fprintf(stderr, "    -l L: Set minimum loop length to L\n");
      fprintf(stderr, "            (Default = %d)\n", min_loop);
      fprintf(stderr, "    -t  : Write output in text format\n");
      fprintf(stderr, "            (Default = Binary format)\n\n");
      exit(EXIT_FAILURE);
    }

    curr_arg = argv[i];
    if (curr_arg[0] != '-')
      break;

    switch(curr_arg[1])
      {
      case 'l':
	curr_arg = argv[++i];
	if (!isdigit(curr_arg[0])) {
	  fprintf(stderr, "\nError: Minimum loop length not specified ");
	  fprintf(stderr, "after -l\n\n");
	  exit(EXIT_FAILURE);
	}
	min_loop = atoi(curr_arg);
	break;
      case 't':
	text_mode = ON;
	break;
      default :
	fprintf(stderr, "\nUnknown switch: %s\n\n", curr_arg);
	exit(EXIT_FAILURE);
      }
  }

  if (!OpenSeq(&seq, argv[i]))
    exit(EXIT_FAILURE);
  num_seqs = CountSeq(&seq);

  if (!MakeGraf(&graf, seq.seq_len))
    exit(EXIT_FAILURE);
  graf.n_edge = CountMaxEdges(&graf);

  base_freq[0] = (int *)   calloc(5*(seq.seq_len + 1)       , sizeof(int));
  Hx =           (int *)   calloc(seq.seq_len + 1           , sizeof(int));
  table =        (int *)   calloc(num_seqs + 1              , sizeof(int));
  seq_list =     (char **) calloc(num_seqs                  , sizeof(char *));

  if ( (base_freq[0] == NULL) || (Hx == NULL) || (table == NULL) ||
      (seq_list == NULL) ) {
    fprintf(stderr, "\nCannot allocate memory\n\n");
    exit(EXIT_FAILURE);
  }

  for (i = 1; i < 5; i++)
    base_freq[i] = base_freq[i - 1] + seq.seq_len + 1;

  for (i = 1; i <= num_seqs; i++) {
    f = ((float) i)/((float) num_seqs);
    table[i] = (int) (-10000.*f*log(f) + 0.5);
  }

  seq_list[0] =  (char *)  calloc(num_seqs*(seq.seq_len + 1), sizeof (char));
  if (seq_list[0] == NULL) {
    fprintf(stderr, "\nCannot allocate memory\n\n");
    exit(EXIT_FAILURE);
  }

  for (i = 1; i < num_seqs; i++)
    seq_list[i] = seq_list[i - 1] + seq.seq_len + 1;

  for (i = 0; i < num_seqs; i++) {
    if (!GetSeq(&seq)) {
      fprintf(stderr, "\nUnexpected end of file\n\n");
      exit(EXIT_FAILURE);
    }

    for (j = 1; j <= seq.seq_len; j++) {
      coded_base_1 = Encode(seq.seq[j]);

      seq_list[i][j] = (char) coded_base_1;
      base_freq[coded_base_1][j]++;
    }
  }

  CloseSeq(&seq);

  for (i = 1; i <= seq.seq_len; i++)
    for (j = 0; j < 5; j++)
      Hx[i] += table[base_freq[j][i]];

  for (i = min_loop + 2; i <= seq.seq_len; i++)
    for (j = 1; j < i - min_loop; j++) {
      for (k = 0; k < num_seqs; k++) {
	coded_base_1 = seq_list[k][i];
	coded_base_2 = seq_list[k][j];
	dinuc_freq[coded_base_1][coded_base_2]++;
      }

      Hxy = 0;
      for(k = 0; k < 5; k++)
	for(m = 0; m < 5; m++) {
	  Hxy += table[dinuc_freq[k][m]];
	  dinuc_freq[k][m] = 0;
	}

      mi = (Hx[j] + Hx[i] - Hxy)/10;
      mi = mi < 0 ? 0 : mi;

      Edge(graf, i, j) = mi;
    }

  if (text_mode == OFF)
    WriteBinGraf(stdout, &graf);
  else
    WriteTextGraf(stdout, &graf, ALL_EDGES);

  return (EXIT_SUCCESS);
}
