#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <unistd.h>
#include <getopt.h>
#include <math.h>
#include "bp2helix.c"
#include "stack.h"
#include "grafio.h"
#include "profile.h"

#define THRESHOLD 0

int* map;
int mapsize;
long* sum;
int divided = 0;
int start5 = 0;
int end5 = 0;
int start3 = 0;
int end3 = 0;

typedef struct Graph Graph;

/* allocate memory for a half matrix, only the lower half (including 
 * the diagonal) were allocated. r[i][0] = r[i-1][i-1] */
int** makeHalfMatrix(int size) {
   int i;
   int** matrix = malloc((size+1) * sizeof(int*));
   matrix[0] = calloc(size * (size + 1) / 2, sizeof(int));
   for (i = 1; i <= size; i++) {
      matrix[i] = matrix[i-1] + i - 1;
   }
   return matrix;
}

/* free up memory */
freeHalfMatrix(int** m) {
   free(m[0]);
   free(m);
}

int canReuse(int i, int j, int** r) {
    if (!divided) return 0;
    return j < start5 || i > end3 || (i > end5 && j < start3)|| r[j][i] == 0;
}

/* Nussinov dynamic programming procedure 
 * on return, r points to the dynamic programming matrix 
 * that can be used to trace back the base pairs.
 */
void dp(int** r, Graph* graf) {
   int vlen;
   int i, j, k;
   int mi, mj, mk, i_1, j_1, k_1;
   int temp;

   for (vlen = 0; vlen < mapsize; vlen++) {
      for(i = 1; i < mapsize - vlen; i++) {
         j = i + vlen + 1;
         mi = map[i];
         mj = map[j];
         if (canReuse(mi, mj, r)) continue;
         if (mj - mi - 1 < min_loop_len 
                    || vlen < min_vloop_len) {
           r[mj][mi] = 0;
           continue;
         }
         i_1 = map[i+1];
         j_1 = map[j-1];
         if (mj > i_1)
           r[mj][mi] = r[mj][i_1];   //i unpaired
         if (j_1 > mi && r[j_1][mi] > r[mj][mi]) //j unpaired
           r[mj][mi] = r[j_1][mi];
         temp = Edge(*graf, mj, mi);
         if (j_1 > i_1) 
            temp += r[j_1][i_1];
         if (temp > r[mj][mi]) // i paired with j
            r[mj][mi] = temp;
         for (k = i + 1; k < j - 1; k++) { 
            mk = map[k];
            k_1 = map[k+1];
            temp = r[mk][mi] + r[mj][k_1];
            if (temp > r[mj][mi])
              r[mj][mi] = temp;
         }
      } 
   }
}

/* trace back. 
 */
void traceback(int* mate, int** r, Graph* graf) {
   stack* stack = createStack();
   int i, j, k;
   int mi, mj, mk, i_1, j_1, k_1;
   int temp;
   pushStack(stack, 1);
   pushStack(stack, mapsize);
   while (!stackIsEmpty(stack)) {
      popStack(stack, &j);
      popStack(stack, &i); 
      mi = map[i];
      mj = map[j]; 
      if (j - i - 1 < min_vloop_len 
               || mj - mi - 1 < min_loop_len) continue;
      i_1 = map[i+1];
      j_1 = map[j-1];
      
      temp = Edge(*graf, mj, mi);
      if (i_1 < j_1)
         temp += r[j_1][i_1];      
      if (temp == r[mj][mi]) {    // i paired with j
         if(Edge(*graf, mj, mi) > THRESHOLD) {
            mate[mi] = mj;
            mate[mj] = mi;
         } 
         pushStack(stack, i+1);
         pushStack(stack, j-1);
         continue; 
      }

      if (i_1 < mj) {
         if(r[mj][mi] == r[mj][i_1]) { // i unpaired
           pushStack(stack, i+1);
           pushStack(stack, j);
           continue;
         }
      } else {
         continue;
      }

      if (j_1 > mi) {
         if(r[mj][mi] == r[j_1][mi]) { // j unpaired
           pushStack(stack, i);
           pushStack(stack, j-1);
           continue;
         }
      } else {
         continue;
      }

      for (k = i + 1; k < j - 1; k++) {
         mk = map[k];
         k_1 = map[k+1];
         temp = r[mk][mi] + r[mj][k_1];
         if (temp == r[mj][mi]) {
           if(Edge(*graf, mk, mi) > THRESHOLD) {
              mate[mi] = mk;
              mate[mk] = mi;
           } 
           pushStack(stack, k+1);
           pushStack(stack, j);
           pushStack(stack, i);
           pushStack(stack, k);
           break;
         }
      }
   }
   freeStack(stack);
}

void markMate(Helix helix, int* mate) {
   int i;
   for(i = 0; i < helix.len; i++) {
      mate[helix.start + i] = helix.end - i;
      mate[helix.end - i] = helix.start + i;
   }
}

void markComp(CompHelix cHelix, int* mate, Graph* graf) {
   int i;
   Helix* vHelix = cHelix.vHelix;
   for(i = 0; i < cHelix.n; i++) {
      markMate(vHelix[i], mate);
   } 
   start5 = vHelix[0].start;
   end5 = vHelix[i-1].start + vHelix[i-1].len - 1;
   start3 = vHelix[i-1].end - vHelix[i-1].len + 1;
   end3 = vHelix[0].end;
}

updateMap() {
   int i, j = 1;
   for (i = 1; i <= mapsize; i++) {
      int k = map[i];
      if (k < start5 || k > end3 || (end5 < k && k < start3)) {
         map[j++] = k;
      }
   }
   mapsize = --j;
}

void mark(CompHelix* vCompHelix, int nCompHelix, int* mate, Graph* graf) {
   int i;
   int n = hlx_per_iter;
   if (n == 0) n = 1;
   for(i = 0; i < n; i++) {
      markComp(vCompHelix[i], mate, graf);
      updateMap();
   } 
   divided = (n == 1) ? 1 : 0;
}

idp(int* mate, Graph* graf, int seqLen) {
   int** r;
   int stop = 0;
   int iteration = 0;
   int* submate = calloc(seqLen+1, sizeof(int));
   int i, j;
   int nHelix;
   Helix* vHelix;
   CompHelix* vCompHelix;
   int nCompHelix;

   r = makeHalfMatrix(seqLen); 

   map = calloc(seqLen+1, sizeof(int)); 
   j = 0;
   for(i = 1; i <= seqLen; i++) {
      if (sum[i] > 0) map[++j] = i;
   }
   mapsize = j;

   while(!stop) {
      iteration++;
      dp(r, graf);
      memset(submate, 0, seqLen * sizeof(int));
      traceback(submate, r, graf);
      getHelices(&vHelix, &nHelix, submate, seqLen); 
      if (nHelix == 0) stop = 1;
      else {
         fillHelixScore(vHelix, nHelix, graf);
         makeCompositeHelix(&vCompHelix, &nCompHelix, vHelix, nHelix);
         if (nCompHelix == 0) { 
           stop = 1;
         } else {
            qsort(vCompHelix, nCompHelix, sizeof(CompHelix), &compareCompHelix);
            //display(vCompHelix, nCompHelix);
            //displayCompHelix(vCompHelix[0]);
            mark(vCompHelix, nCompHelix, mate, graf);
         }
         freeVCompHelix(vCompHelix, nCompHelix);
      }
      free(vHelix);
   }
   freeHalfMatrix(r);
   free(submate);
   free(map);
}

usage() {
   fprintf(stderr, "`ilm' computes a secondary structure with pseudoknots given a score matrix.\n");
   fprintf(stderr, "\nUsage: ilm [option]... <matrix file>\n");
   fprintf(stderr, "matrix file is in MWM format\n");
   fprintf(stderr, "\n Main options:\n");
   fprintf(stderr, "  -L, --LOOP_LEN=NUM      minimum loop length (default=3)\n");
   fprintf(stderr, "  -V, --VLOOP_LEN=NUM     minimum virtual loop length (default=3)\n");
   fprintf(stderr, "  -H, --MIN_HLX=NUM       minimum helix length (default=3)\n");
   fprintf(stderr, "  -N, --HLX_PER_ITER=NUM  number of helices selected per iteration (default=1)\n");   
   fprintf(stderr, "  -I, --ITER_BEF_STOP=NUM number of iterations before termination(default=unlimited)\n");   
   fprintf(stderr, "  -h, --help              print this help message\n");
}

parseOptions(int argc, char** argv) {
   int c;
   int option_index;
   while(1) {
      static struct option long_options[] = {
         {"LOOP_LEN", required_argument, 0, 'L'}, 
         {"VLOOP_LEN", required_argument, 0, 'V'},
         {"MIN_HLX", required_argument, 0, 'H'},
         {"HLX_PER_ITER", required_argument, 0, 'N'},
         {"ITER_BEF_STOP", required_argument, 0, 'I'},
         {"help", no_argument, 0, 'h'}
      };
      c = getopt_long(argc, argv, "L:V:H:N:I:h", long_options, 
                          &option_index);
      if (c == -1) 
         break;

      switch (c) {
         case 'h':
           usage();
           exit(0);
           break;
         case 'L':
           min_loop_len = atoi(optarg);
           if (min_loop_len <= 0) {
              min_loop_len = DEFAULT_MIN_LOOP_LEN;
           }
           break;
         case 'V':
           min_vloop_len = atoi(optarg);
           if (min_vloop_len <= 0) {
              min_vloop_len = DEFAULT_MIN_VLOOP_LEN;
           }
fprintf(stderr, "min_vloop_len = %d\n", min_vloop_len);
           break;
         case 'H':
           min_hlx_len = atoi(optarg);
           if (min_hlx_len <= 0) {
              min_hlx_len = DEFAULT_MIN_HLX_LEN;
           }
           break;
         case 'N':
           hlx_per_iter = atoi(optarg);
           if (hlx_per_iter <= 0) {
              hlx_per_iter = DEFAULT_HLX_PER_ITER;
           }
           break;
         case 'I':
           iter_bef_stop = atoi(optarg);
           if (iter_bef_stop < 0) {
              iter_bef_stop = DEFAULT_ITER_BEF_STOP;
           }
           break;
         default:
           abort();
      }
   }
}

int main(int argc, char** argv) {
   int seqLen;
   int* mate;
   Graph graf;
   int i, j;

   parseOptions(argc, argv);
   if (optind >= argc) {
      abort();
   }
   if (!ReadGraf(argv[optind], &graf)) {
      fprintf(stderr, "cannot open graph file %s\n", argv[1]);
      exit(EXIT_FAILURE);
   }
   seqLen = graf.n_vert;
   mate = calloc(seqLen+1, sizeof(int));

   sum = calloc(seqLen+1, sizeof(long));
   for(i = 1; i <= seqLen; i++) {
      for(j = i+1; j <= seqLen ; j++) {
         if (Edge(graf, i, j) <= 0) {
            continue;
         }
         sum[i] += Edge(graf, i, j);
         sum[j] += Edge(graf, i, j);
      }
   }

   idp(mate, &graf, seqLen);
   printf("\nFinal Matching:\n");
   for(i = 1; i <= seqLen; i++) {
     printf("%d %d\n", i, mate[i]);
   }
   FreeGraf(&graf);
   free(mate);
   free(sum);
}
