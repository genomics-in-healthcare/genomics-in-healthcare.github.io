#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <part_func.h>
#include <fold_vars.h>
#include <fold.h>
#include "grafio.h"

double edge(int i, int j) {
   double p;
   if (i == 0 || j == 0)
      return 0;
   p = i > j ? pr[iindx[j]-i] : pr[iindx[i]-j];
   return p;
}

pf2score(char* seq, int seqL, struct Graph* graf) {
   float mfe;
   float kt;
   char* stru;

   int i, j;

//     temperature = 37.;
//   noGU = 1;
//   no_closingGU = 1;
//   noLonelyPairs = 1;

   stru = malloc((seqL+1) * sizeof(char));
   if (!stru) { fprintf(stderr, "no enough memory!\n"); exit(1); }

   initialize_fold(seqL);
   mfe = fold(seq, stru);
   free_arrays();
   kt = (temperature+273.15)*1.98717/1000.; 
   pf_scale = exp(-mfe/kt/seqL);  

   init_pf_fold(seqL);
   pf_fold(seq, stru); 
   for(i = 0; i < seqL; i++) { 
      for(j = i+2; j < seqL; j++) {
        int s = 10000 * edge(i+1, j+1);
         if (s < 1) s = 0;
         Edge(*graf, i+1, j+1) += (s);
      }
   }

   free_pf_arrays();   
   free(stru);
}
