#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "seqio.h"
#include "grafio.h"

/* Default parameters */
#define DEFAULT_MIN_LOOP 3
#define DEFAULT_MIN_HLX  2

/* Default scores */
#define DEFAULT_GOOD_PAIR  1
#define DEFAULT_BAD_PAIR   2
#define DEFAULT_PAIRED_GAP 3
#define DEFAULT_HELIX_MULT 2.

/* Flags */
#define GAP    1
#define NO_GAP 0
#define ON     1
#define OFF    0

/* Utility variables */
struct Graph  Graf;
int *Translate;

/* Parameters */
int    MinLoop = DEFAULT_MIN_LOOP;
int    MinHlx  = DEFAULT_MIN_HLX;
int    TxtMode = OFF;

/* Scores */
int   GoodPair  = DEFAULT_GOOD_PAIR;
int   BadPair   = DEFAULT_BAD_PAIR;
int   PairedGap = DEFAULT_PAIRED_GAP;
float HelixMult = DEFAULT_HELIX_MULT;

char Encode(char base)
{
  char ret;

  switch (toupper(base))
  {
    case 'A': ret = 0; break;
    case 'C': ret = 1; break;
    case 'G': ret = 2; break;
    case 'T':
    case 'U': ret = 3; break;
    default : ret = 4;
  }

  return ret;
}

void DoHelix(int start5, int stop5, int start3, int stop3)
{
  int hlx_len = stop5 - start5 - 1;
  int score;
  int i, j;

  score = hlx_len < MinHlx ? -BadPair : hlx_len*HelixMult + GoodPair;

  for (i = start5 + 1, j = start3 - 1; i < stop5; i++, j--)
    Edge(Graf, Translate[i], Translate[j]) += score;

  if (stop3 - stop5 > MinLoop)
    Edge(Graf, Translate[stop5], Translate[stop3]) -= BadPair;
}

int main(int argc, char *argv[])
{
  struct Sequence seq;
  int can_pair[5][5];
  char *code_seq;
  int code_len;
  char *gap_list;
  char *curr_arg;
  char c;
  int i, j, k;
  int oldj, oldk;
  int nSeq = 0;

  for (i = 0; i < 5; i++)
    for (j = 0; j < 5; j++)
      can_pair[i][j] = 0;

/* Initialize acceptable base pairs                                      */
/* (Sorry, I had to do this the long way to make the program lint-clean) */

/*         A  U             C  G             G  C             U  A      */
  can_pair[0][3] = can_pair[1][2] = can_pair[2][1] = can_pair[3][0] = 1;

/*         G  U             U  G      */
  can_pair[2][3] = can_pair[3][2] = 1;

  i = 0;
  for (;;) {
    if (++i > argc - 1) {
      fprintf(stderr, "\nUsage: hlxplot [-options] filename\n");
      fprintf(stderr, "  Options:\n");
      fprintf(stderr, "    -b B: Set bad pair penalty to B\n");
      fprintf(stderr, "            (Default = %d)\n", BadPair);
      fprintf(stderr, "    -g G: Set good pair score to G\n");
      fprintf(stderr, "            (Default = %d)\n", GoodPair);
      fprintf(stderr, "    -h H: Set minimum helix length to H\n");
      fprintf(stderr, "            (Default = %d)\n", MinHlx);
      fprintf(stderr, "    -l L: Set minimum loop length to L\n");
      fprintf(stderr, "            (Default = %d)\n", MinLoop);
      fprintf(stderr, "    -s S: Set helix length score to S\n");
      fprintf(stderr, "            (Default = %3.1f)\n", HelixMult);
      fprintf(stderr, "    -t  : Write output in text format\n");
      fprintf(stderr, "            (Default = Binary format)\n");
      fprintf(stderr, "    -x X: Set paired gap penalty to X\n");
      fprintf(stderr, "            (Default = %d)\n\n", PairedGap);
      exit(EXIT_FAILURE);
    }

    curr_arg = argv[i];
    if (curr_arg[0] != '-')
      break;

    switch (curr_arg[1])
      {
      case 'b':
	curr_arg = argv[++i];
	if (!isdigit(curr_arg[0])) {
	  fprintf(stderr, "\nError: Bad pair penalty not specified ");
	  fprintf(stderr, "after -b\n\n");
	  exit(EXIT_FAILURE);
	}
	BadPair = atoi(curr_arg);
	break;
      case 'g':
	curr_arg = argv[++i];
	if (!isdigit(curr_arg[0])) {
	  fprintf(stderr, "\nError: Good pair score not specified ");
	  fprintf(stderr, "after -g\n\n");
	  exit(EXIT_FAILURE);
	}
	GoodPair = atoi(curr_arg);
	break;
      case 'h':
	curr_arg = argv[++i];
	if (!isdigit(curr_arg[0])) {
	  fprintf(stderr, "\nError: Minimum helix length not specified after");
	  fprintf(stderr, " -h\n\n");
	  exit(EXIT_FAILURE);
	}
	MinHlx = atoi(curr_arg);
	break;
      case 'l':
	curr_arg = argv[++i];
	if (!isdigit(curr_arg[0])) {
	  fprintf(stderr, "\nError: Minimum loop length not specified after");
	  fprintf(stderr, " -l\n\n");
	  exit(EXIT_FAILURE);
	}
	MinLoop = atoi(curr_arg);
	break;
      case 's':
	curr_arg = argv[++i];
	if ((!isdigit(curr_arg[0])) && (curr_arg[0] != '.')) {
	  fprintf(stderr, "\nError: Helix length score not specified after");
	  fprintf(stderr, " -s\n\n");
	  exit(EXIT_FAILURE);
	}
	HelixMult = atof(curr_arg);
	break;
      case 't':
	TxtMode = ON;
	break;
      case 'x':
	curr_arg = argv[++i];
	if (!isdigit(curr_arg[0])) {
	  fprintf(stderr, "\nError: Paired gap penalty not specified after");
	  fprintf(stderr, " -x\n\n");
	  exit(EXIT_FAILURE);
	}
	PairedGap = atoi(curr_arg);
	break;
      default :
	fprintf(stderr, "\nUnknown switch: %s\n\n", curr_arg);
	exit(EXIT_FAILURE);
      }
  }

  if (!OpenSeq(&seq, argv[i]))
    exit(EXIT_FAILURE);

  if (!MakeGraf(&Graf, seq.seq_len))
    exit(EXIT_FAILURE);
  Graf.n_edge = CountMaxEdges(&Graf);

  code_seq  = (char *) malloc((seq.seq_len + 2)*sizeof(char));
  Translate = (int *)  malloc((seq.seq_len + 2)*sizeof(int));
  gap_list  = (char *) malloc((seq.seq_len + 2)*sizeof(char));
  if ((code_seq == NULL) || (Translate == NULL) || (gap_list == NULL)) {
    fprintf(stderr, "\nCannot allocate memory\n\n");
    exit(EXIT_FAILURE);
  }

  for (;;) {
    if (!GetSeq(&seq))
      break;

    nSeq++;
    for (i = 1, code_len = 0; i <= seq.seq_len; i++) {
      c = Encode(seq.seq[i]);
      if (c == 4)
        gap_list[i] = GAP;
      else {
        code_seq[++code_len] = c;
        Translate[code_len] = i;
        gap_list[i] = NO_GAP;
      }
    }

    for (i = MinLoop + 2*MinHlx; i < code_len; i++) {
      for (j = i, k = 1, oldj = j + 1, oldk = 0;
	   j - k > MinLoop; j--, k++)
        if (!can_pair[code_seq[j]][code_seq[k]]) {
          DoHelix(oldk, k, oldj, j);
          oldj = j;
          oldk = k;
        }
      DoHelix(oldk, k, oldj, j);
    }

    for (i = 1; i < code_len - MinLoop - 2*(MinHlx - 1); i++) {
      for (j = code_len, k = i, oldj = j + 1, oldk = k - 1;
	   j - k > MinLoop; j--, k++)
        if (!can_pair[code_seq[j]][code_seq[k]]) {
          DoHelix(oldk, k, oldj, j);
          oldj = j;
          oldk = k;
        }
      DoHelix(oldk, k, oldj, j);
    }

    for (i = 1; i <= seq.seq_len; i++)
      if (gap_list[i] == GAP)
        for (j = 1; j <= seq.seq_len; j++)
          if (gap_list[j] == NO_GAP)
            Edge(Graf, i, j) -= PairedGap;
  }

  for(i = 1; i <= seq.seq_len; i++) {
     for(j = i + MinLoop; j <= seq.seq_len; j++) {
         Edge(Graf, i, j) = 20 * Edge(Graf, i, j) / nSeq;
     }
  }

  if (TxtMode == OFF)
    WriteBinGraf(stdout, &Graf);
  else
    WriteTextGraf(stdout, &Graf, ALL_EDGES);

  CloseSeq(&seq);

  return (EXIT_SUCCESS);
}
